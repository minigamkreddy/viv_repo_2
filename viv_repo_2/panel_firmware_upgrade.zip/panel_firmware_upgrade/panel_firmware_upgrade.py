'''
update the panel build with the selected build
'''
import time
import ftplib
import configparser
import re
import commands
import sys
import os
import logging
import polling
import threading
import socket
import warnings
import paramiko
import argparse
import subprocess

TIME_OUT = 3600
FAILURE_LIST = []
SUCCESS_LIST = []
log = logging.getLogger(__name__)
log.setLevel(logging.DEBUG)
channel = logging.StreamHandler(sys.stdout)
channel.setLevel(logging.DEBUG)
log.addHandler(channel)
log = log

class panel_build():
    """
    flush the build to the panel
    """
    def __init__(self, panel_mac, panel_ip, config , panel_list):
        #logging.info("This is a constructor")
        self.file_size_rpi_build = None
        self.file_size = None
        self.firmware_file = None
        self.panel_file_size = None
        self.wallsly_build_copied = False
        self.sky_build_copied = False
        self.panel_ip = panel_ip
        self.panel_mac = panel_mac
        self.panel_list = panel_list
        self.panel_type = None
        self.success_panel_ip_list = []
        self.failure_panel_ip_list = []
        self.threads = []
        self.config = config

    """
    def init_log(self):
        '''Initialises the logs formatting.'''
        log = logging.getLogger(__name__)
        log.setLevel(logging.DEBUG)
        channel = logging.StreamHandler(sys.stdout)
        channel.setLevel(logging.DEBUG)
        log.addHandler(channel)
        log = log
    """ 
    def cmd_local(self, cmd, expected_result=None,
                  return_output=True, nohup=False):
        '''
        Runs commands on the local machine

        Args:
            cmd            : Command to be executed on the local host
            expected_result: Result to be expected after running the command
            return_output  : If true the output of the command will be returned
            nohup          : If true command will be run in background

        Return:
            output (str): Output of the command if return_output is True
            bool        : If return_output is False
        '''
        output = None
        unused_err = None
        #try:
            #if nohup:
            #    cmd += ' > /dev/null 2>&1 &'
        
        log.info('local cmd: {}'.format(cmd))
        process = subprocess.Popen(cmd, shell=True, env=os.environ,
                stdout=subprocess.PIPE)
        log.info('***********************')
        log.info(process)
        output, unused_err = process.communicate()
        retcode = process.wait()
        log.info('Output: {}'.format(output))
        log.info('Error: {}'.format(unused_err))
            
        if return_output:
            return output.strip()
        elif expected_result is None:
            log.info('Return code is {}'.format(retcode))
            return retcode == 0
        else:
            if isinstance(expected_result, list):
                for i in expected_result:
                    if i not in output:
                        return False
            else:
                if expected_result not in output:
                    return False
            return True
        #except Exception as error:
        log.error('Error executing cmd: {} \nmethod: {}'.format(
            cmd, sys._getframe().f_code.co_name))

    def cmd_remote(self, cmd, ip_addr, user, password,
                   return_data=True, verify_rcode=False):
        '''
        Run commands on the remote machine using ssh

        Args:
            cmd         : Command to be run on remote host
            ip_addr     : IP address fo the remote host
            user        : Username of the remote host
            password    : Password of the remote host
            return_data : If true the output of the command will be returned
            nohup       : If true command will be run in background

        Return:
            str: Output of the command if return_output is True
        '''
        log.info('remote cmd on the panel {} is {}'.format(
                    self.panel_ip,
                    cmd))
        retry = 3
        wait = 3
        rcode = 1
        body = None
        stdin = None
        stdout = None
        stderr = None
        out = None
        error = None
        for i in range(retry):
            session = None
            msg = 'retry {}(): {}'.format(sys._getframe().f_code.co_name, i)
            try:
                log.info('panel_ip_addr = {}'.format(ip_addr))
                log.info('panel_username = {}'.format(user))
                log.info('panel_password = {}'.format(password))
                print user
                print password
                warnings.filterwarnings('ignore')
                session = paramiko.SSHClient()
                session.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                session.connect(hostname=ip_addr, username=user, password=password,
                                look_for_keys=False, timeout=30)
                warnings.filterwarnings('default')
                stdin = None
                stdout = None
                stderr = None
                out = None
                stdin, stdout, stderr = session.exec_command(cmd)
                out = stdout.read()
                log.debug('Out: {}'.format(out))
                rcode = int(stdout.channel.recv_exit_status())
                if stdout is None:
                    log.info('Warning  : stdout = None')
                    log.info(msg)
                    time.sleep(wait)
                    continue
                if out is None:
                    log.info('Warning  : out = None')
                    log.info(msg)
                    time.sleep(wait)
                    continue
                if rcode != 0 and verify_rcode is True:
                    log.info('Warning  : rcode {}'.format(rcode))
                    log.info(msg)
                    continue
                # there are differences in paramiko between python2 and python3
                # so this is how I do the conversion for both python versions
                # python3 returns a bytearray
                # python2 returns a unicode string
                if isinstance(out, bytearray) or isinstance(out, bytes):
                    body = str(out.decode('utf-8'))
                else:
                    body = str(out)
                break
            except socket.error as error:
                log.error('method:{} failed due to unable to connect to \
                        remote host on the panel {} \n error: {}'.format(
                            sys._getframe().f_code.co_name,ip_addr,error))
            except BaseException:
                log.debug('In BaseException')
                log.info(msg)
                time.sleep(wait)
            except Exception as error:
                log.error('cmd_remote failed with error: {} \nmethod: {}'.format(
                    error, sys._getframe().f_code.co_name))
            finally:
                try:
                    session.close()
                except BaseException:
                    pass
            if i == retry - 1:
                msg = 'cmd_remote() failed after retries: {} \n reason: {}\n\
                        cmd:    {} \n rcode:  {} \nbody:   {} \nstdout: {} \n\
                        stderr: {}'.format(retry, error, cmd, rcode, body,
                                stdout, stderr)
                log.error(msg)
        if return_data is True:
            return body, rcode
        else:
            log.info(body)


    def copy_file_rpi_to_controller(self):
        """
        copy the build file from the sniffer firmware_repo to controller
        """
        log.info('Copying the firmware file from firmware repository to controller')
        cwd = os.getcwd()
        if self.panel_type == 'wallsly' and args.url !=[]:
            if len(sys.argv) > 5:
                if re.search('sly',args.url[0]):
                    return True
                elif re.search('sly',args.url[1]):
                    return True
                else:
                    self.firmware_path = '{}/{}'.format(self.config['firmware_repo']['path'],
                                        self.config['firmware_repo']['wallsly_build'])
            elif len(sys.argv) <= 5:
                if re.search('sly',args.url[0]):
                    return True
                else:
                    self.firmware_path = '{}/{}'.format(self.config['firmware_repo']['path'],
                                        self.config['firmware_repo']['wallsly_build'])
        elif self.panel_type == 'skycontrol' and args.url !=[]:
            if len(sys.argv) > 5:
                if re.search('touchlink',args.url[0]):
                    return True
                elif re.search('touchlink',args.url[1]):
                    return True
                else:
                    self.firmware_path = '{}/{}'.format(self.config['firmware_repo']['path'],
                                            self.config['firmware_repo']['sky_build'])
            elif len(sys.argv) <= 5:
                if re.search('touchlink',args.url[0]):
                    return True
                else:
                    self.firmware_path = '{}/{}'.format(self.config['firmware_repo']['path'],
                                            self.config['firmware_repo']['sky_build'])
        elif self.panel_type == 'wallsly':
            if self.wallsly_build_copied == True:
                log.info("Build already copied to controller")
                return True
            self.firmware_path = '{}/{}'.format(self.config['firmware_repo']['path'],
                                        self.config['firmware_repo']['wallsly_build'])
        elif self.panel_type == 'skycontrol':
            if self.sky_build_copied == True:
                log.info("Build already copied to controller")
                return True
            self.firmware_path = '{}/{}'.format(self.config['firmware_repo']['path'],
                                            self.config['firmware_repo']['sky_build'])
        else:
            log.info('Invalid panel type on the panel {}'.format(
                        self.panel_ip))
            raise Exception('Invalid panel type')
        copy_panel_build = ('sshpass -p {} scp -o StrictHostKeyChecking='.format(
            self.config['firmware_repo']['password'])
                    + ('no -o UserKnownHostsFile=/dev/null -r ' +
                        '{}@{}:{} {}').format(
                            self.config['firmware_repo']['username'],
                            self.config['firmware_repo']['ip'],
                            self.firmware_path,
                            cwd))
        log.info('Copy command: {}'.format(copy_panel_build))
        rcode, copy_build_rpi_to_controller = commands.getstatusoutput(copy_panel_build)
        log.info("Copy command output: {}".format(copy_build_rpi_to_controller))
        if rcode:
            raise Exception('Failed to copy firmware file to controller')
        else:
            log.info('Successfully copied firmware file to controller')
            if self.panel_type == 'wallsly':
                self.wallsly_build_copied = True
            else:
                self.sky_build_copied = True
        print("self.firmware_path = %s panel_ip = %s"%(self.firmware_path,self.panel_ip))
        return True

    def copy_file_controller_to_panel(self):
        """
        copy file from controller to panel
        """
        log.info('Copying firmware file from controller to panel {}'.format(
                        self.panel_ip))
        self.firmware_file = self.firmware_path.split('/')[-1]
        copy_build_to_panel = ('sshpass -p {} scp -o StrictHostKeyChecking='.format(
            self.config['panel']['host_password'])
                               + ('no -o UserKnownHostsFile=/dev/null -r ' +
                                  '{} {}@{}:{}').format(
                                      self.firmware_file,
                                      self.config['panel']['host_username'],
                                      self.panel_ip,
                                      self.config['panel']['build_path']))
        log.info("Command to copy build to panel {}: {}".format(self.panel_ip, copy_build_to_panel))
        rcode, copy_build_to_panel_result = commands.getstatusoutput(copy_build_to_panel)
        log.info("Command output for panel {}: {}".format(self.panel_ip,copy_build_to_panel_result))
        if rcode:
            log.error('Failed to copy firmware to panel {}'.format(
                        self.panel_ip))
            return False
        self.file_size = 'stat {}'.format(self.firmware_file)
        log.info('self.file_size on the panel {} is {}'.format(
                    self.panel_ip,
                    self.file_size))
        firmware_size = commands.getoutput(self.file_size)
        log.info('firmware_size on the panel {} is {}'.format(
                    self.panel_ip,
                    firmware_size))
        try:
            self.file_size = re.search(r'Size:(.*)Blocks:', firmware_size).group(1)
            log.info("self.file_size %s:" % self.file_size)
            self.file_size_rpi_build = self.file_size.strip()
            return True
        except Exception as error:
            log.error('Getting file size failed on the panel {}, error {}'.format(
                    self.panel_ip,
                    error))
            self.failure_panel_ip_list.append(self.panel_ip)
            return False

    def copy_file_controller_to_rpi(self):
        log.info('Copying firmware file from controller to rpi {}'.format(
                        self.panel_ip))
        print("self.firmware_path %s"%self.firmware_path)
        self.firmware_file = self.firmware_path.split('/')[-1]
        copy_build_to_panel = ('sshpass -p {} scp -o StrictHostKeyChecking='.format(
            self.config['firmware_repo']['password'])
                               + ('no -o UserKnownHostsFile=/dev/null -r ' +
                                  '{} {}@{}:{}').format(
                                      self.firmware_file,
                                      self.config['firmware_repo']['username'],
                                      self.config['firmware_repo']['ip'],
                                      self.config['firmware_repo']['path']))
        log.info("Command to copy build to rpi {}: {}".format(self.panel_ip, copy_build_to_panel))
        rcode, copy_build_to_panel_result = commands.getstatusoutput(copy_build_to_panel)
        log.info("Command output for rpi {}: {}".format(self.panel_ip,copy_build_to_panel_result))
        if rcode:
            log.error('Failed to copy firmware to rpi {}'.format(
                        self.panel_ip))
            return False

    def remove_old_firmware_on_panel(self):
        '''
            Removes old firmware file copied into the panel to avaoid space issue .
        '''
        log.info('Removing if the firmware build is copied to the panel')
        remove_cmd = 'echo y | plink -ssh {}@{} -pw {} rm -rf {}/*.tar.bz2'.format(
            self.config['panel']['host_username'],
            self.panel_ip,
            self.config['panel']['host_password'],
            self.config['panel']['build_path'])
        log.info(remove_cmd)
        rcode, check_build_in_panel = commands.getstatusoutput(remove_cmd)
        log.info(check_build_in_panel)
        if rcode:
            log.warning('Failed to remove the build on the panel is {}'.format(
                    self.panel_ip))
        return True

    def check_build_copied_to_panel(self):
        '''
            Verify wheather build is copied to panel or not.
        '''
        log.info('Verifying if the firmware build is copied to the panel is {}'.format(
                    self.panel_ip))
        path = self.firmware_path.split('/')[-1]
        log.info(path)
        check_build_copied_to_panel = 'echo y | plink -ssh {}@{} -pw {} ls {}/{}'.format(
            self.config['panel']['host_username'],
            self.panel_ip,
            self.config['panel']['host_password'],
            self.config['panel']['build_path'],
            path)
        log.info(check_build_copied_to_panel)
        rcode, self.panel_build_version = commands.getstatusoutput(check_build_copied_to_panel)
        log.info('panel_build_version {}'.format(self.panel_build_version))
        if rcode:
            log.info('Failed to copy build on the panel {}'.format(
                    self.panel_ip))
            self.failure_panel_ip_list.append(self.panel_ip)
            return False
        return True

    def get_panel_type(self):
        '''
            Getting the type from the panel.
        '''
        print("self.args.url %s"%args.url)
        log.info('Fetching the panel type for the panel {}'.format(self.panel_ip))
        panel_type_cmd = 'echo y | plink -ssh {}@{} -pw {} hostname'.format(
            self.config['panel']['host_username'],
            self.panel_ip,
            self.config['panel']['host_password'])
        rcode, panel_type = commands.getstatusoutput(panel_type_cmd)
        if rcode:
            log.info('Failed to get the panel type on the panel is {}'.format(
                    self.panel_ip))
            return False

        log.info('Panel type is: {}'.format(panel_type))
        if 'wallsly' in panel_type:
            return 'wallsly'
        elif 'touchlink' in panel_type:
            return 'skycontrol'
        else:
            log.error('Invalid panel type on the panel {}'.format(self.panel_ip))
            log.error('Aborting the panel upgrade for {}'.format(self.panel_ip))
            FAILURE_LIST.append(self.panel_ip)
            raise Exception ('Invalid panel type : {}'.format(self.panel_ip))

    def update_panel_build(self):
        """
        Updates the panel build
        """
        # Get panel type
        self.panel_type = self.get_panel_type()

        # Validate current and new firmware is not same
        try:
            panel_version = self.get_panel_version()
            if panel_version:
                log.info('Current and new firmware versions are same on the panel {}. Aborting the panel update'.format(
                            self.panel_ip))
                return True
        except Exception as error:
            log.info('Failed to execute the command,error {} on the panel {}'.format(
                            error,
                            self.panel_ip))
        log.info('Current and new firmwares are different, flashing the firmware on the panel {}'.format(self.panel_ip))    

        # Remove old firmware files on panel
        self.remove_old_firmware_on_panel()

        # Copy panel firmware from repo to controller
        if self.panel_type == 'wallsly' and args.url !=[] and len(sys.argv) > 5:
            if re.search('sly',args.url[0]):
                self.copy_file_controller_to_rpi()
            elif re.search('sly',args.url[1]):
                self.copy_file_controller_to_rpi()
            else:
                self.copy_file_rpi_to_controller()
        elif self.panel_type == 'wallsly' and args.url !=[] and len(sys.argv) <= 5:
            if re.search('sly',args.url[0]):
                self.copy_file_controller_to_rpi()
            else:
                self.copy_file_rpi_to_controller()

        #elif args.url !=' ' and self.panel_type == 'skycontrol':
        elif self.panel_type == 'skycontrol' and args.url !=[] and len(sys.argv) > 5:
            if re.search('touchlink',args.url[0]):
                self.copy_file_controller_to_rpi()
            elif re.search('touchlink',args.url[1]):
                self.copy_file_controller_to_rpi()
            else:
                self.copy_file_rpi_to_controller()
        elif self.panel_type == 'skycontrol' and args.url !=[] and len(sys.argv) <= 5:
            if re.search('touchlink',args.url[0]):
                self.copy_file_controller_to_rpi()
            else:
                self.copy_file_rpi_to_controller()
        else:    
            self.copy_file_rpi_to_controller()

        # Copy firmware from controller to panel
        if not self.copy_file_controller_to_panel():
            log.info('Failed to copy firmware to panel {} from controller'.format(
                           self.panel_ip))

        # Validate firmware is copied to panel    
        if not self.check_build_copied_to_panel():
            log.info('Failed to find the copied firmware in the panel {}'.format(self.panel_ip))

        panel_build_version = re.search(self.firmware_file, self.panel_build_version).group()
        log.info("Firmware version to be flashed on the panel {} is {}".format(
                            self.panel_ip,
                            panel_build_version))
        log.info('Panel type of the panel {} is {}'.format(self.panel_ip,self.panel_type))

        time.sleep(5)
        try:
            if self.panel_type == 'wallsly':
                build_path = self.firmware_path.split('/')[-1]
                log.info('Build path on the panel {} is {}'.format(self.panel_ip, build_path))
            else:
                build_path = self.firmware_path.split('/')[-1]
                log.info('Build path on the panel {} is {}'.format(self.panel_ip, build_path))
            build_name = re.search(build_path, panel_build_version)
            build_name = build_name.group()
            log.info('Build name on the panel {} is {}'.format(self.panel_ip, build_name))
            self.panel_file_size = 'ls -l {}/{}'.format(self.config['panel']['build_path'],panel_build_version)
            log.info("self.panel_file_size %s" % self.panel_file_size)
            get_panel_build_size = 'echo y | plink -ssh {}@{} -pw {} {}'.format(
                self.config['panel']['host_username'],
                self.panel_ip,
                self.config['panel']['host_password'],
                self.panel_file_size)
            rcode, panel_build_size = commands.getstatusoutput(get_panel_build_size)
            if rcode:
                log.error('Failed to get panel build size on panel {}'.format(self.panel_ip))
                return None
        except Exception as error:
            log.error('Failed to upgrade panel {} with error: {}'.format(self.panel_ip, error))
            return None

        log.info("Frimware file size = {}".format(panel_build_size))

        # Get firmware file size on panel
        try:
            file_size = re.search(r'root\s+(\d+)', panel_build_size).group(1)
            #file_size = re.search(r'Size:(.*)Blocks:', panel_build_size).group(1)
            log.info('Firmware file size on the panel {} is {}'.format(self.panel_ip, file_size))
        except Exception as error:
            log.error('Getting file size failed, error {} {}'.format(self.panel_ip,error))
            return None
        file_size_panel_build = file_size.strip()
        log.info("Copied firmware file size on panel {} = {}".format(self.panel_ip, file_size_panel_build))


        # Clear the database of the panel before updating the build
        self.delete_panel_db()

        # Validate build path on panel
        panel_update_cmd = 'ls /usr/local/bin/quick-update'
        try:
            get_panel_update_cmd = 'echo y | plink -ssh {}@{} -pw {} {}'.format(
                    config['panel']['host_username'],
                    self.panel_ip,
                    config['panel']['host_password'],
                    panel_update_cmd)
            rcode,status = commands.getstatusoutput(get_panel_update_cmd)
            status =  ''.join(status)
            log.info('Status: {}, return code: {}'.format(status,rcode))
            
            # If file doesn't exist copy it to /usr/local/bin path
            if 'No such file or directory' in status:
                panel_update_cmd = 'find / -name quick-update'
                get_panel_update_cmd = 'echo y | plink -ssh {}@{} -pw {} {}'.format(
                            config['panel']['host_username'],
                            self.panel_ip,
                            config['panel']['host_password'],
                            panel_update_cmd)

                log.debug('Finding the path of quickupdate: {}'.format(get_panel_update_cmd))
                rcode,status = commands.getstatusoutput(get_panel_update_cmd)
                log.debug('quickupdate path on panel {}  is : {}'.format(self.panel_ip, status))


                line = status.splitlines()
                copy_to_path = 'cp {} /usr/local/bin/quick-update'.format(line[0])
                log.info('Copying quickupdate file from : {}'.format(line[0]))
                get_panel_update_cmd = 'echo y | plink -ssh {}@{} -pw {} {}'.format(
                            config['panel']['host_username'],
                            self.panel_ip,
                            config['panel']['host_password'],
                            copy_to_path)
                log.info('Copying the quickupdate to /usr/local/bin/ path: {}'.format(copy_to_path))
                rcode,status = commands.getstatusoutput(get_panel_update_cmd)
                log.info('Copy command status: {}, rcode: {}'.format(status, rcode))

            # Update the panel
            update_build_cmd = 'echo 1 | /usr/local/bin/quick-update -f {}/{}'.format(
                                        self.config['panel']['build_path'],
                                        build_name)

            # Update the panel only if copied firmware is correct
            if file_size_panel_build == self.file_size_rpi_build:
                log.info('Validated the firmware size copied on panel {}'.format(self.panel_ip))
                log.info(update_build_cmd)
                update_build_result ,rcode = self.cmd_remote(
                        update_build_cmd,
                        self.panel_ip,
                        self.config['panel']['host_username'],
                        self.config['panel']['host_password'])
                log.info(update_build_result)
            else:
                log.info('The file sizes are not equal or insufficient space to \
                        copy the build to panel \nmethod{}'.format(
                            sys._getframe().f_code.co_name))
        except Exception as error:
            log.error('Getting file size is not equal, error {}'.format(error))
            log.error('Aborting the panel firmware upgrade for panel {}'.format(self.panel_ip))
            FAILURE_LIST.append(self.panel_ip)
            return None

        # Validate panel is upgraded
        self.is_panel_updated()
        sys.exit(1)

    def is_panel_updated(self):
        '''Verifies if a given panel is updated or not'''
        log.info('Verifying if the panel is updated to the given firmware on the panel {}'.format(
                        self.panel_ip))
        try:
            polling.poll(lambda: self.get_panel_version(), step=200, max_tries=15)

            # Restart panel services    
            restart_cmd = 'plink -ssh {}@{} -pw {} /usr/local/bin/procman restart sundance \
                    pumpernickel'.format(
                        self.config['panel']['host_username'],
                        self.panel_ip,
                        self.config['panel']['host_password'])
            log.info("restart cmd %s"% restart_cmd)
            restart_cmd = commands.getoutput(restart_cmd)
            #TODO: Validate output of restart cmd
            log.info("restart_cmd %s"% restart_cmd)
            SUCCESS_LIST.append(self.panel_ip)
        except polling.MaxCallException:
            log.error('Panel is not rebooted within {} seconds \nmethod: {}()'.format(
                        TIME_OUT, 
                        sys._getframe().f_code.co_name))
            log.error('Panel with IP: {} is not updated'.format(self.panel_ip))
            FAILURE_LIST.append(self.panel_ip)
            return False
    
    def delete_panel_db(self):
        '''Verifies the wheather the database is deleted or not in panel'''
        # Delete databases
        log.info('Deleting the database')
        for db in self.config['delete_data_base']:
            db = self.config['delete_data_base'][db]
            delete_db_cmd = 'plink -ssh {}@{} -pw {} rm "/media/extra/db/{}"'.format(
                        self.config['panel']['host_username'],
                        self.panel_ip,
                        self.config['panel']['host_password'],
                        db)
            log.info("delete_db_cmd %s" %  delete_db_cmd)
            rcode,delete_db_cmd = commands.getstatusoutput(delete_db_cmd)
            #TODO: Validate output of delete command
            if rcode:
                log.info('{} database is not present in panel'.format(db))
            else:
                log.info('Output of delete db: {}'.format(delete_db_cmd))

    def get_panel_version(self):
        ''' Verify the panel version after reboot.
        Return:
            bool: True if method secceed, otherwise False
        '''
        log.info('Getting the panel version on the panel {}'.format(self.panel_ip))
        panel_version = ''
        try:
            self.delete_arp_entries()
            try:
                polling.poll(lambda:self.get_ip_address_after_reboot(),step=200,
                    timeout=TIME_OUT)
            except polling.TimeoutException:
                log.error('Failed to the panel ip within the time {} seconds \nmethod: {}()'.format(
                        TIME_OUT,
                        sys._getframe().f_code.co_name))
                log.error('Failed to the panel ip within the time IP: {} is not updated'.format(self.panel_ip))
                return False
            panel_version_cmd = 'echo y | plink -ssh {}@{} -pw {} cat /etc/version'.format(
                self.config['panel']['host_username'],
                self.panel_ip,
                self.config['panel']['host_password'])
            log.info("Panel version command on the panel {} is {}".format(
                            self.panel_ip,
                            panel_version_cmd))
            rcode, panel_version = commands.getstatusoutput(panel_version_cmd)
            if rcode:
                log.error("Failed to get panel version on the panel {}".format(
                        self.panel_ip))
                log.info('Trying again')
                return False
            if self.panel_type == 'wallsly':
                panel_version = panel_version.split('.')
                panel_version_value = panel_version[-1]
                log.info("Panel version = {}".format(panel_version))
            else:
                panel_version = panel_version.strip('Touchlink').split('.')
                panel_version_value = panel_version[-1]
                log.info("Panel version = {}".format(panel_version))
        except Exception as error:
            log.error('Failed to update panel with IP {}'.format(self.panel_ip))
            log.error('Error: {} \nmethod: {}()'.format(error, sys._getframe().f_code.co_name))
            return False
        if panel_version == '':
            log.error('Failed to get firmware version of panel with IP: {}'.format(self.panel_ip))
            log.error('cmd: {}\n, output: {}\n, method: {}()\n'.format(
                'cat /etc/version',
                panel_version,
                sys._getframe().f_code.co_name))
            return False
        else:
            log.info('Panel firmware version on the panel {} is {}'.format(
                        self.panel_ip,
                        panel_version))
        try:
            if self.panel_type == 'wallsly' and args.url != []:
                if len(sys.argv) > 5:
                    if re.search('sly',args.url[0]):
                        self.firmware_path = args.url[0].split('/')[-1]
                    elif re.search('sly',args.url[1]):
                        self.firmware_path = args.url[1].split('/')[-1]
                    else:
                        self.firmware_path = '{}/{}'.format(self.config['firmware_repo']['path'],
                                                self.config['firmware_repo']['wallsly_build'])
                elif len(sys.argv) <=5:
                    print('sly = %s'%args.url[0])
                    if re.search('sly',args.url[0]):
                        self.firmware_path = args.url[0].split('/')[-1]
                        print("self.firmware_path %s"%self.firmware_path)
                    else:
                        self.firmware_path = '{}/{}'.format(self.config['firmware_repo']['path'],
                                                self.config['firmware_repo']['wallsly_build'])
                ini_file_version = self.firmware_path.split('/')[-1]
                log.info('ini_file_version of wallsly is {}'.format(ini_file_version))
                ini_file_version = ini_file_version.split('-')[-1]
                ini_file_version = re.search(r'(.*).rootfs', ini_file_version.split('-')[-1]).group(1).split('.')
            elif self.panel_type == 'skycontrol' and args.url != []:
                if len(sys.argv) > 5: 
                    if re.search('touchlink',args.url[0]):
                        self.firmware_path = args.url[0].split('/')[-1]
                    elif re.search('touchlink',args.url[1]):
                        self.firmware_path = args.url[1].split('/')[-1]
                    else:
                        self.firmware_path = '{}/{}'.format(self.config['firmware_repo']['path'],
                                                self.config['firmware_repo']['sky_build'])
                elif len(sys.argv) <=5:
                    if re.search('touchlink',args.url[0]):
                        self.firmware_path = args.url[0].split('/')[-1]
                    else:
                        self.firmware_path = '{}/{}'.format(self.config['firmware_repo']['path'],
                                                self.config['firmware_repo']['sky_build'])
                log.info('self.firmware_path of skycontrol is {}'.format(self.firmware_path))
                ini_file_version = self.firmware_path.split('/')[-1]
                ini_file_version = ini_file_version.split('-')[-2]
                ini_file_version = ini_file_version.split('.')
            elif self.panel_type == 'wallsly':
                self.firmware_path = '{}/{}'.format(self.config['firmware_repo']['path'],
                                                self.config['firmware_repo']['wallsly_build'])
                ini_file_version = self.firmware_path.split('/')[-1]
                log.info('ini_file_version of wallsly is {}'.format(ini_file_version))
                ini_file_version = ini_file_version.split('-')[-1]
                ini_file_version = re.search(r'(.*).rootfs', ini_file_version.split('-')[-1]).group(1).split('.')
            else:
                self.firmware_path = '{}/{}'.format(self.config['firmware_repo']['path'],
                                                self.config['firmware_repo']['sky_build'])
                log.info('self.firmware_path of skycontrol is {}'.format(self.firmware_path))
                ini_file_version = self.firmware_path.split('/')[-1]
                #ini_file_version = self.config['firmware_repo']['sky_build'].split('/')[-1]
                ini_file_version = ini_file_version.split('-')[-2]
                ini_file_version = ini_file_version.split('.')
            log.info('ini_file_version {}'.format(ini_file_version))
            ini_version = [str(i) for i in ini_file_version]
            last_value = ini_version[-1]
            log.info('last_value {}'.format(last_value))
            if (int(panel_version[0]) == int(ini_version[0])) and (int(panel_version[1]) ==
                    int(ini_version[1])) and (int(panel_version[2]) ==
                            int(ini_version[2])) and (int(panel_version_value) == int(last_value)):
                log.info('Current and new firmware versions are same on the panel {}'.format(
                            self.panel_ip))
                return True

            log.info('Current and new firmware versions are different on the panel {} Trying again, please wait...'.format(
                            self.panel_ip))
            return False
        except Exception as error:
            log.error('Error in fetching panel firmware version on the panel {} is {}'.format(
                            self.panel_ip,
                            error))
            return False

    def delete_arp_entries(self):
        ''' Delete the arp entries in the arp cache
        '''
        log.info('Deleting the arp entries in the arp cache')
        rcode, status = commands.getstatusoutput('echo {} | sudo -S ip -s -s neigh flush all'.format(
                                            self.config['controller']['password']))
        if rcode:
            log.warning('Failed to execute the arp cache command')
        log.info('Deleted the arp entries in the arp cache {}'.format(status))
    
    def get_ip_address_after_reboot(self):
        ''' Verify the wheather panel is getting ip address after reboot 
        Return:
            bool: True if method secceed, otherwise False
        '''
        log.info('Getting panel IP address after reboot')
        panel_list = self.panel_list
        password = self.config['controller']['password']
        mapping = get_ip_address_of_panel(panel_list, password)
        if self.panel_mac in mapping.keys():
            log.info("Panel MAC= {}".format(self.panel_mac))
            self.panel_ip = mapping[self.panel_mac]
            log.info("Panel IP = {}".format(self.panel_ip))
            return True
        log.info('Trying again')
        return False

def get_ip_address_of_panel(panel_list,password):
    ''' Verify the ip address of panel by using the mac address 
    Return:
        bool: True if method secceed, otherwise False
    '''
    panel_ip_list = {}
    mac_pattern = r'..:..:..:..:..:..'
    cmd = 'echo {} | sudo -S arp-scan -l'.format(password)
    rcode,status = commands.getstatusoutput(cmd)
    log.info("status = {}".format(status))
    if rcode:
        raise Exception('Failed to execute the arp-scan command')
    ip_map = {}
    for line in status.splitlines():
        if re.search(mac_pattern, line):
            panel_ip_list[line.split()[1]] = line.split()[0]
    for mac in panel_list:
        ip_map[mac] = panel_ip_list[mac]
    log.info('Mapping of MAC to IP: {}'.format(ip_map))
    return ip_map
        
            
if __name__ == "__main__":
    print("sys.argv = %s"%len(sys.argv))
    config = configparser.ConfigParser()
    parser = argparse.ArgumentParser(description='This script is used to update flash the build to the panel')
    parser.add_argument('-c',help='please mention the .ini file name',type=str)

    if len(sys.argv) > 3:
        parser.add_argument('-u','--ur',nargs='+',action='store',dest='url',default=None,help='<Required> url link',required=True)
        args = parser.parse_args()
    else:
        args = parser.parse_args()
        args.url = []
    
    print config.read('{}'.format(args.c))
    print("args.url =  %s"%args.url)
    url = args.url

    # This code is to download the build from the ftp server

    '''
    username = 'Vivint'
    password = 'viv123'
    server = ftplib.FTP()
    for build in url:
        server.connect('192.168.1.10', 21)
        build = build.split('/')
        path = '/'.join(build[:-1])
        filename = build[-1]
        server.login(username,password)
        server.cwd(path)
        server.retrbinary("RETR " + filename, open(filename, 'wb').write)
        server.quit()
    '''
    
    # This code is to download the panel build from the vivint website

    cwd = os.getcwd() 
    i = 0
    for build in url:
        panel = build.split('/')[-1]
        build = 'wget --no-check-certificate {}'.format(url[i])
        cwd = '{}/{}'.format(cwd,panel)
        print('cwd %s'%cwd)
        status = os.path.exists(cwd)
        if status != True:
            build =  ''.join(map(str, build))
            rcode, status = commands.getstatusoutput(build)
            print 'The status of the given build is {}'.format(status)
            if rcode != 0:
                print 'Failed to download the panel build'
        cwd = '/'.join(cwd.split('/')[:-1])
        print cwd
        i +=1
    
    print 'Given config file is: {}'.format(args.c)

    if not args.c:
        print('Please pass either config file or URL to download')
        print('Passing URL is not supported yet. Please use config file for firmware upgrade')
        print('Format: python panel_firmware_upgrade.py -c <config_file>')
        sys.exit(1)
     
    print '###################################################'
    print 'Starting the panel update with below configurations'
    print '###################################################'
    print("sys.argv %s"%sys.argv)
    if args.url != [] and len(sys.argv) > 5:
        if re.search('sly',args.url[0]) and re.search('sly',args.url[1]):
            raise Exception('The given url is not valid or both urls are related to wallsly')
        elif re.search('touchlink',args.url[0]) and re.search('touchlink',args.url[1]):
            raise Exception('The given url is not valid or both urls are related to skycontrol')

    Keys = config.keys()
    print Keys
    for key in Keys:
        print key
        for name in config[key]:
            print('{} : {}'.format(name,config[key][name]))
    print '###################################################'
    panel_list = config['panels_mac_addr'].values()
    print '\n\n'
    print 'Updating the firmware of below panels'
    print panel_list
    print '\n\n'
    password = config['controller']['password']
    ip_map = get_ip_address_of_panel(panel_list, password)
    print("Mapping of MAC and IP:  {}".format(ip_map))
    ping_count = 10
    threads = []

    for mac in ip_map:
        obj = panel_build(mac, ip_map[mac], config , panel_list)
        try:
            print('Pinging from controller to panel {}'.format(ip_map[mac]))
            ping_cmd = 'ping -c {} {}'.format(ping_count, ip_map[mac])
            ping_output = obj.cmd_local(ping_cmd)
            if ping_output is None:
                print('Ping from manager failed to panel, out: {}'.format(ping_output))
            ping_pkt_loss = re.search(r'(\d+)% packet loss', ping_output)
            if ping_pkt_loss is None:
                print('Ping packet loss not found in ping output')
            print type(ping_pkt_loss.group(1))
            if float(ping_pkt_loss.group(1)) > 80:
                print('Ping loss is greater than 80%. Aborting the update for {}'.format(ip_map[mac]))
                continue
        except Exception as error:
            print('Ping failed for panel {}'.format(ip_map[mac]))
            print error
        t = threading.Thread(target=obj.update_panel_build)
        threads.append(t)

    # Start the threads
    for thread in threads:
        thread.start()

    # Wait for all the thread to complete
    for thread in threads:
        thread.join()

    print SUCCESS_LIST
    print FAILURE_LIST
