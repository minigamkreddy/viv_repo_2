import nose
import polling
import sys
import time
import traceback
import unittest

from nose.plugins.attrib import attr
from run_yofi_test import execution_log_path

sys.path.append("../Lib/SysLib/")
import vivint_logger

from wrapper import Wrapper

class YoFi_Automation_Firmware_Update(unittest.TestCase, Wrapper):
    dtime = time.strftime('%Y-%m-%d_%H-%M-%S', time.localtime())

    def setUp(self):
        Wrapper.__init__(self, self.__class__.__name__ + '_' + self.dtime)
        self.log = vivint_logger.log_formater(__name__)
        self.log.info('======= Test setup started =======')
        self.log.debug('Class name: {}\n'.format(
                                    self.__class__.__name__ + '_' + self.dtime))

        # Clear_all_logs in panel
        status = self.panel.clear_all_panel_logs()
        self.assertTrue(status, 'Clear Panel logs is failed')
        self.log.info('Panel logs are cleared')

        self.panel.clear_logread()

        self.log.info('Clearing dmesg logs')
        self.cntl.cmd_local('echo {} | sudo -S dmesg -c'.format(
            self.config['controller']['password']))

    @attr(test_category='SANITY')
    @attr(test_id='GES_Vivint_Yofi_SAN_0006')
    @nose.allure.severity(nose.allure.severity_level.CRITICAL)
    @nose.allure.feature('Mesh Network with MPP(Yofi), 1 MAP(YoFi) and 1 MAP(Panel) - Linear')
    def test_01_GES_Vivint_Yofi_SAN_0006(self):
        """Mesh Network with MPP(Yofi), 1 MAP(YoFi) and 1 MAP(Panel) - Linear
        :Vivint Testrail ID : C1155390
        :Test Case ID: GES_Vivint_Yofi_SAN_0006
        :author: GES automation dev
        """
        self.log.info('======= Testcase started =======')
        self.testcase_name = sys._getframe().f_code.co_name
        test_case = getattr(self, self.testcase_name)
        self.log_path = '{}{}/{}/'.format(self.config['controller']['log_path'], execution_log_path, test_case.test_category)
        self.log.debug('Fun name: {}\n'.format(self.testcase_name))

        # Creating log directory with testcase_name
        self.log_path_with_test_name =  self.cntl.create_log_dir_with_testcase_name(self.log_path, self.testcase_name)
        self.log.info('Log path of testcase directory: {}'.format(self.log_path_with_test_name))

        status = self.att_obj.set_all_channel_to_high_attenuation(               
                                    self.config['attenuator']['attenuator_1'])   
        self.assertTrue(status, 'Set all channel to high attenuation_1 is failed') 
        self.log.info('Set all channel to high attenuation_1 is successful')

        # Turn on the panel signal in RF box-1                                  
        status = self.att_obj.set_attenuation(self.config['attenuator']['on'],  
                                    self.config['attenuator']['channel_1'],     
                                    self.config['attenuator']['attenuator_1'])  
        self.assertTrue(status, 'Passing panel signal in RF box-1 is failed')   
        self.attenuator_1 = True

        '''
        # Turn on the panel signal in RF box-1                                  
        status = self.att_obj.set_attenuation('20',  
                                    self.config['attenuator']['channel_1'],     
                                    self.config['attenuator']['attenuator_1'])  
        self.assertTrue(status, 'Passing panel signal in RF box-1 is failed')   
        self.attenuator_1 = True
        '''
        # Configure panel as MPP
        self.panel_mpp_ip = self.configure_mpp(self.panel)
        self.assertTrue(self.panel_mpp_ip, 'get MPP IP address is failed')

        # Get mesh ID and psk from panel
        status = self.panel.get_mesh_id_and_psk()                                
        self.assertTrue(status, 'Failed to get mesh_id and wps_psk')

        # Gets the yofi-1 instance
        self.get_yofi_instance('yofi-1')

        # Start sniffer_1 capture                                                  
        if self.config['sniffer_1']['enable'].lower() == 'true':
            status = self.start_sniffer_capture('sniffer_1', '5', 'adding_yofi_1_to_panel', sniffer_flag=False)
            self.assertTrue(status, 'Sniffer_1 start is failed')

        # Configure yofi as MPP
        self.yofi_mpp_ip = self.configure_mpp(self.yofi)
        self.assertTrue(self.yofi_mpp_ip, 'Getting MPP IP address is failed')

        # Stop sniffer_1 capture
        if self.config['sniffer_1']['enable'].lower() == 'true':
            status = self.stop_sniffer_capture('sniffer_1')
            self.assertTrue(status, 'Sniffer_1 stop is failed')
        add_yofi_1_pcap_in_5  = self.multiple_sniffer_handler['sniffer_1']['pcap_filename']

        # Start sniffer_1 capture                                                  
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_1', '5', 'valiadtion')
            self.assertTrue(status, 'Sniffer_1 start is failed')                 
                                                                                 
        # TODO RSSI of panel should less than -60, RSSI of YoFi-1 should not available or more than -70
        # If not work do attenuate 30dB instead of 0dB
        exp_mac_list = [self.config['panel']['ap_mac_addr'], self.config['panel']['sta_mac_addr']]
        unexp_mac_list = [self.config['yofi-1']['mac'], self.config['yofi-1']['mac_for_wps_check']]
        status = self.cntl.get_signal_strength_in_controller(
                        self.config['controller']['rf1_wireless_adapter_mac'],
                        exp_mac_list, unexp_mac_list)
        #self.assertTrue(status, 'Getting RSSI value in RF box-1 is failed')

        # Gets the yofi-3 instance
        self.get_yofi_instance('yofi-3')

        # get panel map channel                                                  
        panel_map_channel_5 = self.panel.get_channel('wlan0', self.panel_map_ip)   
        self.assertTrue(panel_map_channel_5, 'Getting panel channel on wlan0 is failed')

        # Start sniffer_3 capture                                                  
        if self.config['sniffer_3']['enable'].lower() == 'true':
            status = self.start_sniffer_capture('sniffer_3', '5', 'adding_yofi_3_to_panel', panel_map_channel_5)
            self.assertTrue(status, 'Sniffer_3 start is failed')

        # get panel map channel                                                  
        panel_map_channel_24 = self.panel.get_channel('wlan1', self.panel_map_ip)   
        self.assertTrue(panel_map_channel_24, 'Getting panel channel on wlan1 is failed')

        # Start sniffer_4 capture
        if self.config['sniffer_4']['enable'].lower() == 'true':
            status = self.start_sniffer_capture('sniffer_4', '2.4', 'adding_yofi_3_to_panel', panel_map_channel_24)
            self.assertTrue(status, 'Sniffer_4 start is failed')

        # Add yofi-3
        status = self.add_yofi_node_to_panel('wps', self.panel_map_ip)
        self.assertTrue(status, 'yofi-3 addition is failed')
        self.log.info('yofi-3 addition is succeeded')

        # Stop sniffer_4 capture
        if self.config['sniffer_4']['enable'].lower() == 'true':
            status = self.stop_sniffer_capture('sniffer_4')
            self.assertTrue(status, 'Sniffer_4 stop is failed')
        add_yofi_3_pcap_in_24  = self.multiple_sniffer_handler['sniffer_4']['pcap_filename']

        # Stop sniffer_3 capture
        if self.config['sniffer_3']['enable'].lower() == 'true':
            status = self.stop_sniffer_capture('sniffer_3')
            self.assertTrue(status, 'Sniffer_3 stop is failed')
        add_yofi_3_pcap_in_5  = self.multiple_sniffer_handler['sniffer_3']['pcap_filename']

        # Start sniffer_3 capture                                                  
        if self.config['sniffer_3']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_3', '5', 'rf_1_valiadtion')
            self.assertTrue(status, 'Sniffer_3 start is failed')                 
                                                                                 
        # Verify YoFi-3 node is MAP mesh type
        status = self.yofi.is_mesh_node_map()
        self.assertTrue(status, 'YoFi-3 is not in MAP mode')
        self.log.info('YoFi-3 is in MAP mode')

        # Verify panel node is MAP mesh type
        status = self.panel.is_mesh_node_map(self.panel_map_ip)
        self.assertTrue(status, 'Panel is not in MAP mode')
        self.log.info('Panel is in MAP mode')

        # Gets the yofi-1 instance
        yofi_type = 'yofi-1'
        self.get_yofi_config(yofi_type)
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']

        # Verify YoFi-1 node is MPP mesh type
        status = self.yofi.is_mesh_node_mpp()
        self.assertTrue(status, 'YoFi-1 is not in MPP mode')
        self.log.info('YoFi-1 is in MPP mode')

        # Ping from Yofi-1(MPP) to Panel(MAP)
        status = self.yofi.ping(self.panel_map_ip)
        #self.assertTrue(status, 'Ping from YoFi-1(MPP) to panel(MAP) is failed')
        self.log.info('Ping from YoFi-1(MPP) to panel(MAP) is successfull')

        # Ping from Yofi-1(MPP) to Yofi-3(MAP)
        yofi_map_ip = self.multiple_yofi_handler['yofi-3']['yofi_ip']
        status = self.yofi.ping(yofi_map_ip)
        # TODO 
        #self.assertTrue(status, 'Ping from YoFi-1(MPP) to YoFi-3(MAP) is failed')
        self.log.info('Ping from YoFi-1(MPP) to YoFi-3(MAP) is successfull')

        # Ping from Panel(MAP) to Yofi-3(MAP)
        status = self.panel.ping(yofi_map_ip)
        #self.assertTrue(status, 'Ping from panel(MAP) to YoFi-3(MAP) is failed')
        self.log.info('Ping from panel(MAP) to YoFi-3(MAP) is successfull')

        # Ping from Panel(MAP) to Yofi-1(MPP)
        status = self.panel.ping(self.config['panel']['nw_br_lan_ip'])
        #self.assertTrue(status, 'Ping from panel(MAP) to YoFi-1(MPP) is failed')
        self.log.info('Ping from panel(MAP) to YoFi-1(MPP) is successfull')
  
        # Gets the yofi-3 instance
        yofi_type = 'yofi-3'
        self.get_yofi_config(yofi_type)
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']

        # Ping from Yofi-3(MAP) to Panel(MAP)
        status = self.yofi.ping(self.panel_map_ip)
        #self.assertTrue(status, 'Ping from YoFi-3(MPP) to panel(MAP) is failed')
        self.log.info('Ping from YoFi-3(MAP) to panel(MAP) is successfull')

        # Ping from Yofi-3(MAP) to Yofi-1(MPP)
        status = self.yofi.ping(self.config['panel']['nw_br_lan_ip'])
        # TODO
        #self.assertTrue(status, 'Ping from yofi-3(MAP) to YoFi-1(MPP) is failed')
        self.log.info('Ping from Yofi-3(MAP) to YoFi-1(MPP) is successfull')

        # Get mesh graph .svg file from panel if this flag True
        self.mesh_graph_flag = True

        # Gets the yofi-1 instance
        yofi_type = 'yofi-1'
        self.get_yofi_config(yofi_type)
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']

        # Topology check in MPP-YoFi-1
        status = self.verify_station_dump(self.yofi, self.config['panel']['sta_mac_addr'])
        self.assertTrue(status, 'Station dump check in YoFi is failed')
        self.log.info('Station dump check on mesh interface in YoFi is succeeded')

        # Topology check in MPP-YoFi-1
        status = self.verify_station_dump(self.yofi, self.config['yofi-3']['mac'])
        # TODO yofi-3 entry should not found
        #self.assertTrue(status, 'Station dump check in YoFi is failed')
        self.log.info('Station dump check on mesh interface in YoFi is succeeded')

        # Topology check in panel MAP                                            
        status = self.verify_station_dump(self.panel, self.config['yofi-3']['mac'], panel_map_ip=self.panel_map_ip)
        self.assertTrue(status, 'Station dump check in Panel is failed')         
        self.log.info('Station dump check on mesh interface in Panel is succeeded')
                                                                                 
        # Topology check in Panel MAP                                            
        status = self.verify_station_dump(self.panel, self.config['yofi']['mac'], panel_map_ip=self.panel_map_ip)
        self.assertTrue(status, 'Station dump check in Panel is failed')         
        self.log.info('Station dump check on mesh interface in Panel is succeeded')

        # Gets the yofi-3 instance
        yofi_type = 'yofi-3'
        self.get_yofi_config(yofi_type)
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']

        # Topology check in MAP-YoFi-3
        status = self.verify_station_dump(self.yofi, self.config['panel']['sta_mac_addr'])
        self.assertTrue(status, 'Station dump check in YoFi is failed')
        self.log.info('Station dump check on mesh interface in YoFi is succeeded')

        # Topology check in MAP-YoFi-3
        status = self.verify_station_dump(self.yofi, self.config['yofi-1']['mac'])
        # TODO yofi-1 entry should not found
        #self.assertTrue(status, 'Station dump check in YoFi is failed')
        self.log.info('Station dump check on mesh interface in YoFi is succeeded')

        # TODO RSSI of panel should less than -60, RSSI of YoFi-1 should not available or more than -70
        # If not work do attenuate 30dB instead of 0dB
        exp_mac_list = [self.config['panel']['ap_mac_addr'], self.config['panel']['sta_mac_addr']]
        unexp_mac_list = [self.config['yofi-1']['mac'], self.config['yofi-1']['mac_for_wps_check']]
        status = self.cntl.get_signal_strength_in_controller(
                        self.config['controller']['rf1_wireless_adapter_mac'],
                        exp_mac_list, unexp_mac_list)
        #self.assertTrue(status, 'Getting RSSI value in RF box-1 is failed')

        exp_mac_list = [self.config['panel']['ap_mac_addr'], self.config['panel']['sta_mac_addr']]
        unexp_mac_list = [self.config['yofi-3']['mac'], self.config['yofi-3']['mac_for_wps_check']]
        status = self.cntl.get_signal_strength_in_controller(
                        self.config['controller']['outside_wireless_adapter_mac'],
                        exp_mac_list, unexp_mac_list)
        #self.assertTrue(status, 'Getting RSSI value is failed')

        # TODO If fails, Do attenuate 20dB and check again

        # Check the linear topology using mpath dump, next hop node mac and dest node mac
        self.yofi.verify_linear_topology(self.config['panel']['sta_mac_addr'], self.config['yofi-1']['mac'])

        # Netv assoc for 5GHz
        self.display_mesh_node_connection_status(self.config['panel']['sta_mac_addr'])

        # Stop sniffer_1 capture
        if self.config['sniffer_1']['enable'].lower() == 'true':
            status = self.stop_sniffer_capture('sniffer_1')
            self.assertTrue(status, 'Sniffer_1 stop is failed')
        validation_5  = self.multiple_sniffer_handler['sniffer_1']['pcap_filename']

        # Stop sniffer_3 capture
        if self.config['sniffer_3']['enable'].lower() == 'true':
            status = self.stop_sniffer_capture('sniffer_3')
            self.assertTrue(status, 'Sniffer_3 stop is failed')
        rf_1_validation_5 = self.multiple_sniffer_handler['sniffer_3']['pcap_filename']

        self.get_sniffer_utility_instance()

        panel_sta_mac = self.config['panel']['sta_mac_addr']
        yofi_1_mac = self.config['yofi-1']['mac']
        yofi_3_mac = self.config['yofi-3']['mac']
        panel_ap_mac = self.config['panel']['ap_mac_addr']
        yofi_1_mac_for_24 = self.config['yofi-1']['mac_for_wps_check']
        yofi_3_mac_for_24 = self.config['yofi-3']['mac_for_wps_check']

        # Sniffer_1 frame analysis                                               
        self.log.info('Sniffer_1 analysis between YoFi-1(MPP) and panel(MAP)')   
        self.log.info('Sniffer_1 pcap file: {}'.format(add_yofi_1_pcap_in_5))    
        status = self.sniffer_analysis.validate_MPP_and_MAP_connection_with_sae_and_peer_action_frames(add_yofi_1_pcap_in_5, yofi_1_mac, panel_sta_mac)
                                                                                 
        # Sniffer_3 frame analysis                                               
        self.log.info('Sniffer_3 analysis between YoFi-3(MAP) and panel(MAP)')   
        self.log.info('Sniffer_3 pcap file: {}'.format(add_yofi_3_pcap_in_5))    
        status = self.sniffer_analysis.validate_MPP_and_MAP_connection_with_sae_and_peer_action_frames(add_yofi_3_pcap_in_5, yofi_3_mac, panel_sta_mac)
                                                                                 
        # Sniffer_4 frame analysis, Source Mac should be STA (YoFi)                                       
        self.log.info('Sniffer_4 analysis between YoFi-3(MAP) and panel(MAP)')   
        self.log.info('Sniffer_4 pcap file: {}'.format(add_yofi_3_pcap_in_24))   
        status = self.sniffer_analysis.wps_connect(add_yofi_3_pcap_in_24, yofi_3_mac_for_24, panel_ap_mac)
                                                                                 
    @attr(test_category='SANITY')
    @attr(test_id='GES_Vivint_Yofi_SAN_0016')
    @nose.allure.severity(nose.allure.severity_level.CRITICAL)
    @nose.allure.feature('Wireless Connection between Panel and Cams with MPP(Yofi) and MP(YoFi), MAP(Panel ) - Linear Topology')
    def test_02_GES_Vivint_Yofi_SAN_0016(self):
        """Wireless Connection between Panel and Cams with MPP(Yofi) and MP(YoFi), MAP(Panel ) - Linear Topology
        :Vivint Testrail ID: C1155400
        :Test Case ID: GES_Vivint_Yofi_SAN_0016
        :author: GES automation dev
        """
        self.log.info('======= Testcase started =======')
        self.testcase_name = sys._getframe().f_code.co_name
        test_case = getattr(self, self.testcase_name)
        self.log_path = '{}{}/{}/'.format(self.config['controller']['log_path'], execution_log_path, test_case.test_category)
        self.log.debug('Fun name: {}\n'.format(self.testcase_name))

        # Creating log directory with testcase_name
        self.log_path_with_test_name =  self.cntl.create_log_dir_with_testcase_name(self.log_path, self.testcase_name)
        self.log.info('Log path of testcase directory: {}'.format(self.log_path_with_test_name))

        camera_type_list = ['dbc_camera_1', 'hd400w_camera', 'hd300w_camera',    
                            'ping_camera_2', 'hdp450_camera', 'ping_camera_1']    
        self.check_cameras_in_ap_mode(camera_type_list)

        status = self.att_obj.set_all_channel_to_high_attenuation(               
                                    self.config['attenuator']['attenuator_1'])   
        self.assertTrue(status, 'Set all channel to high attenuation_1 is failed') 
        self.log.info('Set all channel to high attenuation_1 is successful')

        status = self.att_obj.set_all_channel_to_high_attenuation(               
                                    self.config['attenuator']['attenuator_2'])   
        self.assertTrue(status, 'Set all channel to high attenuation_2 is failed') 
        self.log.info('Set all channel to high attenuation_2 is successful')

        # Turn on the panel signal in RF box-1                                  
        status = self.att_obj.set_attenuation(self.config['attenuator']['on'],  
                                    self.config['attenuator']['channel_1'],     
                                    self.config['attenuator']['attenuator_1'])  
        self.assertTrue(status, 'Passing panel signal in RF box-1 is failed')   
        self.attenuator_1 = True

        # Turn on the panel signal in RF box-2                                  
        status = self.att_obj.set_attenuation(self.config['attenuator']['on'],  
                                    self.config['attenuator']['channel_2'],     
                                    self.config['attenuator']['attenuator_1'])  
        self.assertTrue(status, 'Passing panel signal in RF box-2 is failed')   
        self.attenuator_2 = True

        # Configure panel as MPP                                                 
        self.panel_mpp_ip = self.configure_mpp(self.panel)                       
        self.assertTrue(self.panel_mpp_ip, 'get MPP IP address is failed')       
                                                                                 
        # Get mesh ID and psk from panel                                         
        status = self.panel.get_mesh_id_and_psk()                                
        self.assertTrue(status, 'Failed to get mesh_id and wps_psk')             
                                                                                 
        # Start sniffer_2 capture                                                  
        if self.config['sniffer_2']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_2', '2.4', 'add_camera')
            self.assertTrue(status, 'Sniffer_2 start is failed')                 
                                                                                 
        # Select the PCI card                                                    
        self.log.info('Outside wireless adapter mac: {}'.format(                 
                                self.config['controller']['outside_wireless_adapter_mac']))
        self.cntl.pci_mac=self.config['controller']['outside_wireless_adapter_mac']
                                                                                 
        # Gets the camera instance                                               
        self.get_camera_instance('dbc_camera_1')                                 
                                                                                 
        # Add Camera                                                             
        status = self.add_camera_to_panel('wps')                                 
        self.assertTrue(status, 'camera addition is failed')                     
        self.log.info('camera addition is succeeded')                            
                                                                                 
        # Gets the camera instance                                               
        self.get_camera_instance('hd400w_camera')                                
                                                                                 
        # Add Camera                                                             
        status = self.add_camera_to_panel('wps')                                 
        self.assertTrue(status, 'camera addition is failed')                     
        self.log.info('camera addition is succeeded')                            
                                                                                 
        # Gets the camera instance                                               
        self.get_camera_instance('hd300w_camera')                                
                                                                                 
        # Add Camera                                                             
        status = self.add_camera_to_panel('wps')                                 
        self.assertTrue(status, 'camera addition is failed')                     
        self.log.info('camera addition is succeeded')

        # Select the PCI card                                                    
        self.log.info('RF-1 wireless adapter card: {}'.format(                   
                                self.config['controller']['rf1_wireless_adapter_mac']))
        self.cntl.pci_mac=self.config['controller']['rf1_wireless_adapter_mac']  
                                                                                 
        # Start sniffer_4 capture                                                  
        if self.config['sniffer_4']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_4', '2.4', 'rf_1_add_camera')
            self.assertTrue(status, 'Sniffer_4 start is failed')                 
                                                                                 
        # Adding hyrax camera, Support JIRA ID: AUTO-7346
        # Gets the camera instance                                               
        self.get_camera_instance('ping_camera_1')                                
                                                                                 
        # Add Camera                                                             
        status = self.add_camera_to_panel('wps')                                 
        self.assertTrue(status, 'camera addition is failed')                     
        self.log.info('camera addition is succeeded')                            
                                                                                 
        # Select the PCI card                                                    
        self.log.info('RF-2 wireless adapter card: {}'.format(                   
                      self.config['controller']['rf2_wireless_adapter_mac']))
        self.cntl.pci_mac=self.config['controller']['rf2_wireless_adapter_mac']  
                                                                                 
        # Start sniffer_5 capture                                                  
        if self.config['sniffer_5']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_5', '2.4', 'rf_2_add_camera')
            self.assertTrue(status, 'Sniffer_5 start is failed')                 
                                                                                 
        # Gets the camera instance                                               
        self.get_camera_instance('hdp450_camera')                                
                                                                                 
        # Add Camera                                                             
        status = self.add_camera_to_panel('wps')                                 
        self.assertTrue(status, 'camera addition is failed')                     
        self.log.info('camera addition is succeeded')                            
                                                                                 
        # Gets the camera instance                                               
        self.get_camera_instance('ping_camera_2')                                
                                                                                 
        # Add Camera                                                             
        status = self.add_camera_to_panel('wps')                                 
        self.assertTrue(status, 'camera addition is failed')                     
        self.log.info('camera addition is succeeded')                            
                                                                                 
        # Stop sniffer_2 capture                                                 
        if self.config['sniffer_2']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_2')                      
            self.assertTrue(status, 'Sniffer_2 stop is failed')                  
        add_camera_pcap = self.multiple_sniffer_handler['sniffer_2']['pcap_filename']
                                                                                 
        # Stop sniffer_4 capture                                                 
        if self.config['sniffer_4']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_4')                      
            self.assertTrue(status, 'Sniffer_4 stop is failed')                  
        rf_1_add_camera_pcap = self.multiple_sniffer_handler['sniffer_4']['pcap_filename']
                                                                                 
        # Stop sniffer_5 capture                                                 
        if self.config['sniffer_5']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_5')                      
            self.assertTrue(status, 'Sniffer_5 stop is failed')                  
        rf_2_add_camera_pcap = self.multiple_sniffer_handler['sniffer_5']['pcap_filename']
                                                                                 
        # Gets the yofi-1 instance                                               
        self.get_yofi_instance('yofi-1')

        # Start sniffer_1 capture                                                  
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_1', '5', 'adding_yofi_1_to_panel', sniffer_flag=False)
            self.assertTrue(status, 'Sniffer_1 start is failed')                 
                                                                                 
        # Configure yofi as MPP                                                  
        self.yofi_mpp_ip = self.configure_mpp(self.yofi)                         
        self.assertTrue(self.yofi_mpp_ip, 'Getting MPP IP address is failed')    
                                                                                 
        # Stop sniffer_1 capture                                                 
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_1')                      
            self.assertTrue(status, 'Sniffer_1 stop is failed')                  
        add_yofi_1_pcap_in_5  = self.multiple_sniffer_handler['sniffer_1']['pcap_filename']
                                                                                 
        # TODO RSSI of panel should less than -60, RSSI of YoFi-1 should not available or more than -70
        # If not work do attenuate 30dB instead of 0dB
        exp_mac_list = [self.config['panel']['ap_mac_addr'], self.config['panel']['sta_mac_addr']]
        unexp_mac_list = [self.config['yofi-1']['mac'], self.config['yofi-1']['mac_for_wps_check']]
        status = self.cntl.get_signal_strength_in_controller(
                        self.config['controller']['rf1_wireless_adapter_mac'],
                        exp_mac_list, unexp_mac_list)
        #self.assertTrue(status, 'Getting RSSI value in RF box-1 is failed')

        # Start sniffer_1 capture                                                  
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_1', '5', 'valiadtion')
            self.assertTrue(status, 'Sniffer_1 start is failed')                 
                                                                                 
        # Gets the yofi-3 instance
        self.get_yofi_instance('yofi-3')

        # get panel map channel                                                  
        panel_map_channel_5 = self.panel.get_channel('wlan0', self.panel_map_ip)   
        self.assertTrue(panel_map_channel_5, 'Getting panel channel on wlan0 is failed')

        # Start sniffer_3 capture                                                  
        if self.config['sniffer_3']['enable'].lower() == 'true':
            status = self.start_sniffer_capture('sniffer_3', '5', 'adding_yofi_3_to_panel', panel_map_channel_5)
            self.assertTrue(status, 'Sniffer_3 start is failed')

        # get panel map channel                                                  
        panel_map_channel_24 = self.panel.get_channel('wlan1', self.panel_map_ip)   
        self.assertTrue(panel_map_channel_24, 'Getting panel channel on wlan1 is failed')

        # Start sniffer_4 capture
        if self.config['sniffer_4']['enable'].lower() == 'true':
            status = self.start_sniffer_capture('sniffer_4', '2.4', 'adding_yofi_3_to_panel', panel_map_channel_24)
            self.assertTrue(status, 'Sniffer_4 start is failed')

        # Add yofi-3
        status = self.add_yofi_node_to_panel('wps', self.panel_map_ip)
        self.assertTrue(status, 'yofi-3 addition is failed')
        self.log.info('yofi-3 addition is succeeded')

        # Stop sniffer_4 capture
        if self.config['sniffer_4']['enable'].lower() == 'true':
            status = self.stop_sniffer_capture('sniffer_4')
            self.assertTrue(status, 'Sniffer_4 stop is failed')
        add_yofi_3_pcap_in_24  = self.multiple_sniffer_handler['sniffer_4']['pcap_filename']

        # Stop sniffer_3 capture                                                 
        if self.config['sniffer_3']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_3')                      
            self.assertTrue(status, 'Sniffer_3 stop is failed')                  
        add_yofi_3_pcap_in_5 = self.multiple_sniffer_handler['sniffer_3']['pcap_filename']
                                                                                 
        # Start sniffer_3 capture                                                  
        if self.config['sniffer_3']['enable'].lower() == 'true':
            status = self.start_sniffer_capture('sniffer_3', '5', 'rf_1_linear')
            self.assertTrue(status, 'Sniffer_3 start is failed')

        # get panel map channel                                                  
        panel_map_channel = self.panel.get_channel('wlan1', self.panel_map_ip)   
        self.assertTrue(panel_map_channel, 'Getting panel channel is failed')    
                                                                                 
        # Start sniffer_4 capture                                                
        if self.config['sniffer_4']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_4', '2.4', 'rf_1_camera_switch', panel_map_channel)
            self.assertTrue(status, 'Sniffer_4 start is failed')                 
                                                                                 
        # Get channel from YoFi-3                                                
        yofi_3_channel = self.yofi.get_channel('wlan1')                          
        self.assertTrue(yofi_3_channel, 'Getting YoFi-3 2.4GHz channel is failed')
                                                                                 
        # Start sniffer_5 capture                                                
        if self.config['sniffer_5']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_5', '2.4', 'rf_2_camera_switch', yofi_3_channel)
            self.assertTrue(status, 'Sniffer_5 start is failed')                 
                                                                                 
        # Turn off the panel signal in RF box-2                                  
        status = self.att_obj.set_attenuation(self.config['attenuator']['off'],  
                                    self.config['attenuator']['channel_2'],      
                                    self.config['attenuator']['attenuator_1'])
        self.assertTrue(status, 'Blocking panel signal in RF box-2 is failed')   
                                                                                 
        time.sleep(10)                                                           
                                                                                 
        # Turn on the YoFi-3 signal in RF box-2                                  
        status = self.att_obj.set_attenuation(self.config['attenuator']['on'],   
                                    self.config['attenuator']['channel_3'],      
                                    self.config['attenuator']['attenuator_2'])   
        self.assertTrue(status, 'Passing YoFi-3 signal in RF box-2 is failed')   
                                                                                 
        # Verify YoFi-3 node is MAP mesh type
        status = self.yofi.is_mesh_node_map()
        self.assertTrue(status, 'YoFi-3 is not in MAP mode')
        self.log.info('YoFi-3 is in MAP mode')

        # Verify panel node is MAP mesh type                                     
        status = self.panel.is_mesh_node_map(self.panel_map_ip)                  
        self.assertTrue(status, 'Panel is not in MAP mode')                      
        self.log.info('Panel is in MAP mode')                                    
                                                                                 
        yofi_type = 'yofi-1'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']              
                                                                                 
        # Verify YoFi-1 node is MPP mesh type                                    
        status = self.yofi.is_mesh_node_mpp()                                    
        self.assertTrue(status, 'YoFi-1 is not in MPP mode')                     
        self.log.info('YoFi-1 is in MPP mode')                                   
                                                                                 
        # Ping from Yofi-1(MPP) to Panel(MAP)
        status = self.yofi.ping(self.panel_map_ip)
        #self.assertTrue(status, 'Ping from YoFi-1(MPP) to panel(MAP) is failed')
        self.log.info('Ping from YoFi-1(MPP) to panel(MAP) is successfull')

        # Ping from Yofi-1(MPP) to Yofi-3(MAP)
        yofi_map_ip = self.multiple_yofi_handler['yofi-3']['yofi_ip']
        status = self.yofi.ping(yofi_map_ip)
        # TODO
        #self.assertTrue(status, 'Ping from YoFi-1(MPP) to YoFi-3(MAP) is failed')
        self.log.info('Ping from YoFi-1(MPP) to YoFi-3(MAP) is successfull')

        # Ping from Panel(MAP) to Yofi-3(MAP)
        status = self.panel.ping(yofi_map_ip)
        #self.assertTrue(status, 'Ping from panel(MAP) to YoFi-3(MAP) is failed')
        self.log.info('Ping from panel(MAP) to YoFi-3(MAP) is successfull')

        # Ping from Panel(MAP) to Yofi-1(MPP)
        status = self.panel.ping(self.config['panel']['nw_br_lan_ip'])
        #self.assertTrue(status, 'Ping from panel(MAP) to YoFi-1(MPP) is failed')
        self.log.info('Ping from panel(MAP) to YoFi-1(MPP) is successfull')
  
        # Gets the yofi-3 instance
        yofi_type = 'yofi-3'
        self.get_yofi_config(yofi_type)
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']

        # Ping from Yofi-3(MAP) to Panel(MAP)
        status = self.yofi.ping(self.panel_map_ip)
        #self.assertTrue(status, 'Ping from YoFi-3(MPP) to panel(MAP) is failed')
        self.log.info('Ping from YoFi-3(MAP) to panel(MAP) is successfull')

        # Ping from Yofi-3(MAP) to Yofi-1(MPP)
        status = self.yofi.ping(self.config['panel']['nw_br_lan_ip'])
        # TODO
        #self.assertTrue(status, 'Ping from yofi-3(MAP) to YoFi-1(MPP) is failed')
        self.log.info('Ping from Yofi-3(MAP) to YoFi-1(MPP) is successfull')

        # Get mesh graph .svg file from panel if this flag True
        self.mesh_graph_flag = True

        # Gets the yofi-1 instance
        yofi_type = 'yofi-1'
        self.get_yofi_config(yofi_type)
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']

        # Topology check in MPP-YoFi-1
        status = self.verify_station_dump(self.yofi, self.config['panel']['sta_mac_addr'])
        self.assertTrue(status, 'Station dump check in YoFi is failed')
        self.log.info('Station dump check on mesh interface in YoFi is succeeded')

        # Topology check in MPP-YoFi-1
        status = self.verify_station_dump(self.yofi, self.config['yofi-3']['mac'])
        # TODO yofi-3 entry should not found
        #self.assertTrue(status, 'Station dump check in YoFi is failed')
        self.log.info('Station dump check on mesh interface in YoFi is succeeded')

        # Topology check in panel MAP                                            
        status = self.verify_station_dump(self.panel, self.config['yofi-3']['mac'], panel_map_ip=self.panel_map_ip)
        self.assertTrue(status, 'Station dump check in Panel is failed')         
        self.log.info('Station dump check on mesh interface in Panel is succeeded')
                                                                                 
        # Topology check in Panel MAP                                            
        status = self.verify_station_dump(self.panel, self.config['yofi']['mac'], panel_map_ip=self.panel_map_ip)
        self.assertTrue(status, 'Station dump check in Panel is failed')         
        self.log.info('Station dump check on mesh interface in Panel is succeeded')

        # Gets the yofi-3 instance
        yofi_type = 'yofi-3'
        self.get_yofi_config(yofi_type)
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']

        # Topology check in MAP-YoFi-3
        status = self.verify_station_dump(self.yofi, self.config['panel']['sta_mac_addr'])
        self.assertTrue(status, 'Station dump check in YoFi is failed')
        self.log.info('Station dump check on mesh interface in YoFi is succeeded')

        # Topology check in MAP-YoFi-3
        status = self.verify_station_dump(self.yofi, self.config['yofi-1']['mac'])
        # TODO yofi-1 entry should not found
        #self.assertTrue(status, 'Station dump check in YoFi is failed')
        self.log.info('Station dump check on mesh interface in YoFi is succeeded')

        # TODO RSSI of panel should less than -60, RSSI of YoFi-1 should not available or more than -70
        # If not work do attenuate 30dB instead of 0dB
        exp_mac_list = [self.config['panel']['ap_mac_addr'], self.config['panel']['sta_mac_addr']]
        unexp_mac_list = [self.config['yofi-2']['mac'], self.config['yofi-2']['mac_for_wps_check']]
        status = self.cntl.get_signal_strength_in_controller(
                        self.config['controller']['rf1_wireless_adapter_mac'],
                        exp_mac_list, unexp_mac_list)
        #self.assertTrue(status, 'Getting RSSI value in RF box-1 is failed')

        exp_mac_list = [self.config['panel']['ap_mac_addr'], self.config['panel']['sta_mac_addr']]
        unexp_mac_list = [self.config['yofi-3']['mac'], self.config['yofi-3']['mac_for_wps_check']]
        status = self.cntl.get_signal_strength_in_controller(
                        self.config['controller']['outside_wireless_adapter_mac'],
                        exp_mac_list, unexp_mac_list)
        #self.assertTrue(status, 'Getting RSSI value is failed')

        # TODO If fails, Do attenuate 20dB and check again

        # Check the linear topology using mpath dump, next hop node mac and dest node mac
        self.yofi.verify_linear_topology(self.config['panel']['sta_mac_addr'], self.config['yofi-1']['mac'])
        # TODO 
        #self.assertTrue(status, 'Linear topology check in YoFi-3 is failed')
                                                                                 
        # Netv assoc for 5GHz
        self.display_mesh_node_connection_status(self.config['panel']['sta_mac_addr'])

        # Displays the where the camera is connected using netv assoc 2.4         
        status = self.display_camera_connection_status(self.config['camera']['mac'])
        self.log.info('Display cameras connection status in YoFi-3 MAP')         
                                                                                 
        # Stop sniffer_1 capture                                                 
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_1')                      
            self.assertTrue(status, 'Sniffer_1 stop is failed')                  
        validation_5 = self.multiple_sniffer_handler['sniffer_1']['pcap_filename']
                                                                                 
        # Stop sniffer_3 capture                                                 
        if self.config['sniffer_3']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_3')                      
            self.assertTrue(status, 'Sniffer_3 stop is failed')                  
        rf_1_linear_validation = self.multiple_sniffer_handler['sniffer_3']['pcap_filename']
                                                                                 
        # Start sniffer_1 capture                                                  
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_1', '5', 'camera_switch')
            self.assertTrue(status, 'Sniffer_1 start is failed')                 
                                                                                 
        # Start sniffer_3 capture                                                  
        if self.config['sniffer_3']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_3', '5', 'rf_1_camera_switch')
            self.assertTrue(status, 'Sniffer_3 start is failed')                 
                                                                                 
        # get panel map channel                                                  
        panel_map_channel = self.panel.get_channel('wlan1', self.panel_map_ip)   
        self.assertTrue(panel_map_channel, 'Getting panel channel is failed')    
                                                                                 
        # Start sniffer_2 capture                                                
        if self.config['sniffer_2']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_2', '2.4', 'camera_switch', panel_map_channel)
            self.assertTrue(status, 'Sniffer_2 start is failed')                 
                                                                                 
        # Connecting camera to panel using bssid                                 
        self.connect_camera_to_panel('dbc_camera_1', self.config['panel']['ap_mac_addr'], panel_ip=self.panel_map_ip)
                                                                                 
        # Connecting camera to panel using bssid                                 
        self.connect_camera_to_panel('hd400w_camera', self.config['panel']['ap_mac_addr'], panel_ip=self.panel_map_ip)
                                                                                 
        # Connecting camera to panel using bssid                                 
        self.connect_camera_to_panel('hd300w_camera', self.config['panel']['ap_mac_addr'], panel_ip=self.panel_map_ip)

        # Connecting camera to panel using bssid                                 
        self.connect_camera_to_panel('ping_camera_1', self.config['panel']['ap_mac_addr'], panel_ip=self.panel_map_ip)

        # Get YoFi config                                                        
        yofi_type = 'yofi-3'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']

        self.get_camera_config('ping_camera_2')                                  
                                                                                 
        # Topology check in MPP-YoFi, Camera should connected to YoFi            
        status = self.verify_station_dump(self.yofi, self.config['camera']['mac'], 'wlan1')
        self.assertTrue(status, 'Station dump check in YoFi is failed')          
        self.log.info('Station dump check on 2.4GHz interface in YoFi is succeeded')
                                                                                 
        self.get_camera_config('hdp450_camera')                                  
                                                                                 
        # Topology check in MPP-YoFi, Camera should connected to YoFi            
        status = self.verify_station_dump(self.yofi, self.config['camera']['bridge_mac'], 'wlan1')
        self.assertTrue(status, 'Station dump check in YoFi is failed')          
        self.log.info('Station dump check on 2.4GHz interface in YoFi is succeeded')
                                                                                 
        # Stop sniffer_2 capture                                                 
        if self.config['sniffer_2']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_2')                      
            self.assertTrue(status, 'Sniffer_2 stop is failed')                  
        camera_switch_pcap = self.multiple_sniffer_handler['sniffer_2']['pcap_filename']
                                                                                 
        # Stop sniffer_4 capture                                                 
        if self.config['sniffer_4']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_4')                      
            self.assertTrue(status, 'Sniffer_4 stop is failed')                  
        rf_1_camera_switch_pcap = self.multiple_sniffer_handler['sniffer_4']['pcap_filename']
                                                                                 
        # Stop sniffer_5 capture                                                 
        if self.config['sniffer_5']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_5')                      
            self.assertTrue(status, 'Sniffer_5 stop is failed')                  
        rf_2_camera_switch_pcap = self.multiple_sniffer_handler['sniffer_5']['pcap_filename']
                                                                                 
        # Camera video streamming                                                
        status = self.camera_stream_in_controller(camera_type_list,              
                                                  live_video_stream_duration=self.config['durations']['live_video_stream'],
                                                  validation_flag=False,         
                                                  yofi_mpp_ip=self.yofi_mpp_ip)  
        self.assertTrue(status, 'Camera streaming in controller is failed')      
                                                                                 
        # Ping to camera from panel                                              
        status = self.ping_from_panel_to_cams_in_background(camera_type_list, self.config['durations']['live_video_stream'])
        self.assertTrue(status, 'ping from panel to camera is failed')           
        self.log.info('ping from panel to camera is successfully completed')     
                                                                                 
        status = self.validate_camera_stream_in_controller(camera_type_list,live_video_stream_duration=self.config['durations']['live_video_stream'])
                                                                                 
        if not status:
            ping_status = self.panel.stop_ping()                                 
            self.assertTrue(ping_status, 'Failed to stop ping')                  
            self.log.info('Successfully ping stopped')                           
                                                                                 
        ping_status = self.validate_ping(camera_type_list, self.config['durations']['live_video_stream'])
                                                                                 
        # Stop sniffer_1 capture                                                 
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_1')                      
            self.assertTrue(status, 'Sniffer_1 stop is failed')                  
        camera_switch_pcap_in_5 = self.multiple_sniffer_handler['sniffer_1']['pcap_filename']
                                                                                 
        # Stop sniffer_3 capture                                                 
        if self.config['sniffer_3']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_3')                      
            self.assertTrue(status, 'Sniffer_1 stop is failed')                  
        rf_1_camera_switch_pcap_in_5 = self.multiple_sniffer_handler['sniffer_3']['pcap_filename']
                                                                                 
        self.get_sniffer_utility_instance()                                      
                                                                                 
        panel_sta_mac = self.config['panel']['sta_mac_addr']                     
        yofi_1_mac = self.config['yofi-1']['mac']                                
        yofi_3_mac = self.config['yofi-3']['mac']                                
        panel_ap_mac = self.config['panel']['ap_mac_addr']                       
        yofi_1_mac_for_24 = self.config['yofi-1']['mac_for_wps_check']           
        yofi_3_mac_for_24 = self.config['yofi-3']['mac_for_wps_check']           
                                                                                 
        # Sniffer_1 frame analysis                                               
        self.log.info('Sniffer_1 analysis between YoFi-1(MPP) and panel(MAP)')   
        self.log.info('Sniffer_1 pcap file: {}'.format(add_yofi_1_pcap_in_5))    
        status = self.sniffer_analysis.validate_MPP_and_MAP_connection_with_sae_and_peer_action_frames(add_yofi_1_pcap_in_5, yofi_1_mac, panel_sta_mac)
                                                                                 
        # Sniffer_1 frame analysis                                               
        self.log.info('Sniffer_3 analysis between YoFi-3(MAP) and panel(MAP)')   
        self.log.info('Sniffer_3 pcap file: {}'.format(add_yofi_3_pcap_in_5))    
        status = self.sniffer_analysis.validate_MPP_and_MAP_connection_with_sae_and_peer_action_frames(add_yofi_3_pcap_in_5, yofi_3_mac, panel_sta_mac)
                                                                                 
        # Sniffer_4 frame analysis, Source Mac should be STA (YoFi)              
        self.log.info('Sniffer_4 analysis between YoFi-3(MAP) and panel(MAP)')   
        self.log.info('Sniffer_4 pcap file: {}'.format(add_yofi_3_pcap_in_24))   
        status = self.sniffer_analysis.wps_connect(add_yofi_3_pcap_in_24, yofi_3_mac_for_24, panel_ap_mac)
                                                                                 
        # Sniffer_2 packet check M1/M2 packet analysis                                                  
        self.log.info('Sniffer_2 packet checking')                               
        total_errors = {}                                                        
        for camera_type_name in ['dbc_camera_1', 'hd300w_camera', 'hd400w_camera']:
            self.get_camera_config(camera_type_name)                             
            self.log.info('#################################################')   
            self.log.info('Started WPS IE validation for {}'.format(camera_type_name))
            self.log.info('Sniffer_2 pcap file: {}'.format(add_camera_pcap))
            camera_mac = self.config[camera_type_name]['mac']                    
            status, errors = self.sniffer_analysis.GES_Vivint_Yofi_PAK_0016_24G_analysis(add_camera_pcap, self.config)
            status_camera_add = self.sniffer_analysis.wps_connect(add_camera_pcap, camera_mac, panel_ap_mac)
            if not status_camera_add:                                            
                errors.append('WPS connection is failed')                        
            total_errors[camera_type_name] = errors                              
            self.log.info('WPS IE validation is done for {}'.format(camera_type_name))
            self.log.info('#################################################')   
                                                                                 
        for camera_type_name in total_errors.keys():                             
            self.log.info('#################################################')   
            self.log.info('Errors found during validation of {}'.format(camera_type_name))
            self.log.info('#################################################')   
            for error in total_errors[camera_type_name]:                         
                self.log.error('{} of {}'.format(error, camera_type_name))       
            self.log.info('#################################################')   
        error_length = [len(total_errors[item]) for item in total_errors]        
        if not all(i == 0 for i in error_length):                                
            self.log.error('M1/M2 packet check failed')                          
                                                                                 
        # Sniffer_4 packet check M1/M2 packet analysis                                                  
        self.log.info('Sniffer_4 packet checking')                               
        total_errors = {}                                                        
        for camera_type_name in ['ping_camera_1']:                               
            self.get_camera_config(camera_type_name)                             
            self.log.info('#################################################')   
            self.log.info('Started WPS IE validation for {}'.format(camera_type_name))
            self.log.info('Sniffer_4 pcap file: {}'.format(rf_1_add_camera_pcap))
            camera_mac = self.config[camera_type_name]['mac']                    
            status, errors = self.sniffer_analysis.GES_Vivint_Yofi_PAK_0016_24G_analysis(rf_1_add_camera_pcap, self.config)
            status_camera_add = self.sniffer_analysis.wps_connect(rf_1_add_camera_pcap, camera_mac, panel_ap_mac)
            if not status_camera_add:                                            
                errors.append('WPS connection is failed')                        
            total_errors[camera_type_name] = errors                              
            self.log.info('WPS IE validation is done for {}'.format(camera_type_name))
            self.log.info('#################################################')   
                                                                                 
        for camera_type_name in total_errors.keys():                             
            self.log.info('#################################################')   
            self.log.info('Errors found during validation of {}'.format(camera_type_name))
            self.log.info('#################################################')
            for error in total_errors[camera_type_name]:                         
                self.log.error('{} of {}'.format(error, camera_type_name))       
            self.log.info('#################################################')   
            error_length = [len(total_errors[item]) for item in total_errors]    
        if not all(i == 0 for i in error_length):                                
            self.log.error('M1/M2 packet check failed')                          
                                                                                 
        # Sniffer_5 packet check M1/M2 packet analysis                                                  
        self.log.info('Sniffer_5 packet checking')                               
        total_errors = {}                                                        
        for camera_type_name in ['hdp450_camera', 'ping_camera_2']:                               
            self.get_camera_config(camera_type_name)                             
            self.log.info('#################################################')   
            self.log.info('Started WPS IE validation for {}'.format(camera_type_name))
            self.log.info('Sniffer_5 pcap file: {}'.format(rf_2_add_camera_pcap))
            camera_mac = self.config[camera_type_name]['mac']                    
            status, errors = self.sniffer_analysis.GES_Vivint_Yofi_PAK_0016_24G_analysis(rf_2_add_camera_pcap, self.config)
            status_camera_add = self.sniffer_analysis.wps_connect(rf_2_add_camera_pcap, camera_mac, panel_ap_mac)
            if not status_camera_add:                                            
                errors.append('WPS connection is failed')                        
            total_errors[camera_type_name] = errors                              
            self.log.info('WPS IE validation is done for {}'.format(camera_type_name))
            self.log.info('#################################################')   
                                                                                 
        for camera_type_name in total_errors.keys():                             
            self.log.info('#################################################')   
            self.log.info('Errors found during validation of {}'.format(camera_type_name))
            self.log.info('#################################################')   
            for error in total_errors[camera_type_name]:                         
                self.log.error('{} of {}'.format(error, camera_type_name))       
            self.log.info('#################################################')   
        error_length = [len(total_errors[item]) for item in total_errors]        
        if not all(i == 0 for i in error_length):                                
            self.log.error('M1/M2 packet check failed')                          
                                                                                 
        # Sniffer_2 frames analysis for camera switch                                               
        self.log.info('Sniffer_2 packet checking for camera switch')             
        total_errors = {}                                                        
        for camera_type_name in ['dbc_camera_1', 'hd400w_camera', 'hd300w_camera']:               
            self.get_camera_config(camera_type_name)                             
            self.log.info('Started WPS connection validation for {}'.format(camera_type_name))
            self.log.info('Sniffer_2 pcap file: {}'.format(camera_switch_pcap))
            camera_mac = self.config[camera_type_name]['mac']                    
            status = self.sniffer_analysis.connection_over_24GHz(camera_switch_pcap, camera_mac, panel_ap_mac)

        # Sniffer_4 frames analysis for camera switch                                                 
        self.log.info('Sniffer_4 packet checking for camera switch')             
        total_errors = {}                                                        
        for camera_type_name in ['ping_camera_1']:                               
            self.get_camera_config(camera_type_name)                             
            self.log.info('Started WPS connection validation for {}'.format(camera_type_name))
            self.log.info('Sniffer_4 pcap file: {}'.format(rf_1_camera_switch_pcap))
            camera_mac = self.config[camera_type_name]['mac']                    
            status = self.sniffer_analysis.connection_over_24GHz(rf_1_camera_switch_pcap, camera_mac, panel_ap_mac)
                                                                                 
        # Sniffer_5 frames analysis for camera switch                                                 
        self.log.info('Sniffer_5 packet checking for camera switch')             
        total_errors = {}                                                        
        for camera_type_name in ['hdp450_camera', 'ping_camera_2']:                               
            self.get_camera_config(camera_type_name)                             
            self.log.info('Started WPS connection validation for {}'.format(camera_type_name))
            self.log.info('Sniffer_5 pcap file: {}'.format(rf_2_camera_switch_pcap))
            camera_mac = self.config[camera_type_name]['mac']                    
            status = self.sniffer_analysis.connection_over_24GHz(rf_2_camera_switch_pcap, camera_mac, yofi_3_mac_for_24)
                                                                                 
        self.assertTrue(ping_status, 'ping verification failed')                 
        self.log.info('Successfully verified ping')

    @attr(test_category='FUNCTIONALITY')
    @attr(test_id='GES_Vivint_Yofi_FUN_0004')
    @nose.allure.severity(nose.allure.severity_level.CRITICAL)
    @nose.allure.feature('Wireless Connection and Ping check between Panel and Cams  with MPP(Panel) and MP(YoFi), MAP(YoFi) - Linear Topology')
    def test_03_GES_Vivint_Yofi_FUN_0004(self):
        """"Wireless Connection and Ping check between Panel and Cams  with MPP(Panel) and MP(YoFi), MAP(YoFi) - Linear Topology
        :Vivint Testrail ID : C1167995
        :Test Case ID: GES_Vivint_Yofi_FUN_0004
        :author: GES automation dev
        """
        self.log.info('======= Testcase started =======')
        self.testcase_name = sys._getframe().f_code.co_name
        test_case = getattr(self, self.testcase_name)
        self.log_path = '{}{}/{}/'.format(self.config['controller']['log_path'], execution_log_path, test_case.test_category)
        self.log.debug('Fun name: {}\n'.format(self.testcase_name))

        # Creating log directory with testcase_name
        self.log_path_with_test_name =  self.cntl.create_log_dir_with_testcase_name(self.log_path, self.testcase_name)
        self.log.info('Log path of testcase directory: {}'.format(self.log_path_with_test_name))

        camera_type_list = ['dbc_camera_2', 'hd300w_camera', 'ping_camera_2']    
        self.check_cameras_in_ap_mode(camera_type_list)

        status = self.att_obj.set_all_channel_to_high_attenuation(               
                                    self.config['attenuator']['attenuator_1'])   
        self.assertTrue(status, 'Set all channel to high attenuation_1 is failed') 
        self.log.info('Set all channel to high attenuation_1 is successful')

        status = self.att_obj.set_all_channel_to_high_attenuation(               
                                    self.config['attenuator']['attenuator_2'])   
        self.assertTrue(status, 'Set all channel to high attenuation_2 is failed') 
        self.log.info('Set all channel to high attenuation_2 is successful')

        # Turn on the panel signal in RF box-1                                  
        status = self.att_obj.set_attenuation(self.config['attenuator']['on'],  
                                    self.config['attenuator']['channel_1'],     
                                    self.config['attenuator']['attenuator_1'])  
        self.assertTrue(status, 'Passing panel signal in RF box-1 is failed')   
        self.attenuator_1 = True

        # Turn on the panel signal in RF box-2                                  
        status = self.att_obj.set_attenuation(self.config['attenuator']['on'],  
                                    self.config['attenuator']['channel_2'],     
                                    self.config['attenuator']['attenuator_1'])  
        self.assertTrue(status, 'Passing panel signal in RF box-2 is failed')   
        self.attenuator_2 = True

        # Configure panel as MPP                                                 
        self.panel_mpp_ip = self.configure_mpp(self.panel)                       
        self.assertTrue(self.panel_mpp_ip, 'get MPP IP address is failed')       
                                                                                 
        '''
        # Get mesh ID and psk from panel                                         
        status = self.panel.get_mesh_id_and_psk()                                
        self.assertTrue(status, 'Failed to get mesh_id and wps_psk')             
        '''
                                                                                 
        # Start sniffer_2 capture                                                  
        if self.config['sniffer_2']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_2', '2.4', 'add_camera')
            self.assertTrue(status, 'Sniffer_2 start is failed')                 
                                                                                 
        # Select the PCI card                                                    
        self.log.info('Outside wireless adapter mac: {}'.format(                 
                                self.config['controller']['outside_wireless_adapter_mac']))
        self.cntl.pci_mac=self.config['controller']['outside_wireless_adapter_mac']
                                                                                 
        # Gets the camera instance                                               
        self.get_camera_instance('hd300w_camera')                                
                                                                                 
        # Add Camera                                                             
        status = self.add_camera_to_panel('wps')                                 
        self.assertTrue(status, 'camera addition is failed')                     
        self.log.info('camera addition is succeeded')

        # Select the PCI card                                                    
        self.log.info('RF-1 wireless adapter card: {}'.format(                   
                                self.config['controller']['rf1_wireless_adapter_mac']))
        self.cntl.pci_mac=self.config['controller']['rf1_wireless_adapter_mac']  
                                                                                 
        # Start sniffer_4 capture                                                  
        if self.config['sniffer_4']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_4', '2.4', 'rf_1_add_camera')
            self.assertTrue(status, 'Sniffer_4 start is failed')                 
                                                                                 
        # Gets the camera instance                                               
        self.get_camera_instance('dbc_camera_2')                                
                                                                                 
        # Add Camera                                                             
        status = self.add_camera_to_panel('wps')                                 
        self.assertTrue(status, 'camera addition is failed')                     
        self.log.info('camera addition is succeeded')                            
                                                                                 
        # Select the PCI card                                                    
        self.log.info('RF-2 wireless adapter card: {}'.format(                   
                      self.config['controller']['rf2_wireless_adapter_mac']))
        self.cntl.pci_mac=self.config['controller']['rf2_wireless_adapter_mac']  
                                                                                 
        # Start sniffer_5 capture                                                  
        if self.config['sniffer_5']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_5', '2.4', 'rf_2_add_camera')
            self.assertTrue(status, 'Sniffer_5 start is failed')                 
                                                                                 
        # Gets the camera instance                                               
        self.get_camera_instance('ping_camera_2')                                
                                                                                 
        # Add Camera                                                             
        status = self.add_camera_to_panel('wps')                                 
        self.assertTrue(status, 'camera addition is failed')                     
        self.log.info('camera addition is succeeded')                            
                                                                                 
        # Stop sniffer_2 capture                                                 
        if self.config['sniffer_2']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_2')                      
            self.assertTrue(status, 'Sniffer_2 stop is failed')                  
        add_camera_pcap = self.multiple_sniffer_handler['sniffer_2']['pcap_filename']
                                                                                 
        # Stop sniffer_4 capture                                                 
        if self.config['sniffer_4']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_4')                      
            self.assertTrue(status, 'Sniffer_4 stop is failed')                  
        rf_1_add_camera_pcap = self.multiple_sniffer_handler['sniffer_4']['pcap_filename']
                                                                                 
        # Stop sniffer_5 capture                                                 
        if self.config['sniffer_5']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_5')                      
            self.assertTrue(status, 'Sniffer_5 stop is failed')                  
        rf_2_add_camera_pcap = self.multiple_sniffer_handler['sniffer_5']['pcap_filename']
                                                                                 
        # Gets the yofi-1 instance                                               
        self.get_yofi_instance('yofi-2')

        # Start sniffer_1 capture                                                  
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_1', '5', 'adding_yofi_2_to_panel', sniffer_flag=False)
            self.assertTrue(status, 'Sniffer_1 start is failed')                 
                                                                                 
        # Start sniffer_2 capture                                                
        if self.config['sniffer_2']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_2', '2.4', 'adding_yofi_2_to_panel')
            self.assertTrue(status, 'Sniffer_2 start is failed')

        # Add yofi-2                                                               
        status = self.add_yofi_node_to_panel('wps')                              
        self.assertTrue(status, 'yofi-2 addition is failed')                     
        self.log.info('yofi-2 addition is succeeded')

        # Stop sniffer_1 capture                                                 
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_1')                      
            self.assertTrue(status, 'Sniffer_1 stop is failed')                  
        add_yofi_2_pcap_in_5  = self.multiple_sniffer_handler['sniffer_1']['pcap_filename']
                                                                                 
        # Stop sniffer_2 capture                                                 
        if self.config['sniffer_2']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_2')                      
            self.assertTrue(status, 'Sniffer_2 stop is failed')                  
        add_yofi_2_pcap_in_24  = self.multiple_sniffer_handler['sniffer_2']['pcap_filename']
                                                                                 
        # TODO RSSI of panel should less than -60, RSSI of YoFi-1 should not available or more than -70
        # If not work do attenuate 30dB instead of 0dB
        exp_mac_list = [self.config['panel']['ap_mac_addr'], self.config['panel']['sta_mac_addr']]
        unexp_mac_list = [self.config['yofi-2']['mac'], self.config['yofi-2']['mac_for_wps_check']]
        status = self.cntl.get_signal_strength_in_controller(
                        self.config['controller']['rf1_wireless_adapter_mac'],
                        exp_mac_list, unexp_mac_list)
        #self.assertTrue(status, 'Getting RSSI value in RF box-1 is failed')

        # Start sniffer_1 capture                                                  
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_1', '5', 'valiadtion')
            self.assertTrue(status, 'Sniffer_1 start is failed')                 
                                                                                 
        # Gets the yofi-3 instance
        self.get_yofi_instance('yofi-3')

        # Start sniffer_3 capture                                                  
        if self.config['sniffer_3']['enable'].lower() == 'true':
            status = self.start_sniffer_capture('sniffer_3', '5', 'adding_yofi_3_to_panel')
            self.assertTrue(status, 'Sniffer_3 start is failed')

        # Start sniffer_4 capture
        if self.config['sniffer_4']['enable'].lower() == 'true':
            status = self.start_sniffer_capture('sniffer_4', '2.4', 'adding_yofi_3_to_panel')
            self.assertTrue(status, 'Sniffer_4 start is failed')

        # Add yofi-3
        status = self.add_yofi_node_to_panel('wps')
        self.assertTrue(status, 'yofi-3 addition is failed')
        self.log.info('yofi-3 addition is succeeded')

        # Stop sniffer_4 capture
        if self.config['sniffer_4']['enable'].lower() == 'true':
            status = self.stop_sniffer_capture('sniffer_4')
            self.assertTrue(status, 'Sniffer_4 stop is failed')
        add_yofi_3_pcap_in_24  = self.multiple_sniffer_handler['sniffer_4']['pcap_filename']

        # Stop sniffer_3 capture                                                 
        if self.config['sniffer_3']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_3')                      
            self.assertTrue(status, 'Sniffer_3 stop is failed')                  
        add_yofi_3_pcap_in_5 = self.multiple_sniffer_handler['sniffer_3']['pcap_filename']
                                                                                 
        # Start sniffer_3 capture                                                  
        if self.config['sniffer_3']['enable'].lower() == 'true':
            status = self.start_sniffer_capture('sniffer_3', '5', 'rf_1_linear')
            self.assertTrue(status, 'Sniffer_3 start is failed')

        # Get channel from YoFi-3                                                
        yofi_3_channel = self.yofi.get_channel('wlan1')                          
        self.assertTrue(yofi_3_channel, 'Getting YoFi-3 2.4GHz channel is failed')
                                                                                 
        # Start sniffer_4 capture                                                
        if self.config['sniffer_4']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_4', '2.4', 'rf_1_camera_switch', yofi_3_channel)
            self.assertTrue(status, 'Sniffer_4 start is failed')                 
                                                                                 
        yofi_type = 'yofi-2'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']              
                                                                                 
        # Get channel from YoFi-2                                                
        yofi_2_channel = self.yofi.get_channel('wlan1')                          
        self.assertTrue(yofi_2_channel, 'Getting YoFi-2 2.4GHz channel is failed')
                                                                                 
        # Start sniffer_5 capture                                                
        if self.config['sniffer_5']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_5', '2.4', 'rf_2_camera_switch', yofi_2_channel)
            self.assertTrue(status, 'Sniffer_5 start is failed')                 
                                                                                 
        # Turn off the panel signal in RF box-1                                 
        status = self.att_obj.set_attenuation(self.config['attenuator']['off'],  
                                    self.config['attenuator']['channel_1'],      
                                    self.config['attenuator']['attenuator_1'])
        self.assertTrue(status, 'Blocking panel signal in RF box-1 is failed')   
                                                                                 
        # Turn off the panel signal in RF box-2                                  
        status = self.att_obj.set_attenuation(self.config['attenuator']['off'],  
                                    self.config['attenuator']['channel_2'],      
                                    self.config['attenuator']['attenuator_1'])
        self.assertTrue(status, 'Blocking panel signal in RF box-2 is failed')   
                                                                                 
        time.sleep(10)                                                           
                                                                                 
        # Turn on the YoFi-2 signal in RF box-1                               
        status = self.att_obj.set_attenuation(self.config['attenuator']['on'],   
                                    self.config['attenuator']['channel_1'],      
                                    self.config['attenuator']['attenuator_2'])   
        self.assertTrue(status, 'Passing YoFi-2 signal in RF box-1 is failed')   

        # Turn on the YoFi-2 signal in RF box-2                                  
        status = self.att_obj.set_attenuation(self.config['attenuator']['on'],   
                                    self.config['attenuator']['channel_2'],      
                                    self.config['attenuator']['attenuator_2'])   
        self.assertTrue(status, 'Passing YoFi-2 signal in RF box-2 is failed')   
                                                                                 
        # Verify YoFi-2 node is MAP mesh type
        status = self.yofi.is_mesh_node_map()
        self.assertTrue(status, 'YoFi-2 is not in MAP mode')
        self.log.info('YoFi-2 is in MAP mode')

        # Verify panel node is MPP mesh type                                     
        status = self.panel.is_mesh_node_mpp()                                   
        self.assertTrue(status, 'Panel is not in MPP mode')                      
        self.log.info('Panel is in MPP mode')
                                                                                 
        yofi_type = 'yofi-3'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']              
                                                                                 
        # Verify YoFi-3 node is MAP mesh type
        status = self.yofi.is_mesh_node_map()
        self.assertTrue(status, 'YoFi-3 is not in MAP mode')
        self.log.info('YoFi-3 is in MAP mode')

        # Ping from Yofi-3(MAP) to Panel(MPP)                                    
        status = self.yofi.ping(self.config['panel']['nw_br_lan_ip'])            
        # TODO
        #self.assertTrue(status, 'Ping from YoFi-3(MAP) to panel(MPP) is failed') 
        self.log.info('Ping from YoFi-3(MAP) to panel(MPP) is successfull')      
                                                                                 
        # Ping from Yofi-3(MAP) to Yofi-2(MAP)                                   
        status = self.yofi.ping(self.multiple_yofi_handler['yofi-2']['yofi_ip']) 
        #self.assertTrue(status, 'Ping from yofi-3(MAP) to YoFi-2(MAP) is failed')
        self.log.info('Ping from Yofi-3(MAP) to YoFi-2(MAP) is successfull')

        # Ping from Panel(MPP) to Yofi-2(MAP)                                    
        status = self.panel.ping(self.multiple_yofi_handler['yofi-2']['yofi_ip'])
        #self.assertTrue(status, 'Ping from panel(MPP) to YoFi-2(MAP) is failed') 
        self.log.info('Ping from panel(MPP) to YoFi-2(MAP) is successfull')

        # Ping from Panel(MPP) to Yofi-3(MAP)                                    
        status = self.panel.ping(self.multiple_yofi_handler['yofi-3']['yofi_ip'])                                    
        # TODO
        #self.assertTrue(status, 'Ping from panel(MPP) to YoFi-3(MAP) is failed') 
        self.log.info('Ping from panel(MPP) to YoFi-3(MAP) is successfull')      
                                                                                 
        yofi_type = 'yofi-2'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']              
                                                                                 
        # Ping from Yofi-2(MAP) to Panel(MPP)                                    
        status = self.yofi.ping(self.config['panel']['nw_br_lan_ip'])            
        #self.assertTrue(status, 'Ping from YoFi-2(MAP) to panel(MPP) is failed') 
        self.log.info('Ping from YoFi-2(MAP) to panel(MPP) is successfull')      
                                                                                 
        # Ping from Yofi-2(MAP) to Yofi-3(MAP)                                   
        status = self.yofi.ping(self.multiple_yofi_handler['yofi-3']['yofi_ip']) 
        #self.assertTrue(status, 'Ping from yofi-2(MAP) to YoFi-3(MAP) is failed')
        self.log.info('Ping from Yofi-2(MAP) to YoFi-3(MAP) is successfull')

        # Get mesh graph .svg file from panel if this flag True
        self.mesh_graph_flag = True

        # Topology check in panel MPP                                            
        status = self.verify_station_dump(self.panel, self.config['yofi-2']['mac'])
        self.assertTrue(status, 'Station dump check in Panel is failed')         
        self.log.info('Station dump check on mesh interface in Panel is succeeded')
                                                                                 
        # Topology check in Panel MPP                                            
        status = self.verify_station_dump(self.panel, self.config['yofi-3']['mac'])
        # TODO should not found
        #self.assertTrue(status, 'Station dump check in Panel is failed')         
        self.log.info('Station dump check on mesh interface in Panel is succeeded')
                                                                                 
        # Topology check in MAP-YoFi-2                                            
        status = self.verify_station_dump(self.yofi, self.config['yofi-3']['mac'])
        self.assertTrue(status, 'Station dump check in YoFi is failed')          
        self.log.info('Station dump check on mesh interface in YoFi is succeeded')
                                                                                 
        # Topology check in MAP-YoFi-2                                            
        status = self.verify_station_dump(self.yofi, self.config['panel']['sta_mac_addr'])
        self.assertTrue(status, 'Station dump check in YoFi is failed')          
        self.log.info('Station dump check on mesh interface in YoFi is succeeded')
                                                                                 
        # Gets the yofi-3 instance                                               
        yofi_type = 'yofi-3'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']              
                                                                                 
        # Topology check in MAP-YoFi-3                                            
        status = self.verify_station_dump(self.yofi, self.config['yofi-2']['mac'])
        self.assertTrue(status, 'Station dump check in YoFi is failed')          
        self.log.info('Station dump check on mesh interface in YoFi is succeeded')
                                                                                 
        # Topology check in MAP-YoFi-3                                           
        status = self.verify_station_dump(self.yofi, self.config['panel']['sta_mac_addr'])
        # TODO should not found
        #self.assertTrue(status, 'Station dump check in YoFi is failed')          
        self.log.info('Station dump check on mesh interface in YoFi is succeeded')

        # TODO RSSI of panel should less than -60, RSSI of YoFi-1 should not available or more than -70
        # If not work do attenuate 30dB instead of 0dB
        unexp_mac_list = [self.config['panel']['ap_mac_addr'], self.config['panel']['sta_mac_addr']]
        exp_mac_list = [self.config['yofi-2']['mac'], self.config['yofi-2']['mac_for_wps_check']]
        status = self.cntl.get_signal_strength_in_controller(
                        self.config['controller']['rf1_wireless_adapter_mac'],
                        exp_mac_list, unexp_mac_list)
        #self.assertTrue(status, 'Getting RSSI value in RF box-1 is failed')

        exp_mac_list = [self.config['panel']['ap_mac_addr'], self.config['panel']['sta_mac_addr']]
        unexp_mac_list = [self.config['yofi-3']['mac'], self.config['yofi-3']['mac_for_wps_check']]
        status = self.cntl.get_signal_strength_in_controller(
                        self.config['controller']['outside_wireless_adapter_mac'],
                        exp_mac_list, unexp_mac_list)
        #self.assertTrue(status, 'Getting RSSI value is failed')

        # TODO If fails, Do attenuate 20dB and check again

        # Check the linear topology using mpath dump, next hop node mac and dest node mac
        self.yofi.verify_linear_topology(self.config['panel']['sta_mac_addr'], self.config['yofi-2']['mac'])
        # TODO 
        #self.assertTrue(status, 'Linear topology check in YoFi-3 is failed')
                                                                                 
        # Netv assoc for 5GHz
        self.display_mesh_node_connection_status(self.config['panel']['sta_mac_addr'])

        # Displays the where the camera is connected using netv assoc 2.4         
        status = self.display_camera_connection_status(self.config['camera']['mac'], panel_flag=True)
        self.log.info('Display cameras connection status in Panel MPP')         
                                                                                 
        # Stop sniffer_1 capture                                                 
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_1')                      
            self.assertTrue(status, 'Sniffer_1 stop is failed')                  
        validation_5 = self.multiple_sniffer_handler['sniffer_1']['pcap_filename']
                                                                                 
        # Stop sniffer_3 capture                                                 
        if self.config['sniffer_3']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_3')                      
            self.assertTrue(status, 'Sniffer_3 stop is failed')                  
        rf_1_linear_validation = self.multiple_sniffer_handler['sniffer_3']['pcap_filename']
                                                                                 
        # Start sniffer_1 capture                                                  
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_1', '5', 'camera_switch')
            self.assertTrue(status, 'Sniffer_1 start is failed')                 
                                                                                 
        # Start sniffer_3 capture                                                  
        if self.config['sniffer_3']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_3', '5', 'rf_1_camera_switch')
            self.assertTrue(status, 'Sniffer_3 start is failed')                 
                                                                                 
        yofi_type = 'yofi-2'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']              
                                                                                 
        # Get channel from YoFi-2                                                
        yofi_2_channel = self.yofi.get_channel('wlan1')                          
        self.assertTrue(yofi_2_channel, 'Getting YoFi-2 2.4GHz channel is failed')
                                                                                 
        # Start sniffer_2 capture                                                
        if self.config['sniffer_2']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_2', '2.4', 'camera_switch', yofi_2_channel)
            self.assertTrue(status, 'Sniffer_2 start is failed')                 
                                                                                 
        # Connecting camera to mesh node using bssid                                 
        self.connect_camera_to_mesh_node('hd300w_camera', self.config['yofi-2']['mac_for_wps_check'])

        self.get_camera_config('ping_camera_2')                                  
                                                                                 
        # Topology check in MPP-YoFi, Camera should connected to YoFi            
        status = self.verify_station_dump(self.yofi, self.config['camera']['mac'], 'wlan1')
        self.assertTrue(status, 'Station dump check in YoFi is failed')          
        self.log.info('Station dump check on 2.4GHz interface in YoFi is succeeded')
                                                                                 
        yofi_type = 'yofi-3'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']              
                                                                                 
        # Connecting camera to mesh node using bssid                                 
        self.connect_camera_to_mesh_node('dbc_camera_2', self.config['yofi-3']['mac_for_wps_check'])

        # Stop sniffer_2 capture                                                 
        if self.config['sniffer_2']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_2')                      
            self.assertTrue(status, 'Sniffer_2 stop is failed')                  
        camera_switch_pcap = self.multiple_sniffer_handler['sniffer_2']['pcap_filename']
                                                                                 
        # Stop sniffer_4 capture                                                 
        if self.config['sniffer_4']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_4')                      
            self.assertTrue(status, 'Sniffer_4 stop is failed')                  
        rf_1_camera_switch_pcap = self.multiple_sniffer_handler['sniffer_4']['pcap_filename']
                                                                                 
        # Stop sniffer_5 capture                                                 
        if self.config['sniffer_5']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_5')                      
            self.assertTrue(status, 'Sniffer_5 stop is failed')                  
        rf_2_camera_switch_pcap = self.multiple_sniffer_handler['sniffer_5']['pcap_filename']
                                                                                 
        # Camera video streamming                                                
        status = self.camera_stream_in_controller(camera_type_list,              
                                                  live_video_stream_duration=self.config['durations']['live_video_stream'],
                                                  validation_flag=False)         
        self.assertTrue(status, 'Camera streaming in controller is failed')      
                                                                                 
        # Ping to camera from panel                                              
        status = self.ping_from_panel_to_cams_in_background(camera_type_list, self.config['durations']['live_video_stream'])
        self.assertTrue(status, 'ping from panel to camera is failed')           
        self.log.info('ping from panel to camera is successfully completed')     
                                                                                 
        status = self.validate_camera_stream_in_controller(camera_type_list,live_video_stream_duration=self.config['durations']['live_video_stream'])
                                                                                 
        if not status:
            ping_status = self.panel.stop_ping()                                 
            self.assertTrue(ping_status, 'Failed to stop ping')                  
            self.log.info('Successfully ping stopped')                           
                                                                                 
        ping_status = self.validate_ping(camera_type_list, self.config['durations']['live_video_stream'])
                                                                                 
        # Stop sniffer_1 capture                                                 
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_1')                      
            self.assertTrue(status, 'Sniffer_1 stop is failed')                  
        camera_switch_pcap_in_5 = self.multiple_sniffer_handler['sniffer_1']['pcap_filename']
                                                                                 
        # Stop sniffer_3 capture                                                 
        if self.config['sniffer_3']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_3')                      
            self.assertTrue(status, 'Sniffer_1 stop is failed')                  
        rf_1_camera_switch_pcap_in_5 = self.multiple_sniffer_handler['sniffer_3']['pcap_filename']
                                                                                 
        self.get_sniffer_utility_instance()                                      
                                                                                 
        panel_sta_mac = self.config['panel']['sta_mac_addr']                     
        yofi_2_mac = self.config['yofi-2']['mac']                                
        yofi_3_mac = self.config['yofi-3']['mac']                                
        panel_ap_mac = self.config['panel']['ap_mac_addr']                       
        yofi_2_mac_for_24 = self.config['yofi-2']['mac_for_wps_check']           
        yofi_3_mac_for_24 = self.config['yofi-3']['mac_for_wps_check']           
                                                                                 
        # Sniffer_1 frame analysis                                               
        self.log.info('Sniffer_1 analysis between YoFi-2(MAP) and panel(MPP)')   
        self.log.info('Sniffer_1 pcap file: {}'.format(add_yofi_2_pcap_in_5))    
        status = self.sniffer_analysis.validate_MPP_and_MAP_connection_with_sae_and_peer_action_frames(add_yofi_2_pcap_in_5, yofi_2_mac, panel_sta_mac)
                                                                                 
        # Sniffer_2 frame analysis, Source Mac should be STA (YoFi)              
        self.log.info('Sniffer_2 analysis between YoFi-2(MAP) and panel(MPP)')   
        self.log.info('Sniffer_2 pcap file: {}'.format(add_yofi_2_pcap_in_24))   
        status = self.sniffer_analysis.wps_connect(add_yofi_2_pcap_in_24, yofi_2_mac_for_24, panel_ap_mac)
                                                                                 
        # Sniffer_1 frame analysis                                               
        self.log.info('Sniffer_1 analysis between YoFi-3(MAP) and panel(MPP)')   
        self.log.info('Sniffer_1 pcap file: {}'.format(add_yofi_3_pcap_in_5))    
        status = self.sniffer_analysis.validate_MPP_and_MAP_connection_with_sae_and_peer_action_frames(add_yofi_3_pcap_in_5, yofi_3_mac, panel_sta_mac)
                                                                                 
        # Sniffer_2 frame analysis, Source Mac should be STA (YoFi)              
        self.log.info('Sniffer_2 analysis between YoFi-3(MAP) and panel(MPP)')   
        self.log.info('Sniffer_2 pcap file: {}'.format(add_yofi_3_pcap_in_24))   
        status = self.sniffer_analysis.wps_connect(add_yofi_3_pcap_in_24, yofi_3_mac_for_24, panel_ap_mac)

        # Sniffer_3 frame analysis                                               
        self.log.info('Sniffer_3 analysis between YoFi-3(MAP) and YoFi-2(MAP)')  
        self.log.info('Sniffer_3 pcap file: {}'.format(rf_1_linear_validation))  
        status = self.sniffer_analysis.validate_MPP_and_MAP_connection_with_sae_and_peer_action_frames(rf_1_linear_validation, yofi_2_mac, yofi_3_mac)

        # Sniffer_2 packet check M1/M2 packet analysis                                                  
        self.log.info('Sniffer_2 packet checking')                               
        total_errors = {}                                                        
        for camera_type_name in ['hd300w_camera']:
            self.get_camera_config(camera_type_name)                             
            self.log.info('#################################################')   
            self.log.info('Started WPS IE validation for {}'.format(camera_type_name))
            self.log.info('Sniffer_2 pcap file: {}'.format(add_camera_pcap))
            camera_mac = self.config[camera_type_name]['mac']                    
            status, errors = self.sniffer_analysis.GES_Vivint_Yofi_PAK_0016_24G_analysis(add_camera_pcap, self.config)
            status_camera_add = self.sniffer_analysis.wps_connect(add_camera_pcap, camera_mac, panel_ap_mac)
            if not status_camera_add:                                            
                errors.append('WPS connection is failed')                        
            total_errors[camera_type_name] = errors                              
            self.log.info('WPS IE validation is done for {}'.format(camera_type_name))
            self.log.info('#################################################')   
                                                                                 
        for camera_type_name in total_errors.keys():                             
            self.log.info('#################################################')   
            self.log.info('Errors found during validation of {}'.format(camera_type_name))
            self.log.info('#################################################')   
            for error in total_errors[camera_type_name]:                         
                self.log.error('{} of {}'.format(error, camera_type_name))       
            self.log.info('#################################################')   
        error_length = [len(total_errors[item]) for item in total_errors]        
        if not all(i == 0 for i in error_length):                                
            self.log.error('M1/M2 packet check failed')                          
                                                                                 
        # Sniffer_4 packet check M1/M2 packet analysis                                                  
        self.log.info('Sniffer_4 packet checking')                               
        total_errors = {}                                                        
        for camera_type_name in ['dbc_camera_2']:                               
            self.get_camera_config(camera_type_name)                             
            self.log.info('#################################################')   
            self.log.info('Started WPS IE validation for {}'.format(camera_type_name))
            self.log.info('Sniffer_4 pcap file: {}'.format(rf_1_add_camera_pcap))
            camera_mac = self.config[camera_type_name]['mac']                    
            status, errors = self.sniffer_analysis.GES_Vivint_Yofi_PAK_0016_24G_analysis(rf_1_add_camera_pcap, self.config)
            status_camera_add = self.sniffer_analysis.wps_connect(rf_1_add_camera_pcap, camera_mac, panel_ap_mac)
            if not status_camera_add:                                            
                errors.append('WPS connection is failed')                        
            total_errors[camera_type_name] = errors                              
            self.log.info('WPS IE validation is done for {}'.format(camera_type_name))
            self.log.info('#################################################')   
                                                                                 
        for camera_type_name in total_errors.keys():                             
            self.log.info('#################################################')   
            self.log.info('Errors found during validation of {}'.format(camera_type_name))
            self.log.info('#################################################')
            for error in total_errors[camera_type_name]:                         
                self.log.error('{} of {}'.format(error, camera_type_name))       
            self.log.info('#################################################')   
            error_length = [len(total_errors[item]) for item in total_errors]    
        if not all(i == 0 for i in error_length):                                
            self.log.error('M1/M2 packet check failed')                          
                                                                                 
        # Sniffer_5 packet check M1/M2 packet analysis                                                  
        self.log.info('Sniffer_5 packet checking')                               
        total_errors = {}                                                        
        for camera_type_name in ['ping_camera_2']:                               
            self.get_camera_config(camera_type_name)                             
            self.log.info('#################################################')   
            self.log.info('Started WPS IE validation for {}'.format(camera_type_name))
            self.log.info('Sniffer_5 pcap file: {}'.format(rf_2_add_camera_pcap))
            camera_mac = self.config[camera_type_name]['mac']                    
            status, errors = self.sniffer_analysis.GES_Vivint_Yofi_PAK_0016_24G_analysis(rf_2_add_camera_pcap, self.config)
            status_camera_add = self.sniffer_analysis.wps_connect(rf_2_add_camera_pcap, camera_mac, panel_ap_mac)
            if not status_camera_add:                                            
                errors.append('WPS connection is failed')                        
            total_errors[camera_type_name] = errors                              
            self.log.info('WPS IE validation is done for {}'.format(camera_type_name))
            self.log.info('#################################################')   
                                                                                 
        for camera_type_name in total_errors.keys():                             
            self.log.info('#################################################')   
            self.log.info('Errors found during validation of {}'.format(camera_type_name))
            self.log.info('#################################################')   
            for error in total_errors[camera_type_name]:                         
                self.log.error('{} of {}'.format(error, camera_type_name))       
            self.log.info('#################################################')   
        error_length = [len(total_errors[item]) for item in total_errors]        
        if not all(i == 0 for i in error_length):                                
            self.log.error('M1/M2 packet check failed')                          
                                                                                 
        # Sniffer_2 frames analysis for camera switch                                               
        self.log.info('Sniffer_2 packet checking for camera switch')             
        total_errors = {}                                                        
        for camera_type_name in ['hd300w_camera']:               
            self.get_camera_config(camera_type_name)                             
            self.log.info('Started WPS connection validation for {}'.format(camera_type_name))
            self.log.info('Sniffer_2 pcap file: {}'.format(camera_switch_pcap))
            camera_mac = self.config[camera_type_name]['mac']                    
            status = self.sniffer_analysis.connection_over_24GHz(camera_switch_pcap, camera_mac, yofi_2_mac_for_24)

        # Sniffer_4 frames analysis for camera switch                                                 
        self.log.info('Sniffer_4 packet checking for camera switch')             
        total_errors = {}                                                        
        for camera_type_name in ['dbc_camera_2']:                               
            self.get_camera_config(camera_type_name)                             
            self.log.info('Started WPS connection validation for {}'.format(camera_type_name))
            self.log.info('Sniffer_4 pcap file: {}'.format(rf_1_camera_switch_pcap))
            camera_mac = self.config[camera_type_name]['mac']                    
            status = self.sniffer_analysis.connection_over_24GHz(rf_1_camera_switch_pcap, camera_mac, yofi_3_mac_for_24)
                                                                                 
        # Sniffer_5 frames analysis for camera switch                                                 
        self.log.info('Sniffer_5 packet checking for camera switch')             
        total_errors = {}                                                        
        for camera_type_name in ['ping_camera_2']:                               
            self.get_camera_config(camera_type_name)                             
            self.log.info('Started WPS connection validation for {}'.format(camera_type_name))
            self.log.info('Sniffer_5 pcap file: {}'.format(rf_2_camera_switch_pcap))
            camera_mac = self.config[camera_type_name]['mac']                    
            status = self.sniffer_analysis.connection_over_24GHz(rf_2_camera_switch_pcap, camera_mac, yofi_2_mac_for_24)
                                                                                 
        self.assertTrue(ping_status, 'ping verification failed')                 
        self.log.info('Successfully verified ping')

    @attr(test_category='FUNCTIONALITY')
    @attr(test_id='GES_Vivint_Yofi_FUN_0007')
    @nose.allure.severity(nose.allure.severity_level.CRITICAL)
    @nose.allure.feature('Reboot of MPP(YoFi')
    def test_04_GES_Vivint_Yofi_FUN_0007(self):
        """"Mesh Network with MPP(Yofi) and 1 MAP(Panel) and 1 MAP (YoFi) in Star topology. Reboot of MPP YoFi
        :Vivint Testrail ID : C1167997
        :Test Case ID: GES_Vivint_Yofi_FUN_0007
        :author: GES automation dev
        """
        self.log.info('======= Testcase started =======')
        self.testcase_name = sys._getframe().f_code.co_name
        test_case = getattr(self, self.testcase_name)
        self.log_path = '{}{}/{}/'.format(self.config['controller']['log_path'], execution_log_path, test_case.test_category)
        self.log.debug('Fun name: {}\n'.format(self.testcase_name))

        # Creating log directory with testcase_name
        self.log_path_with_test_name =  self.cntl.create_log_dir_with_testcase_name(self.log_path, self.testcase_name)
        self.log.info('Log path of testcase directory: {}'.format(self.log_path_with_test_name))

        camera_type_list = ['dbc_camera_1']    
        self.check_cameras_in_ap_mode(camera_type_list)

        # Configure panel as MPP                                                 
        self.panel_mpp_ip = self.configure_mpp(self.panel)                       
        self.assertTrue(self.panel_mpp_ip, 'get MPP IP address is failed')       
                                                                                 
        # Get mesh ID and psk from panel                                         
        status = self.panel.get_mesh_id_and_psk()                                
        self.assertTrue(status, 'Failed to get mesh_id and wps_psk')             
                                                                                 
        # Start sniffer_2 capture                                                  
        if self.config['sniffer_2']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_2', '2.4', 'add_camera')
            self.assertTrue(status, 'Sniffer_2 start is failed')                 
                                                                                 
        # Select the PCI card                                                    
        self.log.info('Outside wireless adapter mac: {}'.format(                 
                                self.config['controller']['outside_wireless_adapter_mac']))
        self.cntl.pci_mac=self.config['controller']['outside_wireless_adapter_mac']
                                                                                 
        # Gets the camera instance                                               
        self.get_camera_instance('dbc_camera_1')                                 
                                                                                 
        # Add Camera                                                             
        status = self.add_camera_to_panel('wps')                                 
        self.assertTrue(status, 'camera addition is failed')                     
        self.log.info('camera addition is succeeded')                            
                                                                                 
        # Stop sniffer_2 capture                                                 
        if self.config['sniffer_2']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_2')                      
            self.assertTrue(status, 'Sniffer_2 stop is failed')                  
        add_camera_pcap = self.multiple_sniffer_handler['sniffer_2']['pcap_filename']
                                                                                 
        # Gets the yofi-1 instance                                               
        self.get_yofi_instance('yofi-1')
                                                                          
        # Start sniffer_1 capture                                                  
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_1', '5', 'adding_yofi_1_to_panel', sniffer_flag=False)
            self.assertTrue(status, 'Sniffer_1 start is failed')                 

        # Configure yofi as MPP                                                  
        self.yofi_mpp_ip = self.configure_mpp(self.yofi)                         
        self.assertTrue(self.yofi_mpp_ip, 'Getting MPP IP address is failed')

        # Stop sniffer_1 capture                                                 
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_1')                      
            self.assertTrue(status, 'Sniffer_1 stop is failed')                  
        add_yofi_1_pcap_in_5  = self.multiple_sniffer_handler['sniffer_1']['pcap_filename']
                                                                       
        # Gets the yofi-2 instance                                               
        self.get_yofi_instance('yofi-2')

        # Start sniffer_1 capture                                                  
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_1', '5', 'adding_yofi_2_to_panel')
            self.assertTrue(status, 'Sniffer_1 start is failed')                 

        # get panel map channel                                                  
        panel_map_channel_24 = self.panel.get_channel('wlan1', self.panel_map_ip)
        self.assertTrue(panel_map_channel_24, 'Getting panel channel on wlan1 is failed')

        # Start sniffer_2 capture                                                  
        if self.config['sniffer_2']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_2', '2.4', 'adding_yofi_2_to_panel', panel_map_channel_24)
            self.assertTrue(status, 'Sniffer_2 start is failed')

        # Add yofi-2                                                             
        status = self.add_yofi_node_to_panel('wps', self.panel_map_ip)           
        self.assertTrue(status, 'yofi-2 addition is failed')                     
        self.log.info('yofi-2 addition is succeeded')

        # Stop sniffer_1 capture                                                 
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_1')                      
            self.assertTrue(status, 'Sniffer_1 stop is failed')                  
        add_yofi_2_pcap_in_5  = self.multiple_sniffer_handler['sniffer_1']['pcap_filename']
      
        # Stop sniffer_2 capture                                                 
        if self.config['sniffer_2']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_2')                      
            self.assertTrue(status, 'Sniffer_2 stop is failed')                  
        add_yofi_2_pcap_in_24 = self.multiple_sniffer_handler['sniffer_2']['pcap_filename']
                                                                           
        # Start sniffer_1 capture                                                  
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_1', '5', 'valiadtion')  
            self.assertTrue(status, 'Sniffer_1 start is failed')

        # Verify YoFi-2 node is MAP mesh type
        status = self.yofi.is_mesh_node_map()
        self.assertTrue(status, 'YoFi-2 is not in MAP mode')
        self.log.info('YoFi-2 is in MAP mode')

        # Verify panel node is MAP mesh type                                     
        status = self.panel.is_mesh_node_map(self.panel_map_ip)                  
        self.assertTrue(status, 'Panel is not in MAP mode')                      
        self.log.info('Panel is in MAP mode')                                    
                                                                                 
        yofi_type = 'yofi-1'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']              
                                                                                 
        # Verify YoFi-1 node is MPP mesh type                                    
        status = self.yofi.is_mesh_node_mpp()                                    
        self.assertTrue(status, 'YoFi-1 is not in MPP mode')                     
        self.log.info('YoFi-1 is in MPP mode')                                   
                                                                                 
        # Ping from Yofi-1(MPP) to Panel(MAP)
        status = self.yofi.ping(self.panel_map_ip)
        #self.assertTrue(status, 'Ping from YoFi-1(MPP) to panel(MAP) is failed')
        self.log.info('Ping from YoFi-1(MPP) to panel(MAP) is successfull')

        # Ping from Yofi-1(MPP) to Yofi-2(MAP)
        yofi_map_ip = self.multiple_yofi_handler['yofi-2']['yofi_ip']
        status = self.yofi.ping(yofi_map_ip)
        #self.assertTrue(status, 'Ping from YoFi-1(MPP) to YoFi-2(MAP) is failed')
        self.log.info('Ping from YoFi-1(MPP) to YoFi-2(MAP) is successfull')

        # Ping from Panel(MAP) to Yofi-2(MAP)
        status = self.panel.ping(yofi_map_ip)
        #self.assertTrue(status, 'Ping from panel(MAP) to YoFi-2(MAP) is failed')
        self.log.info('Ping from panel(MAP) to YoFi-2(MAP) is successfull')

        # Ping from Panel(MAP) to Yofi-1(MPP)
        status = self.panel.ping(self.config['panel']['nw_br_lan_ip'])
        #self.assertTrue(status, 'Ping from panel(MAP) to YoFi-1(MPP) is failed')
        self.log.info('Ping from panel(MAP) to YoFi-1(MPP) is successfull')
  
        # Gets the yofi-2 instance
        yofi_type = 'yofi-2'
        self.get_yofi_config(yofi_type)
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']

        # Ping from Yofi-2(MAP) to Panel(MAP)
        status = self.yofi.ping(self.panel_map_ip)
        #self.assertTrue(status, 'Ping from YoFi-2(MPP) to panel(MAP) is failed')
        self.log.info('Ping from YoFi-2(MAP) to panel(MAP) is successfull')

        # Ping from Yofi-2(MAP) to Yofi-1(MPP)
        status = self.yofi.ping(self.config['panel']['nw_br_lan_ip'])
        #self.assertTrue(status, 'Ping from yofi-2(MAP) to YoFi-1(MPP) is failed')
        self.log.info('Ping from Yofi-2(MAP) to YoFi-1(MPP) is successfull')

        # Gets the yofi-1 instance
        yofi_type = 'yofi-1'
        self.get_yofi_config(yofi_type)
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']

        # Topology check in MPP-YoFi-1
        status = self.verify_station_dump(self.yofi, self.config['panel']['sta_mac_addr'])
        self.assertTrue(status, 'Station dump check in YoFi is failed')
        self.log.info('Station dump check on mesh interface in YoFi is succeeded')

        # Topology check in MPP-YoFi-1
        status = self.verify_station_dump(self.yofi, self.config['yofi-2']['mac'])
        #self.assertTrue(status, 'Station dump check in YoFi is failed')
        self.log.info('Station dump check on mesh interface in YoFi is succeeded')

        # Topology check in panel MAP                                            
        status = self.verify_station_dump(self.panel, self.config['yofi-2']['mac'], panel_map_ip=self.panel_map_ip)
        self.assertTrue(status, 'Station dump check in Panel is failed')         
        self.log.info('Station dump check on mesh interface in Panel is succeeded')
                                                                                 
        # Topology check in Panel MAP                                            
        status = self.verify_station_dump(self.panel, self.config['yofi']['mac'], panel_map_ip=self.panel_map_ip)
        self.assertTrue(status, 'Station dump check in Panel is failed')         
        self.log.info('Station dump check on mesh interface in Panel is succeeded')

        # Gets the yofi-2 instance
        yofi_type = 'yofi-2'
        self.get_yofi_config(yofi_type)
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']

        # Topology check in MAP-YoFi-2
        status = self.verify_station_dump(self.yofi, self.config['panel']['sta_mac_addr'])
        self.assertTrue(status, 'Station dump check in YoFi is failed')
        self.log.info('Station dump check on mesh interface in YoFi is succeeded')

        # Topology check in MAP-YoFi-2
        status = self.verify_station_dump(self.yofi, self.config['yofi-1']['mac'])
        #self.assertTrue(status, 'Station dump check in YoFi is failed')
        self.log.info('Station dump check on mesh interface in YoFi is succeeded')

        # Check the star topology using mpath dump                               
        self.yofi.verify_star_topology(self.config['yofi-1']['mac'], self.config['panel']['sta_mac_addr'])

        # Displays the where the camera is connected using netv assoc 2.4         
        status = self.display_camera_connection_status(self.config['camera']['mac'])
        self.log.info('Display cameras connection status in YoFi-2 MAP')         
                                                                                 
        # Stop sniffer_1 capture                                                 
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_1')                      
            self.assertTrue(status, 'Sniffer_1 stop is failed')                  
        validation_5 = self.multiple_sniffer_handler['sniffer_1']['pcap_filename']

        # Gets the yofi-1 instance
        yofi_type = 'yofi-1'
        self.get_yofi_config(yofi_type)
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']

        # Start sniffer_1 capture                                                  
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_1', '5', 'camera_switch')
            self.assertTrue(status, 'Sniffer_1 start is failed')                 
                                                                                 
        # Start sniffer_2 capture                                                  
        if self.config['sniffer_2']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_2', '2.4', 'camera_switch')
            self.assertTrue(status, 'Sniffer_2 start is failed')                 
                                                                                 
        # Connecting camera to yofi-1 using bssid                                
        self.connect_camera_to_mesh_node('dbc_camera_1',                         
                                    self.config['yofi']['mac_for_wps_check'])

        # Stop sniffer_2 capture                                                 
        if self.config['sniffer_2']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_2')                      
            self.assertTrue(status, 'Sniffer_2 stop is failed')                  
        camera_switch_pcap = self.multiple_sniffer_handler['sniffer_2']['pcap_filename']

        # Camera video streamming                                                
        status = self.camera_stream_in_controller(camera_type_list,              
                                                  live_video_stream_duration=60,
                                                  validation_flag=False,         
                                                  yofi_mpp_ip=self.yofi_mpp_ip)  
        self.assertTrue(status, 'Camera streaming in controller is failed')      
                                                                                 
        # Ping to camera from panel                                              
        status = self.ping_from_panel_to_cams_in_background(camera_type_list, 60)
        self.assertTrue(status, 'ping from panel to camera is failed')           
        self.log.info('ping from panel to camera is successfully completed')     
                                                                                 
        status = self.validate_camera_stream_in_controller(camera_type_list,live_video_stream_duration=60)
                                                                                 
        if not status:                                                           
            ping_status = self.panel.stop_ping()                                 
            self.assertTrue(ping_status, 'Failed to stop ping')                  
            self.log.info('Successfully ping stopped')                           
                                                                                 
        ping_status = self.validate_ping(camera_type_list, 60)

        # Stop sniffer_1 capture                                                 
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_1')                      
            self.assertTrue(status, 'Sniffer_1 stop is failed')                  
        camera_switch_pcap_in_5 = self.multiple_sniffer_handler['sniffer_1']['pcap_filename']

        # Start sniffer_2 capture                                                  
        if self.config['sniffer_2']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_2', '2.4', 'soft_reboot_yofi')
            self.assertTrue(status, 'Sniffer_2 start is failed')                 

        # Start sniffer_1 capture                                                  
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_1', '5', 'soft_reboot_yofi')
            self.assertTrue(status, 'Sniffer_1 start is failed')

        # Reboot Yofi (MPP)
        status = self.yofi.reboot_yofi()                                       
        self.assertTrue(status, 'MPP yofi reboot is failed')                    
        self.log.info('MPP yofi reboot is succeeded') 

        time.sleep(30)

        # Stop sniffer_1 capture                                                   
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_1')                      
            self.assertTrue(status, 'Sniffer_1 stop is failed')                  
        soft_reboot_yofi = self.multiple_sniffer_handler['sniffer_1']['pcap_filename']

        # Start sniffer_1 capture                                                  
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_1', '5', 'after_soft_reboot_yofi')
            self.assertTrue(status, 'Sniffer_1 start is failed')

        # Station dump on Yofi MPP                      
        #status = self.verify_station_dump_fail(self.yofi, self.config['dbc_camera_1']['mac'], expiration_time=300)
        status = self.verify_is_device_connected_panel_or_yofi('yofi-2', self.config['dbc_camera_1']['mac'])
        if not status:                                                           
            self.log.info('Ignoring the expected error as panel is rebooted and connected back within short time')
        else:                                                                    
            self.log.info('Mesh teardown is done, Panel is disconnected from YoFi')
                                                                                 
        # Check the mesh n/w is up or not. Do ping from any yofi node to panel in polling
        try:                                                                     
            polling.poll(lambda: self.panel.ping(self.yofi_mpp_ip), step=20,     
                timeout=int(self.config['durations']['wait_for_fw_version_after_panel_reboot']))
            self.log.info('Mesh network is up after yofi reboot')               
        except polling.TimeoutException:                                         
            self.log.error('Failed to ping from panel to YoFi MPP')

        # Topology check in panel MAP                                            
        status = self.verify_station_dump(self.panel, self.config['yofi-2']['mac'], panel_map_ip=self.panel_map_ip)
        self.assertTrue(status, 'Station dump check in Panel is failed')         
        self.log.info('Station dump check on mesh interface in Panel is succeeded')
                                                                                 
        # Topology check in Panel MAP                                            
        status = self.verify_station_dump(self.panel, self.config['yofi-1']['mac'], panel_map_ip=self.panel_map_ip)
        self.assertTrue(status, 'Station dump check in Panel is failed')         
        self.log.info('Station dump check on mesh interface in Panel is succeeded')
        self.log.warning('Mesh network is not up after yofi reboot')  
                              
        # Camera video streamming                                                
        status = self.camera_stream_in_panel(camera_type_list, yofi_mpp_ip=self.yofi_mpp_ip, live_video_stream_duration=60)
        self.assertTrue(status, 'Camera streaming in panel is failed')           
        self.log.info('Camera streaming in panel are succeeded') 

        # Stop sniffer_1 capture                                                   
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_1')                      
            self.assertTrue(status, 'Sniffer_1 stop is failed')                  
                                                                                 
        after_soft_reboot_yofi = self.multiple_sniffer_handler['sniffer_1']['pcap_filename']

        # Stop sniffer_2 capture                                                 
        if self.config['sniffer_2']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_2')                      
            self.assertTrue(status, 'Sniffer_2 stop is failed')                  
        soft_reboot_yofi_24 = self.multiple_sniffer_handler['sniffer_2']['pcap_filename']
                                                  
        self.get_sniffer_utility_instance()                                      
                                                                                 
        panel_sta_mac = self.config['panel']['sta_mac_addr']                     
        yofi_1_mac = self.config['yofi-1']['mac']                                
        yofi_2_mac = self.config['yofi-2']['mac']                                
        panel_ap_mac = self.config['panel']['ap_mac_addr']                       
        yofi_1_mac_for_24 = self.config['yofi-1']['mac_for_wps_check']           
        yofi_2_mac_for_24 = self.config['yofi-2']['mac_for_wps_check']           
                                                                                 
        # Sniffer_1 frame analysis for Yofi-1                                              
        self.log.info('Sniffer_1 analysis between YoFi-1(MPP) and panel(MAP)')   
        self.log.info('Sniffer_1 pcap file: {}'.format(add_yofi_1_pcap_in_5))    
        status = self.sniffer_analysis.validate_MPP_and_MAP_connection_with_sae_and_peer_action_frames(add_yofi_1_pcap_in_5, yofi_1_mac, panel_sta_mac)
                                                                                 
        # Sniffer_1 frame analysis for Yofi-2
        self.log.info('Sniffer_1 analysis between YoFi-1(MPP) and panel(MAP)')   
        self.log.info('Sniffer_1 pcap file: {}'.format(add_yofi_2_pcap_in_5))    
        status = self.sniffer_analysis.validate_MPP_and_MAP_connection_with_sae_and_peer_action_frames(add_yofi_2_pcap_in_5, yofi_2_mac, panel_sta_mac)
       
        # Sniffer_2 frame analysis, Source Mac should be STA (YoFi)              
        self.log.info('Sniffer_2 analysis between YoFi-2(MAP) and Panel(MAP)')   
        self.log.info('Sniffer_2 pcap file: {}'.format(add_yofi_2_pcap_in_24))   
        status = self.sniffer_analysis.wps_connect(add_yofi_2_pcap_in_24, yofi_2_mac_for_24, panel_ap_mac)
 
        # Sniffer_2 packet check M1/M2 packet analysis                                                  
        self.log.info('Sniffer_2 packet checking')                               
        total_errors = {}                                                        
        for camera_type_name in ['dbc_camera_1']:
            self.get_camera_config(camera_type_name)                             
            self.log.info('#################################################')   
            self.log.info('Started WPS IE validation for {}'.format(camera_type_name))
            self.log.info('Sniffer_2 pcap file: {}'.format(add_camera_pcap))
            camera_mac = self.config[camera_type_name]['mac']                    
            status, errors = self.sniffer_analysis.GES_Vivint_Yofi_PAK_0016_24G_analysis(add_camera_pcap, self.config)
            status_camera_add = self.sniffer_analysis.wps_connect(add_camera_pcap, camera_mac, panel_ap_mac)
            if not status_camera_add:                                            
                errors.append('WPS connection is failed')                        
            total_errors[camera_type_name] = errors                              
            self.log.info('WPS IE validation is done for {}'.format(camera_type_name))
            self.log.info('#################################################')   
                                                                                 
        for camera_type_name in total_errors.keys():                             
            self.log.info('#################################################')   
            self.log.info('Errors found during validation of {}'.format(camera_type_name))
            self.log.info('#################################################')   
            for error in total_errors[camera_type_name]:                         
                self.log.error('{} of {}'.format(error, camera_type_name))       
            self.log.info('#################################################')   
        error_length = [len(total_errors[item]) for item in total_errors]        
        if not all(i == 0 for i in error_length):                                
            self.log.error('M1/M2 packet check failed')                          
                                                                                 
        # Sniffer_2 frames analysis for camera switch                                               
        self.log.info('Sniffer_2 packet checking for camera switch')             
        total_errors = {}                                                        
        for camera_type_name in ['dbc_camera_1']:               
            self.get_camera_config(camera_type_name)                             
            self.log.info('Started WPS connection validation for {}'.format(camera_type_name))
            self.log.info('Sniffer_2 pcap file: {}'.format(camera_switch_pcap))
            camera_mac = self.config[camera_type_name]['mac']                    
            status = self.sniffer_analysis.connection_over_24GHz(camera_switch_pcap, camera_mac, yofi_1_mac_for_24)

        # Sniffer_1 packet check                                                    
        self.log.info('Sniffer_1 packet checking')                                 
        self.log.info('Sniffer_1 pcap file: {}'.format(soft_reboot_yofi))       
        status = self.sniffer_analysis.mesh_peer_close_5G_analysis(soft_reboot_yofi, yofi_1_mac, panel_sta_mac)

        # Sniffer_1 packet check                                                    
        self.log.info('Sniffer_1 packet checking')                                 
        self.log.info('Sniffer_1 pcap file: {}'.format(soft_reboot_yofi))       
        status = self.sniffer_analysis.mesh_peer_close_5G_analysis(soft_reboot_yofi, yofi_1_mac, yofi_2_mac)

        # Sniffer_2 frame analysis, Validate the disassoc/deauth frame of YoFi-1 for connected STA    
        self.log.info('Sniffer_2 analysis between YoFi MPP and Camera')  
        self.log.info('Sniffer_2 pcap file: {}'.format(soft_reboot_yofi_24))     
        status = self.sniffer_analysis.disconnection_24G_analysis(soft_reboot_yofi_24, yofi_1_mac, self.config['dbc_camera_1']['mac'])

        # Sniffer_1 frame analysis for Yofi-1 after reboot                                             
        self.log.info('Sniffer_1 analysis between YoFi-1(MPP) and panel(MAP)')   
        self.log.info('Sniffer_1 pcap file: {}'.format(after_soft_reboot_yofi))    
        status = self.sniffer_analysis.validate_MPP_and_MAP_connection_with_sae_and_peer_action_frames(after_soft_reboot_yofi, yofi_1_mac, panel_sta_mac)
                                                                                
        self.assertTrue(ping_status, 'ping verification failed')                 
        self.log.info('Successfully verified ping')

    @attr(test_category='TOPOLOGY')
    @attr(test_id='GES_Vivint_Yofi_TOP_0004')
    @nose.allure.severity(nose.allure.severity_level.CRITICAL)
    @nose.allure.feature('Daisy Chain Topology with one MPP(Panel) and 2 MAP(YoFi)')
    def test_05_GES_Vivint_Yofi_TOP_0004(self):
        """Daisy Chain Topology with one MPP(Panel) and 2 MAP(YoFi)
        :Vivint Testrail ID : C1168017
        :Test Case ID: GES_Vivint-Yofi_TOP_0004
        :author: GES automation dev
        """
        self.log.info('======= Testcase started =======')
        self.testcase_name = sys._getframe().f_code.co_name
        test_case = getattr(self, self.testcase_name)
        self.log_path = '{}{}/{}/'.format(self.config['controller']['log_path'], execution_log_path, test_case.test_category)
        self.log.debug('Fun name: {}\n'.format(self.testcase_name))

        # Creating log directory with testcase_name
        self.log_path_with_test_name =  self.cntl.create_log_dir_with_testcase_name(self.log_path, self.testcase_name)
        self.log.info('Log path of testcase directory: {}'.format(self.log_path_with_test_name))

        camera_type_list = ['dbc_camera_1', 'ping_camera_1']    
        self.check_cameras_in_ap_mode(camera_type_list)

        status = self.att_obj.set_all_channel_to_high_attenuation(               
                                    self.config['attenuator']['attenuator_1'])   
        self.assertTrue(status, 'Set all channel to high attenuation_1 is failed') 
        self.log.info('Set all channel to high attenuation_1 is successful')

        # Turn on the panel signal in RF box-1                                  
        status = self.att_obj.set_attenuation(self.config['attenuator']['on'],  
                                    self.config['attenuator']['channel_1'],     
                                    self.config['attenuator']['attenuator_1'])  
        self.assertTrue(status, 'Passing panel signal in RF box-1 is failed')   
        self.attenuator_1 = True

        # Configure panel as MPP                                                 
        self.panel_mpp_ip = self.configure_mpp(self.panel)                       
        self.assertTrue(self.panel_mpp_ip, 'get MPP IP address is failed')       
                                                                                 
        '''
        # Get mesh ID and psk from panel                                         
        status = self.panel.get_mesh_id_and_psk()                                
        self.assertTrue(status, 'Failed to get mesh_id and wps_psk')             
        '''
                                                                                 
        # Start sniffer_2 capture                                                  
        if self.config['sniffer_2']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_2', '2.4', 'add_camera')
            self.assertTrue(status, 'Sniffer_2 start is failed')                 
                                                                                 
        # Select the PCI card                                                    
        self.log.info('Outside wireless adapter mac: {}'.format(                 
                                self.config['controller']['outside_wireless_adapter_mac']))
        self.cntl.pci_mac=self.config['controller']['outside_wireless_adapter_mac']
                                                                                 
        # Gets the camera instance                                               
        self.get_camera_instance('dbc_camera_1')                                
                                                                                 
        # Add Camera                                                             
        status = self.add_camera_to_panel('wps')                                 
        self.assertTrue(status, 'camera addition is failed')                     
        self.log.info('camera addition is succeeded')

        # Select the PCI card                                                    
        self.log.info('RF-1 wireless adapter card: {}'.format(                   
                                self.config['controller']['rf1_wireless_adapter_mac']))
        self.cntl.pci_mac=self.config['controller']['rf1_wireless_adapter_mac']  
                                                                                 
        # Start sniffer_4 capture                                                  
        if self.config['sniffer_4']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_4', '2.4', 'rf_1_add_camera')
            self.assertTrue(status, 'Sniffer_4 start is failed')                 
                                                                                 
        # Gets the camera instance                                               
        self.get_camera_instance('ping_camera_1')                                
                                                                                 
        # Add Camera                                                             
        status = self.add_camera_to_panel('wps')                                 
        self.assertTrue(status, 'camera addition is failed')                     
        self.log.info('camera addition is succeeded')                            
                                                                                 
        # Stop sniffer_2 capture                                                 
        if self.config['sniffer_2']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_2')                      
            self.assertTrue(status, 'Sniffer_2 stop is failed')                  
        add_camera_pcap = self.multiple_sniffer_handler['sniffer_2']['pcap_filename']
                                                                                 
        # Stop sniffer_4 capture                                                 
        if self.config['sniffer_4']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_4')                      
            self.assertTrue(status, 'Sniffer_4 stop is failed')                  
        rf_1_add_camera_pcap = self.multiple_sniffer_handler['sniffer_4']['pcap_filename']
                                                                                 
        # Gets the yofi-1 instance                                               
        self.get_yofi_instance('yofi-2')

        # Start sniffer_1 capture                                                  
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_1', '5', 'adding_yofi_2_to_panel', sniffer_flag=False)
            self.assertTrue(status, 'Sniffer_1 start is failed')                 
                                                                                 
        # Start sniffer_2 capture                                                
        if self.config['sniffer_2']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_2', '2.4', 'adding_yofi_2_to_panel')
            self.assertTrue(status, 'Sniffer_2 start is failed')

        # Add yofi-2                                                               
        status = self.add_yofi_node_to_panel('wps')                              
        self.assertTrue(status, 'yofi-2 addition is failed')                     
        self.log.info('yofi-2 addition is succeeded')

        # Stop sniffer_1 capture                                                 
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_1')                      
            self.assertTrue(status, 'Sniffer_1 stop is failed')                  
        add_yofi_2_pcap_in_5  = self.multiple_sniffer_handler['sniffer_1']['pcap_filename']
                                                                                 
        # Stop sniffer_2 capture                                                 
        if self.config['sniffer_2']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_2')                      
            self.assertTrue(status, 'Sniffer_2 stop is failed')                  
        add_yofi_2_pcap_in_24  = self.multiple_sniffer_handler['sniffer_2']['pcap_filename']
                                                                                 
        # TODO RSSI of panel should less than -60, RSSI of YoFi-1 should not available or more than -70
        # If not work do attenuate 30dB instead of 0dB
        exp_mac_list = [self.config['panel']['ap_mac_addr'], self.config['panel']['sta_mac_addr']]
        unexp_mac_list = [self.config['yofi-2']['mac'], self.config['yofi-2']['mac_for_wps_check']]
        status = self.cntl.get_signal_strength_in_controller(
                        self.config['controller']['rf1_wireless_adapter_mac'],
                        exp_mac_list, unexp_mac_list)
        #self.assertTrue(status, 'Getting RSSI value in RF box-1 is failed')

        # Start sniffer_1 capture                                                  
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_1', '5', 'valiadtion')
            self.assertTrue(status, 'Sniffer_1 start is failed')                 
                                                                                 
        # Gets the yofi-3 instance
        self.get_yofi_instance('yofi-3')

        # Start sniffer_3 capture                                                  
        if self.config['sniffer_3']['enable'].lower() == 'true':
            status = self.start_sniffer_capture('sniffer_3', '5', 'adding_yofi_3_to_panel')
            self.assertTrue(status, 'Sniffer_3 start is failed')

        # Start sniffer_4 capture
        if self.config['sniffer_4']['enable'].lower() == 'true':
            status = self.start_sniffer_capture('sniffer_4', '2.4', 'adding_yofi_3_to_panel')
            self.assertTrue(status, 'Sniffer_4 start is failed')

        # Add yofi-3
        status = self.add_yofi_node_to_panel('wps')
        self.assertTrue(status, 'yofi-3 addition is failed')
        self.log.info('yofi-3 addition is succeeded')

        # Stop sniffer_4 capture
        if self.config['sniffer_4']['enable'].lower() == 'true':
            status = self.stop_sniffer_capture('sniffer_4')
            self.assertTrue(status, 'Sniffer_4 stop is failed')
        add_yofi_3_pcap_in_24  = self.multiple_sniffer_handler['sniffer_4']['pcap_filename']

        # Stop sniffer_3 capture                                                 
        if self.config['sniffer_3']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_3')                      
            self.assertTrue(status, 'Sniffer_3 stop is failed')                  
        add_yofi_3_pcap_in_5 = self.multiple_sniffer_handler['sniffer_3']['pcap_filename']   

        # Start sniffer_3 capture                                                  
        if self.config['sniffer_3']['enable'].lower() == 'true':
            status = self.start_sniffer_capture('sniffer_3', '5', 'rf_1_linear')
            self.assertTrue(status, 'Sniffer_3 start is failed')

        # Get channel from YoFi-3                                                
        yofi_3_channel = self.yofi.get_channel('wlan1')                          
        self.assertTrue(yofi_3_channel, 'Getting YoFi-3 2.4GHz channel is failed')
                                                                                 
        # Start sniffer_4 capture                                                
        if self.config['sniffer_4']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_4', '2.4', 'rf_1_camera_switch', yofi_3_channel)
            self.assertTrue(status, 'Sniffer_4 start is failed')                 
                                                                                 
        # Turn off the panel signal in RF box-1                                  
        status = self.att_obj.set_attenuation(self.config['attenuator']['off'],  
                                    self.config['attenuator']['channel_1'],      
                                    self.config['attenuator']['attenuator_1'])   
        self.assertTrue(status, 'Blocking panel signal in RF box-1 is failed')   
                                                                                 
        time.sleep(10)                                                           
                                                                                 
        # Turn on the YoFi-2 signal in RF box-1                                  
        status = self.att_obj.set_attenuation(self.config['attenuator']['on'],   
                                    self.config['attenuator']['channel_1'],      
                                    self.config['attenuator']['attenuator_2'])   
        self.assertTrue(status, 'Passing YoFi-2 signal in RF box-1 is failed')

        # Verify YoFi-3 node is MAP mesh type
        status = self.yofi.is_mesh_node_map()
        self.assertTrue(status, 'YoFi-3 is not in MAP mode')
        self.log.info('YoFi-3 is in MAP mode')

        # Verify panel node is MPP mesh type                                     
        status = self.panel.is_mesh_node_mpp()                                   
        self.assertTrue(status, 'Panel is not in MPP mode')                      
        self.log.info('Panel is in MPP mode')
                                                                                 
        yofi_type = 'yofi-2'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']              
                                                                                 
        # Verify YoFi-2 node is MAP mesh type
        status = self.yofi.is_mesh_node_map()
        self.assertTrue(status, 'YoFi-2 is not in MAP mode')
        self.log.info('YoFi-2 is in MAP mode')

        # Ping from Yofi-2(MAP) to Panel(MPP)                                    
        status = self.yofi.ping(self.config['panel']['nw_br_lan_ip'])            
        #self.assertTrue(status, 'Ping from YoFi-2(MAP) to panel(MPP) is failed') 
        self.log.info('Ping from YoFi-2(MAP) to panel(MPP) is successfull')      
                                                                                 
        # Ping from Yofi-2(MAP) to Yofi-3(MAP)                                   
        status = self.yofi.ping(self.multiple_yofi_handler['yofi-3']['yofi_ip']) 
        #self.assertTrue(status, 'Ping from yofi-2(MAP) to YoFi-3(MAP) is failed')
        self.log.info('Ping from Yofi-2(MAP) to YoFi-3(MAP) is successfull')

        # Ping from Panel(MPP) to Yofi-2(MAP)                                    
        status = self.panel.ping(self.multiple_yofi_handler['yofi-2']['yofi_ip'])
        #self.assertTrue(status, 'Ping from panel(MPP) to YoFi-2(MAP) is failed') 
        self.log.info('Ping from panel(MPP) to YoFi-2(MAP) is successfull')

        # Ping from Panel(MPP) to Yofi-3(MAP)                                    
        status = self.panel.ping(self.multiple_yofi_handler['yofi-3']['yofi_ip'])                                    
        # TODO
        #self.assertTrue(status, 'Ping from panel(MPP) to YoFi-3(MAP) is failed') 
        self.log.info('Ping from panel(MPP) to YoFi-3(MAP) is successfull')      
                                                                                 
        yofi_type = 'yofi-3'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']              
                                                                                 
        # Ping from Yofi-3(MAP) to Panel(MPP)                                    
        status = self.yofi.ping(self.config['panel']['nw_br_lan_ip'])            
        # TODO
        #self.assertTrue(status, 'Ping from YoFi-3(MAP) to panel(MPP) is failed') 
        self.log.info('Ping from YoFi-3(MAP) to panel(MPP) is successfull')      
                                                                                 
        # Ping from Yofi-3(MAP) to Yofi-2(MAP)                                   
        status = self.yofi.ping(self.multiple_yofi_handler['yofi-2']['yofi_ip']) 
        #self.assertTrue(status, 'Ping from yofi-3(MAP) to YoFi-2(MAP) is failed')
        self.log.info('Ping from Yofi-3(MAP) to YoFi-2(MAP) is successfull')

        # Get mesh graph .svg file from panel if this flag True
        self.mesh_graph_flag = True

        # Topology check in MAP-YoFi-3                                            
        status = self.verify_station_dump(self.yofi, self.config['yofi-2']['mac'])
        self.assertTrue(status, 'Station dump check in YoFi is failed')          
        self.log.info('Station dump check on mesh interface in YoFi is succeeded')
                                                                                 
        # Topology check in MAP-YoFi-3                                           
        status = self.verify_station_dump(self.yofi, self.config['panel']['sta_mac_addr'])
        # TODO should not found
        #self.assertTrue(status, 'Station dump check in YoFi is failed')          
        self.log.info('Station dump check on mesh interface in YoFi is succeeded')

        # Topology check in panel MPP                                            
        status = self.verify_station_dump(self.panel, self.config['yofi-2']['mac'])
        self.assertTrue(status, 'Station dump check in Panel is failed')         
        self.log.info('Station dump check on mesh interface in Panel is succeeded')
                                                                                 
        # Topology check in Panel MPP                                            
        status = self.verify_station_dump(self.panel, self.config['yofi-3']['mac'])
        # TODO should not found
        #self.assertTrue(status, 'Station dump check in Panel is failed')         
        self.log.info('Station dump check on mesh interface in Panel is succeeded')
                                                                                 
        # Gets the yofi-2 instance                                               
        yofi_type = 'yofi-2'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']              
                                                                                 
        # Topology check in MAP-YoFi-2                                            
        status = self.verify_station_dump(self.yofi, self.config['yofi-3']['mac'])
        self.assertTrue(status, 'Station dump check in YoFi is failed')          
        self.log.info('Station dump check on mesh interface in YoFi is succeeded')
                                                                                 
        # Topology check in MAP-YoFi-2                                            
        status = self.verify_station_dump(self.yofi, self.config['panel']['sta_mac_addr'])
        self.assertTrue(status, 'Station dump check in YoFi is failed')          
        self.log.info('Station dump check on mesh interface in YoFi is succeeded')
                                                                                 
        # TODO RSSI of panel should less than -60, RSSI of YoFi-1 should not available or more than -70
        # If not work do attenuate 30dB instead of 0dB
        exp_mac_list = [self.config['panel']['ap_mac_addr'], self.config['panel']['sta_mac_addr']]
        unexp_mac_list = [self.config['yofi-2']['mac'], self.config['yofi-2']['mac_for_wps_check']]
        status = self.cntl.get_signal_strength_in_controller(
                        self.config['controller']['rf1_wireless_adapter_mac'],
                        exp_mac_list, unexp_mac_list)
        #self.assertTrue(status, 'Getting RSSI value in RF box-1 is failed')

        exp_mac_list = [self.config['panel']['ap_mac_addr'], self.config['panel']['sta_mac_addr']]
        unexp_mac_list = [self.config['yofi-3']['mac'], self.config['yofi-3']['mac_for_wps_check']]
        status = self.cntl.get_signal_strength_in_controller(
                        self.config['controller']['outside_wireless_adapter_mac'],
                        exp_mac_list, unexp_mac_list)
        #self.assertTrue(status, 'Getting RSSI value is failed')

        # TODO If fails, Do attenuate 20dB and check again

        # Check the linear topology using mpath dump, next hop node mac and dest node mac
        self.panel.verify_linear_topology(self.config['yofi-2']['mac'], self.config['yofi-3']['mac'])
        # TODO 
        #self.assertTrue(status, 'Linear topology check in YoFi-3 is failed')
                                                                                 
        # Netv assoc for 5GHz
        self.display_mesh_node_connection_status(self.config['panel']['sta_mac_addr'], panel_flag=True)

        # Displays the where the camera is connected using netv assoc 2.4         
        status = self.display_camera_connection_status(self.config['camera']['mac'], panel_flag=True)
        self.log.info('Display cameras connection status in Panel MPP')         
                                                                                 
        # Stop sniffer_1 capture                                                 
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_1')                      
            self.assertTrue(status, 'Sniffer_1 stop is failed')                  
        validation_5 = self.multiple_sniffer_handler['sniffer_1']['pcap_filename']
                                                                                 
        # Stop sniffer_3 capture                                                 
        if self.config['sniffer_3']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_3')                      
            self.assertTrue(status, 'Sniffer_3 stop is failed')                  
        rf_1_linear_validation = self.multiple_sniffer_handler['sniffer_3']['pcap_filename']
                                                                                 
        # Start sniffer_1 capture                                                  
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_1', '5', 'camera_switch')
            self.assertTrue(status, 'Sniffer_1 start is failed')                 
                                                                                 
        # Start sniffer_3 capture                                                  
        if self.config['sniffer_3']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_3', '5', 'rf_1_camera_switch')
            self.assertTrue(status, 'Sniffer_3 start is failed')                 
                                                                                 
        # Get channel from YoFi-2                                                
        yofi_2_channel = self.yofi.get_channel('wlan1')                          
        self.assertTrue(yofi_2_channel, 'Getting YoFi-2 2.4GHz channel is failed')
                                                                                 
        # Start sniffer_2 capture                                                
        if self.config['sniffer_2']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_2', '2.4', 'camera_switch', yofi_2_channel)
            self.assertTrue(status, 'Sniffer_2 start is failed')                 
                                                                                 
        # Connecting camera to mesh node using bssid                                 
        self.connect_camera_to_mesh_node('dbc_camera_1', self.config['yofi-2']['mac_for_wps_check'])

        self.get_camera_config('ping_camera_1')                                  

        # Gets the yofi-3 instance                                               
        yofi_type = 'yofi-3'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']              
                                                                                 
        # Topology check in MPP-YoFi, Camera should connected to YoFi            
        status = self.verify_station_dump(self.yofi, self.config['camera']['mac'], 'wlan1')
        self.assertTrue(status, 'Station dump check in YoFi is failed')          
        self.log.info('Station dump check on 2.4GHz interface in YoFi is succeeded')

        # Stop sniffer_2 capture                                                 
        if self.config['sniffer_2']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_2')                      
            self.assertTrue(status, 'Sniffer_2 stop is failed')                  
        camera_switch_pcap = self.multiple_sniffer_handler['sniffer_2']['pcap_filename']
                                                                                 
        # Stop sniffer_4 capture                                                 
        if self.config['sniffer_4']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_4')                      
            self.assertTrue(status, 'Sniffer_4 stop is failed')                  
        rf_1_camera_switch_pcap = self.multiple_sniffer_handler['sniffer_4']['pcap_filename']
                                                                                 
        # Camera video streamming                                                
        status = self.camera_stream_in_controller(camera_type_list,              
                                                  live_video_stream_duration=self.config['durations']['live_video_stream'],
                                                  validation_flag=False)         
        self.assertTrue(status, 'Camera streaming in controller is failed')      
                                                                                 
        # Ping to camera from panel                                              
        status = self.ping_from_panel_to_cams_in_background(camera_type_list, self.config['durations']['live_video_stream'])
        self.assertTrue(status, 'ping from panel to camera is failed')           
        self.log.info('ping from panel to camera is successfully completed')     
                                                                                 
        status = self.validate_camera_stream_in_controller(camera_type_list,live_video_stream_duration=self.config['durations']['live_video_stream'])
                                                                                 
        if not status:
            ping_status = self.panel.stop_ping()                                 
            self.assertTrue(ping_status, 'Failed to stop ping')                  
            self.log.info('Successfully ping stopped')                           
                                                                                 
        ping_status = self.validate_ping(camera_type_list, self.config['durations']['live_video_stream'])
                                                                                 
        # Stop sniffer_1 capture                                                 
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_1')                      
            self.assertTrue(status, 'Sniffer_1 stop is failed')                  
        camera_switch_pcap_in_5 = self.multiple_sniffer_handler['sniffer_1']['pcap_filename']
                                                                                 
        # Stop sniffer_3 capture                                                 
        if self.config['sniffer_3']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_3')                      
            self.assertTrue(status, 'Sniffer_1 stop is failed')                  
        rf_1_camera_switch_pcap_in_5 = self.multiple_sniffer_handler['sniffer_3']['pcap_filename']
                                                                                 
        self.get_sniffer_utility_instance()                                      
                                                                                 
        panel_sta_mac = self.config['panel']['sta_mac_addr']                     
        yofi_2_mac = self.config['yofi-2']['mac']                                
        yofi_3_mac = self.config['yofi-3']['mac']                                
        panel_ap_mac = self.config['panel']['ap_mac_addr']                       
        yofi_2_mac_for_24 = self.config['yofi-2']['mac_for_wps_check']           
        yofi_3_mac_for_24 = self.config['yofi-3']['mac_for_wps_check']           
                                                                                 
        # Sniffer_1 frame analysis                                               
        self.log.info('Sniffer_1 analysis between YoFi-2(MAP) and panel(MPP)')   
        self.log.info('Sniffer_1 pcap file: {}'.format(add_yofi_2_pcap_in_5))    
        status = self.sniffer_analysis.validate_MPP_and_MAP_connection_with_sae_and_peer_action_frames(add_yofi_2_pcap_in_5, yofi_2_mac, panel_sta_mac)
                                                                                 
        # Sniffer_2 frame analysis, Source Mac should be STA (YoFi)              
        self.log.info('Sniffer_2 analysis between YoFi-2(MAP) and panel(MPP)')   
        self.log.info('Sniffer_2 pcap file: {}'.format(add_yofi_2_pcap_in_24))   
        status = self.sniffer_analysis.wps_connect(add_yofi_2_pcap_in_24, yofi_2_mac_for_24, panel_ap_mac)
                                                                                 
        # Sniffer_1 frame analysis                                               
        self.log.info('Sniffer_1 analysis between YoFi-3(MAP) and panel(MPP)')   
        self.log.info('Sniffer_1 pcap file: {}'.format(add_yofi_3_pcap_in_5))    
        status = self.sniffer_analysis.validate_MPP_and_MAP_connection_with_sae_and_peer_action_frames(add_yofi_3_pcap_in_5, yofi_3_mac, panel_sta_mac)
                                                                                 
        # Sniffer_2 frame analysis, Source Mac should be STA (YoFi)              
        self.log.info('Sniffer_2 analysis between YoFi-3(MAP) and panel(MPP)')   
        self.log.info('Sniffer_2 pcap file: {}'.format(add_yofi_3_pcap_in_24))   
        status = self.sniffer_analysis.wps_connect(add_yofi_3_pcap_in_24, yofi_3_mac_for_24, panel_ap_mac)

        # Sniffer_3 frame analysis                                               
        self.log.info('Sniffer_3 analysis between YoFi-3(MAP) and YoFi-2(MAP)')  
        self.log.info('Sniffer_3 pcap file: {}'.format(rf_1_linear_validation))  
        status = self.sniffer_analysis.validate_MPP_and_MAP_connection_with_sae_and_peer_action_frames(rf_1_linear_validation, yofi_2_mac, yofi_3_mac)

        # Sniffer_2 packet check M1/M2 packet analysis                                                  
        self.log.info('Sniffer_2 packet checking')                               
        total_errors = {}                                                        
        for camera_type_name in ['dbc_camera_1']:
            self.get_camera_config(camera_type_name)                             
            self.log.info('#################################################')   
            self.log.info('Started WPS IE validation for {}'.format(camera_type_name))
            self.log.info('Sniffer_2 pcap file: {}'.format(add_camera_pcap))
            camera_mac = self.config[camera_type_name]['mac']                    
            status, errors = self.sniffer_analysis.GES_Vivint_Yofi_PAK_0016_24G_analysis(add_camera_pcap, self.config)
            status_camera_add = self.sniffer_analysis.wps_connect(add_camera_pcap, camera_mac, panel_ap_mac)
            if not status_camera_add:                                            
                errors.append('WPS connection is failed')                        
            total_errors[camera_type_name] = errors                              
            self.log.info('WPS IE validation is done for {}'.format(camera_type_name))
            self.log.info('#################################################')   
                                                                                 
        for camera_type_name in total_errors.keys():                             
            self.log.info('#################################################')   
            self.log.info('Errors found during validation of {}'.format(camera_type_name))
            self.log.info('#################################################')   
            for error in total_errors[camera_type_name]:                         
                self.log.error('{} of {}'.format(error, camera_type_name))       
            self.log.info('#################################################')   
        error_length = [len(total_errors[item]) for item in total_errors]        
        if not all(i == 0 for i in error_length):                                
            self.log.error('M1/M2 packet check failed')                          
                                                                                 
        # Sniffer_4 packet check M1/M2 packet analysis                                                  
        self.log.info('Sniffer_4 packet checking')                               
        total_errors = {}                                                        
        for camera_type_name in ['ping_camera_1']:                               
            self.get_camera_config(camera_type_name)                             
            self.log.info('#################################################')   
            self.log.info('Started WPS IE validation for {}'.format(camera_type_name))
            self.log.info('Sniffer_4 pcap file: {}'.format(rf_1_add_camera_pcap))
            camera_mac = self.config[camera_type_name]['mac']                    
            status, errors = self.sniffer_analysis.GES_Vivint_Yofi_PAK_0016_24G_analysis(rf_1_add_camera_pcap, self.config)
            status_camera_add = self.sniffer_analysis.wps_connect(rf_1_add_camera_pcap, camera_mac, panel_ap_mac)
            if not status_camera_add:                                            
                errors.append('WPS connection is failed')                        
            total_errors[camera_type_name] = errors                              
            self.log.info('WPS IE validation is done for {}'.format(camera_type_name))
            self.log.info('#################################################')   
                                                                                 
        for camera_type_name in total_errors.keys():                             
            self.log.info('#################################################')   
            self.log.info('Errors found during validation of {}'.format(camera_type_name))
            self.log.info('#################################################')
            for error in total_errors[camera_type_name]:                         
                self.log.error('{} of {}'.format(error, camera_type_name))       
            self.log.info('#################################################')   
            error_length = [len(total_errors[item]) for item in total_errors]    
        if not all(i == 0 for i in error_length):                                
            self.log.error('M1/M2 packet check failed')                          
                                                                                 
        # Sniffer_2 frames analysis for camera switch                                               
        self.log.info('Sniffer_2 packet checking for camera switch')             
        total_errors = {}                                                        
        for camera_type_name in ['dbc_camera_1']:               
            self.get_camera_config(camera_type_name)                             
            self.log.info('Started WPS connection validation for {}'.format(camera_type_name))
            self.log.info('Sniffer_2 pcap file: {}'.format(camera_switch_pcap))
            camera_mac = self.config[camera_type_name]['mac']                    
            status = self.sniffer_analysis.connection_over_24GHz(camera_switch_pcap, camera_mac, yofi_2_mac_for_24)

        # Sniffer_4 frames analysis for camera switch                                                 
        self.log.info('Sniffer_4 packet checking for camera switch')             
        total_errors = {}                                                        
        for camera_type_name in ['ping_camera_1']:                               
            self.get_camera_config(camera_type_name)                             
            self.log.info('Started WPS connection validation for {}'.format(camera_type_name))
            self.log.info('Sniffer_4 pcap file: {}'.format(rf_1_camera_switch_pcap))
            camera_mac = self.config[camera_type_name]['mac']                    
            status = self.sniffer_analysis.connection_over_24GHz(rf_1_camera_switch_pcap, camera_mac, yofi_3_mac_for_24)
                                                                                 
        self.assertTrue(ping_status, 'ping verification failed')                 
        self.log.info('Successfully verified ping')

    @attr(test_category='TOPOLOGY')
    @attr(test_id='GES_Vivint_Yofi_TOP_0005')
    @nose.allure.severity(nose.allure.severity_level.CRITICAL)
    @nose.allure.feature('Power off (delete) MAP-1(YoFi) in Daisy chain topology')
    def test_06_GES_Vivint_Yofi_TOP_0005(self):
        """Power off (delete) MAP-1(YoFi) in Daisy chain topology
        :Vivint Testrail ID : C1168018
        :Test Case ID: GES_Vivint_Yofi_TOP_0004
        :author: GES automation dev
        """
        self.log.info('======= Testcase started =======')
        self.testcase_name = sys._getframe().f_code.co_name
        test_case = getattr(self, self.testcase_name)
        self.log_path = '{}{}/{}/'.format(self.config['controller']['log_path'], execution_log_path, test_case.test_category)
        self.log.debug('Fun name: {}\n'.format(self.testcase_name))

        # Creating log directory with testcase_name
        self.log_path_with_test_name =  self.cntl.create_log_dir_with_testcase_name(self.log_path, self.testcase_name)
        self.log.info('Log path of testcase directory: {}'.format(self.log_path_with_test_name))

        camera_type_list = ['dbc_camera_2', 'ping_camera_2']    
        self.check_cameras_in_ap_mode(camera_type_list)

        status = self.att_obj.set_all_channel_to_high_attenuation(               
                                    self.config['attenuator']['attenuator_1'])   
        self.assertTrue(status, 'Set all channel to high attenuation_1 is failed') 
        self.log.info('Set all channel to high attenuation_1 is successful')

        status = self.att_obj.set_all_channel_to_high_attenuation(               
                                    self.config['attenuator']['attenuator_2'])   
        self.assertTrue(status, 'Set all channel to high attenuation_2 is failed') 
        self.log.info('Set all channel to high attenuation_2 is successful')

        # Turn on the panel signal in RF box-1                                  
        status = self.att_obj.set_attenuation(self.config['attenuator']['on'],  
                                    self.config['attenuator']['channel_1'],     
                                    self.config['attenuator']['attenuator_1'])  
        self.assertTrue(status, 'Passing panel signal in RF box-1 is failed')   
        self.attenuator_1 = True

        # Turn on the panel signal in RF box-2                                  
        status = self.att_obj.set_attenuation(self.config['attenuator']['on'],  
                                    self.config['attenuator']['channel_2'],     
                                    self.config['attenuator']['attenuator_1'])  
        self.assertTrue(status, 'Passing panel signal in RF box-2 is failed')   
        self.attenuator_2 = True

        # Configure panel as MPP                                                 
        self.panel_mpp_ip = self.configure_mpp(self.panel)                       
        self.assertTrue(self.panel_mpp_ip, 'get MPP IP address is failed')       
                                                                                 
        '''
        # Get mesh ID and psk from panel                                         
        status = self.panel.get_mesh_id_and_psk()                                
        self.assertTrue(status, 'Failed to get mesh_id and wps_psk')             
        '''
                                                                                 
        # Select the PCI card                                                    
        self.log.info('RF-1 wireless adapter card: {}'.format(                   
                                self.config['controller']['rf1_wireless_adapter_mac']))
        self.cntl.pci_mac=self.config['controller']['rf1_wireless_adapter_mac']  
                                                                                 
        # Start sniffer_4 capture                                                  
        if self.config['sniffer_4']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_4', '2.4', 'rf_1_add_camera')
            self.assertTrue(status, 'Sniffer_4 start is failed')                 
                                                                                 
        # Gets the camera instance                                               
        self.get_camera_instance('dbc_camera_2')                                
                                                                                 
        # Add Camera                                                             
        status = self.add_camera_to_panel('wps')                                 
        self.assertTrue(status, 'camera addition is failed')                     
        self.log.info('camera addition is succeeded')                            
                                                                                 
        # Select the PCI card                                                    
        self.log.info('RF-2 wireless adapter card: {}'.format(                   
                      self.config['controller']['rf2_wireless_adapter_mac']))
        self.cntl.pci_mac=self.config['controller']['rf2_wireless_adapter_mac']  
                                                                                 
        # Start sniffer_5 capture                                                  
        if self.config['sniffer_5']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_5', '2.4', 'rf_2_add_camera')
            self.assertTrue(status, 'Sniffer_5 start is failed')                 
                                                                                 
        # Gets the camera instance                                               
        self.get_camera_instance('ping_camera_2')                                
                                                                                 
        # Add Camera                                                             
        status = self.add_camera_to_panel('wps')                                 
        self.assertTrue(status, 'camera addition is failed')                     
        self.log.info('camera addition is succeeded')                            
                                                                                 
        # Stop sniffer_4 capture                                                 
        if self.config['sniffer_4']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_4')                      
            self.assertTrue(status, 'Sniffer_4 stop is failed')                  
        rf_1_add_camera_pcap = self.multiple_sniffer_handler['sniffer_4']['pcap_filename']
                                                                                 
        # Stop sniffer_5 capture                                                 
        if self.config['sniffer_5']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_5')                      
            self.assertTrue(status, 'Sniffer_5 stop is failed')                  
        rf_2_add_camera_pcap = self.multiple_sniffer_handler['sniffer_5']['pcap_filename']
                                                                                 
        # Gets the yofi-1 instance                                               
        self.get_yofi_instance('yofi-2')

        # Start sniffer_1 capture                                                  
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_1', '5', 'adding_yofi_2_to_panel', sniffer_flag=False)
            self.assertTrue(status, 'Sniffer_1 start is failed')                 
                                                                                 
        # Start sniffer_2 capture                                                
        if self.config['sniffer_2']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_2', '2.4', 'adding_yofi_2_to_panel')
            self.assertTrue(status, 'Sniffer_2 start is failed')

        # Add yofi-2                                                               
        status = self.add_yofi_node_to_panel('wps')                              
        self.assertTrue(status, 'yofi-2 addition is failed')                     
        self.log.info('yofi-2 addition is succeeded')

        # Stop sniffer_1 capture                                                 
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_1')                      
            self.assertTrue(status, 'Sniffer_1 stop is failed')                  
        add_yofi_2_pcap_in_5  = self.multiple_sniffer_handler['sniffer_1']['pcap_filename']
                                                                                 
        # Stop sniffer_2 capture                                                 
        if self.config['sniffer_2']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_2')                      
            self.assertTrue(status, 'Sniffer_2 stop is failed')                  
        add_yofi_2_pcap_in_24  = self.multiple_sniffer_handler['sniffer_2']['pcap_filename']
                                                                                 
        # TODO RSSI of panel should less than -60, RSSI of YoFi-1 should not available or more than -70
        # If not work do attenuate 30dB instead of 0dB
        exp_mac_list = [self.config['panel']['ap_mac_addr'], self.config['panel']['sta_mac_addr']]
        unexp_mac_list = [self.config['yofi-2']['mac'], self.config['yofi-2']['mac_for_wps_check']]
        status = self.cntl.get_signal_strength_in_controller(
                        self.config['controller']['rf1_wireless_adapter_mac'],
                        exp_mac_list, unexp_mac_list)
        #self.assertTrue(status, 'Getting RSSI value in RF box-1 is failed')

        # Start sniffer_1 capture                                                  
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_1', '5', 'valiadtion')
            self.assertTrue(status, 'Sniffer_1 start is failed')                 
                                                                                 
        # Gets the yofi-3 instance
        self.get_yofi_instance('yofi-3')

        # Start sniffer_3 capture                                                  
        if self.config['sniffer_3']['enable'].lower() == 'true':
            status = self.start_sniffer_capture('sniffer_3', '5', 'adding_yofi_3_to_panel')
            self.assertTrue(status, 'Sniffer_3 start is failed')

        # Start sniffer_4 capture
        if self.config['sniffer_4']['enable'].lower() == 'true':
            status = self.start_sniffer_capture('sniffer_4', '2.4', 'adding_yofi_3_to_panel')
            self.assertTrue(status, 'Sniffer_4 start is failed')

        # Add yofi-3
        status = self.add_yofi_node_to_panel('wps')
        self.assertTrue(status, 'yofi-3 addition is failed')
        self.log.info('yofi-3 addition is succeeded')

        # Stop sniffer_4 capture
        if self.config['sniffer_4']['enable'].lower() == 'true':
            status = self.stop_sniffer_capture('sniffer_4')
            self.assertTrue(status, 'Sniffer_4 stop is failed')
        add_yofi_3_pcap_in_24  = self.multiple_sniffer_handler['sniffer_4']['pcap_filename']

        # Stop sniffer_3 capture                                                 
        if self.config['sniffer_3']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_3')                      
            self.assertTrue(status, 'Sniffer_3 stop is failed')                  
        add_yofi_3_pcap_in_5 = self.multiple_sniffer_handler['sniffer_3']['pcap_filename']
                                                                                 
        # Start sniffer_3 capture                                                  
        if self.config['sniffer_3']['enable'].lower() == 'true':
            status = self.start_sniffer_capture('sniffer_3', '5', 'rf_1_linear')
            self.assertTrue(status, 'Sniffer_3 start is failed')

        # Get channel from YoFi-3                                                
        yofi_3_channel = self.yofi.get_channel('wlan1')                          
        self.assertTrue(yofi_3_channel, 'Getting YoFi-3 2.4GHz channel is failed')
                                                                                 
        # Start sniffer_4 capture                                                
        if self.config['sniffer_4']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_4', '2.4', 'rf_1_camera_switch', yofi_3_channel)
            self.assertTrue(status, 'Sniffer_4 start is failed')                 
                                                                                 
        yofi_type = 'yofi-2'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']              
                                                                                 
        # Get channel from YoFi-2                                                
        yofi_2_channel = self.yofi.get_channel('wlan1')                          
        self.assertTrue(yofi_2_channel, 'Getting YoFi-2 2.4GHz channel is failed')
                                                                                 
        # Start sniffer_5 capture                                                
        if self.config['sniffer_5']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_5', '2.4', 'rf_2_camera_switch', yofi_2_channel)
            self.assertTrue(status, 'Sniffer_5 start is failed')                 
                                                                                 
        # Turn off the panel signal in RF box-1                                 
        status = self.att_obj.set_attenuation(self.config['attenuator']['off'],  
                                    self.config['attenuator']['channel_1'],      
                                    self.config['attenuator']['attenuator_1'])
        self.assertTrue(status, 'Blocking panel signal in RF box-1 is failed')   
                                                                                 
        # Turn off the panel signal in RF box-2                                  
        status = self.att_obj.set_attenuation(self.config['attenuator']['off'],  
                                    self.config['attenuator']['channel_2'],      
                                    self.config['attenuator']['attenuator_1'])
        self.assertTrue(status, 'Blocking panel signal in RF box-2 is failed')   
                                                                                 
        time.sleep(10)                                                           
                                                                                 
        # Turn on the YoFi-2 signal in RF box-1                               
        status = self.att_obj.set_attenuation(self.config['attenuator']['on'],   
                                    self.config['attenuator']['channel_1'],      
                                    self.config['attenuator']['attenuator_2'])   
        self.assertTrue(status, 'Passing YoFi-2 signal in RF box-1 is failed')   

        # Turn on the YoFi-2 signal in RF box-2                                  
        status = self.att_obj.set_attenuation(self.config['attenuator']['on'],   
                                    self.config['attenuator']['channel_2'],      
                                    self.config['attenuator']['attenuator_2'])   
        self.assertTrue(status, 'Passing YoFi-2 signal in RF box-2 is failed')   
                                                                                 
        # Verify YoFi-2 node is MAP mesh type
        status = self.yofi.is_mesh_node_map()
        self.assertTrue(status, 'YoFi-2 is not in MAP mode')
        self.log.info('YoFi-2 is in MAP mode')

        # Verify panel node is MPP mesh type                                     
        status = self.panel.is_mesh_node_mpp()                                   
        self.assertTrue(status, 'Panel is not in MPP mode')                      
        self.log.info('Panel is in MPP mode')
                                                                                 
        yofi_type = 'yofi-3'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']              
                                                                                 
        # Verify YoFi-3 node is MAP mesh type
        status = self.yofi.is_mesh_node_map()
        self.assertTrue(status, 'YoFi-3 is not in MAP mode')
        self.log.info('YoFi-3 is in MAP mode')

        # Ping from Yofi-3(MAP) to Panel(MPP)                                    
        status = self.yofi.ping(self.config['panel']['nw_br_lan_ip'])            
        # TODO
        #self.assertTrue(status, 'Ping from YoFi-3(MAP) to panel(MPP) is failed') 
        self.log.info('Ping from YoFi-3(MAP) to panel(MPP) is successfull')      
                                                                                 
        # Ping from Yofi-3(MAP) to Yofi-2(MAP)                                   
        status = self.yofi.ping(self.multiple_yofi_handler['yofi-2']['yofi_ip']) 
        #self.assertTrue(status, 'Ping from yofi-3(MAP) to YoFi-2(MAP) is failed')
        self.log.info('Ping from Yofi-3(MAP) to YoFi-2(MAP) is successfull')

        # Ping from Panel(MPP) to Yofi-2(MAP)                                    
        status = self.panel.ping(self.multiple_yofi_handler['yofi-2']['yofi_ip'])
        #self.assertTrue(status, 'Ping from panel(MPP) to YoFi-2(MAP) is failed') 
        self.log.info('Ping from panel(MPP) to YoFi-2(MAP) is successfull')

        # Ping from Panel(MPP) to Yofi-3(MAP)                                    
        status = self.panel.ping(self.multiple_yofi_handler['yofi-3']['yofi_ip'])                                    
        # TODO
        #self.assertTrue(status, 'Ping from panel(MPP) to YoFi-3(MAP) is failed') 
        self.log.info('Ping from panel(MPP) to YoFi-3(MAP) is successfull')      
                                                                                 
        yofi_type = 'yofi-2'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']              
                                                                                 
        # Ping from Yofi-2(MAP) to Panel(MPP)                                    
        status = self.yofi.ping(self.config['panel']['nw_br_lan_ip'])            
        #self.assertTrue(status, 'Ping from YoFi-2(MAP) to panel(MPP) is failed') 
        self.log.info('Ping from YoFi-2(MAP) to panel(MPP) is successfull')      
                                                                                 
        # Ping from Yofi-2(MAP) to Yofi-3(MAP)                                   
        status = self.yofi.ping(self.multiple_yofi_handler['yofi-3']['yofi_ip']) 
        #self.assertTrue(status, 'Ping from yofi-2(MAP) to YoFi-3(MAP) is failed')
        self.log.info('Ping from Yofi-2(MAP) to YoFi-3(MAP) is successfull')

        # Get mesh graph .svg file from panel if this flag True
        self.mesh_graph_flag = True

        # Topology check in panel MPP                                            
        status = self.verify_station_dump(self.panel, self.config['yofi-2']['mac'])
        self.assertTrue(status, 'Station dump check in Panel is failed')         
        self.log.info('Station dump check on mesh interface in Panel is succeeded')
                                                                                 
        # Topology check in Panel MPP                                            
        status = self.verify_station_dump(self.panel, self.config['yofi-3']['mac'])
        # TODO should not found
        #self.assertTrue(status, 'Station dump check in Panel is failed')         
        self.log.info('Station dump check on mesh interface in Panel is succeeded')
                                                                                 
        # Topology check in MAP-YoFi-2                                            
        status = self.verify_station_dump(self.yofi, self.config['yofi-3']['mac'])
        self.assertTrue(status, 'Station dump check in YoFi is failed')          
        self.log.info('Station dump check on mesh interface in YoFi is succeeded')
                                                                                 
        # Topology check in MAP-YoFi-2                                            
        status = self.verify_station_dump(self.yofi, self.config['panel']['sta_mac_addr'])
        self.assertTrue(status, 'Station dump check in YoFi is failed')          
        self.log.info('Station dump check on mesh interface in YoFi is succeeded')
                                                                                 
        # Gets the yofi-3 instance                                               
        yofi_type = 'yofi-3'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']              
                                                                                 
        # Topology check in MAP-YoFi-3                                            
        status = self.verify_station_dump(self.yofi, self.config['yofi-2']['mac'])
        self.assertTrue(status, 'Station dump check in YoFi is failed')          
        self.log.info('Station dump check on mesh interface in YoFi is succeeded')
                                                                                 
        # Topology check in MAP-YoFi-3                                           
        status = self.verify_station_dump(self.yofi, self.config['panel']['sta_mac_addr'])
        # TODO should not found
        #self.assertTrue(status, 'Station dump check in YoFi is failed')          
        self.log.info('Station dump check on mesh interface in YoFi is succeeded')

        # TODO RSSI of panel should less than -60, RSSI of YoFi-1 should not available or more than -70
        # If not work do attenuate 30dB instead of 0dB
        unexp_mac_list = [self.config['panel']['ap_mac_addr'], self.config['panel']['sta_mac_addr']]
        exp_mac_list = [self.config['yofi-2']['mac'], self.config['yofi-2']['mac_for_wps_check']]
        status = self.cntl.get_signal_strength_in_controller(
                        self.config['controller']['rf1_wireless_adapter_mac'],
                        exp_mac_list, unexp_mac_list)
        #self.assertTrue(status, 'Getting RSSI value in RF box-1 is failed')

        exp_mac_list = [self.config['panel']['ap_mac_addr'], self.config['panel']['sta_mac_addr']]
        unexp_mac_list = [self.config['yofi-3']['mac'], self.config['yofi-3']['mac_for_wps_check']]
        status = self.cntl.get_signal_strength_in_controller(
                        self.config['controller']['outside_wireless_adapter_mac'],
                        exp_mac_list, unexp_mac_list)
        #self.assertTrue(status, 'Getting RSSI value is failed')

        # TODO If fails, Do attenuate 20dB and check again

        # Check the linear topology using mpath dump, next hop node mac and dest node mac
        self.yofi.verify_linear_topology(self.config['panel']['sta_mac_addr'], self.config['yofi-2']['mac'])
        # TODO 
        #self.assertTrue(status, 'Linear topology check in YoFi-3 is failed')
                                                                                 
        # Netv assoc for 5GHz
        self.display_mesh_node_connection_status(self.config['panel']['sta_mac_addr'])

        # Displays the where the camera is connected using netv assoc 2.4         
        status = self.display_camera_connection_status(self.config['camera']['mac'], panel_flag=True)
        self.log.info('Display cameras connection status in Panel MPP')         
                                                                                 
        # Stop sniffer_1 capture                                                 
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_1')                      
            self.assertTrue(status, 'Sniffer_1 stop is failed')                  
        validation_5 = self.multiple_sniffer_handler['sniffer_1']['pcap_filename']
                                                                                 
        # Stop sniffer_3 capture                                                 
        if self.config['sniffer_3']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_3')                      
            self.assertTrue(status, 'Sniffer_3 stop is failed')                  
        rf_1_linear_validation = self.multiple_sniffer_handler['sniffer_3']['pcap_filename']
                                                                                 
        # Start sniffer_1 capture                                                  
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_1', '5', 'camera_switch')
            self.assertTrue(status, 'Sniffer_1 start is failed')                 
                                                                                 
        # Start sniffer_3 capture                                                  
        if self.config['sniffer_3']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_3', '5', 'rf_1_camera_switch')
            self.assertTrue(status, 'Sniffer_3 start is failed')                 
                                                                                 
        # Connecting camera to mesh node using bssid                                 
        self.connect_camera_to_mesh_node('dbc_camera_2',
                                    self.config['yofi-3']['mac_for_wps_check'])

        # Gets the yofi-2 instance                                               
        yofi_type = 'yofi-2'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']              
                                                                                 
        self.get_camera_config('ping_camera_2')                                  

        # Topology check in MPP-YoFi, Camera should connected to YoFi            
        status = self.verify_station_dump(self.yofi, self.config['camera']['mac'], 'wlan1')
        self.assertTrue(status, 'Station dump check in YoFi is failed')          
        self.log.info('Station dump check on 2.4GHz interface in YoFi is succeeded')

        # Stop sniffer_4 capture                                                 
        if self.config['sniffer_4']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_4')                      
            self.assertTrue(status, 'Sniffer_4 stop is failed')                  
        rf_1_camera_switch_pcap = self.multiple_sniffer_handler['sniffer_4']['pcap_filename']
                                                                                 
        # Stop sniffer_5 capture                                                 
        if self.config['sniffer_5']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_5')                      
            self.assertTrue(status, 'Sniffer_5 stop is failed')                  
        rf_2_camera_switch_pcap = self.multiple_sniffer_handler['sniffer_5']['pcap_filename']
                                                                                 
        # Stop sniffer_1 capture                                                 
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_1')                      
            self.assertTrue(status, 'Sniffer_1 stop is failed')                  
        camera_switch_pcap_in_5 = self.multiple_sniffer_handler['sniffer_1']['pcap_filename']
                                                                                 
        # Stop sniffer_3 capture                                                 
        if self.config['sniffer_3']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_3')                      
            self.assertTrue(status, 'Sniffer_1 stop is failed')                  
        rf_1_camera_switch_pcap_in_5 = self.multiple_sniffer_handler['sniffer_3']['pcap_filename']

        # Turn on the panel signal in RF box-2                                  
        status = self.att_obj.set_attenuation(self.config['attenuator']['on'],  
                                    self.config['attenuator']['channel_2'],     
                                    self.config['attenuator']['attenuator_1'])  
        self.assertTrue(status, 'Passing panel signal in RF box-2 is failed')   

        # Start sniffer_3 capture                                                  
        if self.config['sniffer_3']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_3', '5', 'delete_yofi_2')
            self.assertTrue(status, 'Sniffer_3 start is failed')                 
                                                                                 
        # Gets the yofi-3 instance                                               
        yofi_type = 'yofi-3'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']              

        # Get channel from YoFi-3                                                
        yofi_3_channel = self.yofi.get_channel('wlan1')                          
        self.assertTrue(yofi_3_channel, 'Getting YoFi-3 2.4GHz channel is failed')
                                                                                 
        # Start sniffer_4 capture                                                
        if self.config['sniffer_4']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_4', '2.4', 'delete_yofi_2', yofi_3_channel)
            self.assertTrue(status, 'Sniffer_4 start is failed')                 
                                                                                 
        # Start sniffer_5 capture                                                
        if self.config['sniffer_5']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_5', '2.4', 'ping_camera_roam')
            self.assertTrue(status, 'Sniffer_5 start is failed')                 
                                                                                 
        # TODO get the .svg files to controller with different name

        # TODO Ping between Panel and Camera Sta's

        # Camera video streamming                                                
        status = self.camera_stream_in_controller(camera_type_list,              
                                                  live_video_stream_duration=1200,
                                                  validation_flag=False)         
        self.assertTrue(status, 'Camera streaming in controller is failed')      
                                                                                 
        # Stream camera 60s via panel before Panel reboot                        
        time.sleep(60)

        # Gets the yofi-2 instance                                               
        yofi_type = 'yofi-2'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']              
                                                                                 
        # Delete the MAP-1 yofi-2                                                
        status = self.delete_yofi_from_panel('yofi-2')                           
        self.assertTrue(status, 'YoFi-2 delete is failed')                       
        self.log.info('YoFi-2 delete is succeeded')                              
                                                                                 
        # Clear the YoFi-2 detailes                                              
        del(self.multiple_yofi_handler['yofi-2'])                                
                                                                                 
        time.sleep(120)                                                           
                                                                                 
        # Stream should stop                                                     
        status = self.validate_camera_stream_in_controller(camera_type_list,     
                    live_video_stream_duration=1200)                             
        self.assertFalse(status, 'Camera streaming is not stopped in controller')
        self.log.info('Camera streaming is stopped in controller')

        # Stop sniffer_3 capture                                                 
        if self.config['sniffer_3']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_3')                      
            self.assertTrue(status, 'Sniffer_1 stop is failed')                  
        delete_yofi_2_in_5 = self.multiple_sniffer_handler['sniffer_3']['pcap_filename']

        # Stop sniffer_4 capture                                                 
        if self.config['sniffer_4']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_4')                      
            self.assertTrue(status, 'Sniffer_4 stop is failed')                  
        delete_yofi_2_in_24 = self.multiple_sniffer_handler['sniffer_4']['pcap_filename']
                                                                                 
        # Gets the yofi-3 instance                                               
        yofi_type = 'yofi-3'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']              

        self.get_camera_config('ping_camera_2')

        # Do station dump for ping camera in Panel
        status = self.verify_station_dump(self.panel, self.config['camera']['mac'], 'wlan1')
        self.assertTrue(status, 'Ping camera is not connected to panel')
        self.log.info('Ping camera is connected to panel')
                                                                                 
        self.get_camera_config('dbc_camera_2')

        # TODO might be DBC connected to yofi-2
        # Do station dump for ping camera in Panel
        status = self.verify_station_dump(self.yofi, self.config['camera']['mac'], 'wlan1')
        #self.assertTrue(status, 'DBC camera is not connected to panel')
        #self.log.info('DBC camera is connected to panel')
                                                                                 
        # Do ping from panel to ping camera
        status = self.panel.ping(self.multiple_yofi_handler['ping_camera_2']['camera_ip'])                                    
        self.assertTrue(status, 'Ping from panel(MPP) to Ping camera is failed') 
        self.log.info('Ping from panel(MPP) to Ping camera is successfull')      
                                                                                 
        # Do ping from panel to DBC camera, ping opertaion should fail
        status = self.panel.ping(self.multiple_yofi_handler['ping_camera_2']['camera_ip'])                                    
        self.assertFalse(status, 'Ping from panel(MPP) to Ping camera is successfull') 
        self.log.info('Ping from panel(MPP) to Ping camera is failed, expected result')      
        
        # Live ping camera stream in panel
        status = self.camera_stream_in_panel(['ping_camera_2'])                   
        self.assertTrue(status, 'Ping Camera streaming in panel is failed')
        self.log.info('Ping Camera streaming in panel is successfull')      

        # Stop sniffer_5 capture                                                 
        if self.config['sniffer_5']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_5')                      
            self.assertTrue(status, 'Sniffer_5 stop is failed')                  
        ping_camera_roam_pcap = self.multiple_sniffer_handler['sniffer_5']['pcap_filename']
                                                                                 
        self.get_sniffer_utility_instance()                                      
                                                                                 
        panel_sta_mac = self.config['panel']['sta_mac_addr']                     
        yofi_2_mac = self.config['yofi-2']['mac']                                
        yofi_3_mac = self.config['yofi-3']['mac']                                
        panel_ap_mac = self.config['panel']['ap_mac_addr']                       
        yofi_2_mac_for_24 = self.config['yofi-2']['mac_for_wps_check']           
        yofi_3_mac_for_24 = self.config['yofi-3']['mac_for_wps_check']           
                                                                                 
        # Sniffer_1 frame analysis                                               
        self.log.info('Sniffer_1 analysis between YoFi-2(MAP) and panel(MPP)')   
        self.log.info('Sniffer_1 pcap file: {}'.format(add_yofi_2_pcap_in_5))    
        status = self.sniffer_analysis.validate_MPP_and_MAP_connection_with_sae_and_peer_action_frames(add_yofi_2_pcap_in_5, yofi_2_mac, panel_sta_mac)
                                                                                 
        # Sniffer_2 frame analysis, Source Mac should be STA (YoFi)              
        self.log.info('Sniffer_2 analysis between YoFi-2(MAP) and panel(MPP)')   
        self.log.info('Sniffer_2 pcap file: {}'.format(add_yofi_2_pcap_in_24))   
        status = self.sniffer_analysis.wps_connect(add_yofi_2_pcap_in_24, yofi_2_mac_for_24, panel_ap_mac)
                                                                                 
        # Sniffer_1 frame analysis                                               
        self.log.info('Sniffer_1 analysis between YoFi-3(MAP) and panel(MPP)')   
        self.log.info('Sniffer_1 pcap file: {}'.format(add_yofi_3_pcap_in_5))    
        status = self.sniffer_analysis.validate_MPP_and_MAP_connection_with_sae_and_peer_action_frames(add_yofi_3_pcap_in_5, yofi_3_mac, panel_sta_mac)
                                                                                 
        # Sniffer_2 frame analysis, Source Mac should be STA (YoFi)              
        self.log.info('Sniffer_2 analysis between YoFi-3(MAP) and panel(MPP)')   
        self.log.info('Sniffer_2 pcap file: {}'.format(add_yofi_3_pcap_in_24))   
        status = self.sniffer_analysis.wps_connect(add_yofi_3_pcap_in_24, yofi_3_mac_for_24, panel_ap_mac)

        # Sniffer_3 frame analysis                                               
        self.log.info('Sniffer_3 analysis between YoFi-3(MAP) and YoFi-2(MAP)')  
        self.log.info('Sniffer_3 pcap file: {}'.format(rf_1_linear_validation))  
        status = self.sniffer_analysis.validate_MPP_and_MAP_connection_with_sae_and_peer_action_frames(rf_1_linear_validation, yofi_2_mac, yofi_3_mac)

        # Sniffer_4 packet check M1/M2 packet analysis                                                  
        self.log.info('Sniffer_4 packet checking')                               
        total_errors = {}                                                        
        for camera_type_name in ['dbc_camera_2']:                               
            self.get_camera_config(camera_type_name)                             
            self.log.info('#################################################')   
            self.log.info('Started WPS IE validation for {}'.format(camera_type_name))
            self.log.info('Sniffer_4 pcap file: {}'.format(rf_1_add_camera_pcap))
            camera_mac = self.config[camera_type_name]['mac']                    
            status, errors = self.sniffer_analysis.GES_Vivint_Yofi_PAK_0016_24G_analysis(rf_1_add_camera_pcap, self.config)
            status_camera_add = self.sniffer_analysis.wps_connect(rf_1_add_camera_pcap, camera_mac, panel_ap_mac)
            if not status_camera_add:                                            
                errors.append('WPS connection is failed')                        
            total_errors[camera_type_name] = errors                              
            self.log.info('WPS IE validation is done for {}'.format(camera_type_name))
            self.log.info('#################################################')   
                                                                                 
        for camera_type_name in total_errors.keys():                             
            self.log.info('#################################################')   
            self.log.info('Errors found during validation of {}'.format(camera_type_name))
            self.log.info('#################################################')
            for error in total_errors[camera_type_name]:                         
                self.log.error('{} of {}'.format(error, camera_type_name))       
            self.log.info('#################################################')   
            error_length = [len(total_errors[item]) for item in total_errors]    
        if not all(i == 0 for i in error_length):                                
            self.log.error('M1/M2 packet check failed')                          
                                                                                 
        # Sniffer_5 packet check M1/M2 packet analysis                                                  
        self.log.info('Sniffer_5 packet checking')                               
        total_errors = {}                                                        
        for camera_type_name in ['ping_camera_2']:                               
            self.get_camera_config(camera_type_name)                             
            self.log.info('#################################################')   
            self.log.info('Started WPS IE validation for {}'.format(camera_type_name))
            self.log.info('Sniffer_5 pcap file: {}'.format(rf_2_add_camera_pcap))
            camera_mac = self.config[camera_type_name]['mac']                    
            status, errors = self.sniffer_analysis.GES_Vivint_Yofi_PAK_0016_24G_analysis(rf_2_add_camera_pcap, self.config)
            status_camera_add = self.sniffer_analysis.wps_connect(rf_2_add_camera_pcap, camera_mac, panel_ap_mac)
            if not status_camera_add:                                            
                errors.append('WPS connection is failed')                        
            total_errors[camera_type_name] = errors                              
            self.log.info('WPS IE validation is done for {}'.format(camera_type_name))
            self.log.info('#################################################')   
                                                                                 
        for camera_type_name in total_errors.keys():                             
            self.log.info('#################################################')   
            self.log.info('Errors found during validation of {}'.format(camera_type_name))
            self.log.info('#################################################')   
            for error in total_errors[camera_type_name]:                         
                self.log.error('{} of {}'.format(error, camera_type_name))       
            self.log.info('#################################################')   
        error_length = [len(total_errors[item]) for item in total_errors]        
        if not all(i == 0 for i in error_length):                                
            self.log.error('M1/M2 packet check failed')                          
                                                                                 
        # Sniffer_4 frames analysis for camera switch                                                 
        self.log.info('Sniffer_4 packet checking for camera switch')             
        total_errors = {}                                                        
        for camera_type_name in ['dbc_camera_2']:                               
            self.get_camera_config(camera_type_name)                             
            self.log.info('Started WPS connection validation for {}'.format(camera_type_name))
            self.log.info('Sniffer_4 pcap file: {}'.format(rf_1_camera_switch_pcap))
            camera_mac = self.config[camera_type_name]['mac']                    
            status = self.sniffer_analysis.connection_over_24GHz(rf_1_camera_switch_pcap, camera_mac, yofi_3_mac_for_24)
                                                                                 
        # Sniffer_5 frames analysis for camera switch                                                 
        self.log.info('Sniffer_5 packet checking for camera switch')             
        total_errors = {}                                                        
        for camera_type_name in ['ping_camera_2']:                               
            self.get_camera_config(camera_type_name)                             
            self.log.info('Started WPS connection validation for {}'.format(camera_type_name))
            self.log.info('Sniffer_5 pcap file: {}'.format(rf_2_camera_switch_pcap))
            camera_mac = self.config[camera_type_name]['mac']                    
            status = self.sniffer_analysis.connection_over_24GHz(rf_2_camera_switch_pcap, camera_mac, yofi_2_mac_for_24)
                                                                                 
        # TODO working properly
        # Sniffer_3 frame analysis, Validate the close frame of YoFi-2     
        self.log.info('Sniffer_3 analysis between YoFi-2(MAP) and YoFi-3(MAP)')   
        self.log.info('Sniffer_3 pcap file: {}'.format(delete_yofi_2_in_5))   
        status = self.sniffer_analysis.mesh_peer_close_5G_analysis(delete_yofi_2_in_5, yofi_2_mac, yofi_3_mac)

        # TODO working properly
        # Sniffer_3 frame analysis, Validate the close frame of YoFi-2     
        self.log.info('Sniffer_3 analysis between YoFi-2(MAP) and Panel (MPP)')   
        self.log.info('Sniffer_3 pcap file: {}'.format(delete_yofi_2_in_5))   
        status = self.sniffer_analysis.mesh_peer_close_5G_analysis(delete_yofi_2_in_5, yofi_2_mac, panel_sta_mac)

        # TODO working properly
        # Sniffer_4 frame analysis, Validate the disassoc/deauth frame of YoFi-2 for connected STA    
        self.log.info('Sniffer_4 analysis between YoFi-2(MAP) and Camera')   
        self.log.info('Sniffer_4 pcap file: {}'.format(delete_yofi_2_in_24))   
        status = self.sniffer_analysis.disconnection_24G_analysis(delete_yofi_2_in_24, yofi_2_mac, self.config['dbc_camera_2']['mac'])

        # Sniffer_5 frames analysis for camera switch                                                 
        self.log.info('Sniffer_5 packet checking for camera switch')             
        total_errors = {}                                                        
        for camera_type_name in ['ping_camera_2']:                               
            self.get_camera_config(camera_type_name)                             
            self.log.info('Started WPS connection validation for {}'.format(camera_type_name))
            self.log.info('Sniffer_5 pcap file: {}'.format(ping_camera_roam_pcap))
            camera_mac = self.config[camera_type_name]['mac']                    
            status = self.sniffer_analysis.connection_over_24GHz(ping_camera_roam_pcap, camera_mac, panel_ap_mac)
                                                                                 
    @attr(test_category='ROUTING')
    @attr(test_id='GES_Vivint_Yofi_ROUTE_0010')
    @nose.allure.severity(nose.allure.severity_level.CRITICAL)
    @nose.allure.feature('Power off (delete) MAP-1 (YoFi) in Daisy chain topology')
    def test_07_GES_Vivint_Yofi_ROUTE_0010(self):
        """Power off (delete) MAP-1 (YoFi) in Daisy chain topology
        :Vivint Testrail ID : C1177888 
        :Test Case ID: GES_Vivint-Yofi_ROUTE_0010
        :author: GES automation dev
        """
        self.log.info('======= Testcase started =======')
        self.testcase_name = sys._getframe().f_code.co_name
        test_case = getattr(self, self.testcase_name)
        self.log_path = '{}{}/{}/'.format(self.config['controller']['log_path'], execution_log_path, test_case.test_category)
        self.log.debug('Fun name: {}\n'.format(self.testcase_name))

        # Creating log directory with testcase_name
        self.log_path_with_test_name =  self.cntl.create_log_dir_with_testcase_name(self.log_path, self.testcase_name)
        self.log.info('Log path of testcase directory: {}'.format(self.log_path_with_test_name))

        camera_type_list = ['dbc_camera_2', 'ping_camera_2']    
        self.check_cameras_in_ap_mode(camera_type_list)

        status = self.att_obj.set_all_channel_to_high_attenuation(               
                                    self.config['attenuator']['attenuator_1'])   
        self.assertTrue(status, 'Set all channel to high attenuation_1 is failed') 
        self.log.info('Set all channel to high attenuation_1 is successful')

        status = self.att_obj.set_all_channel_to_high_attenuation(               
                                    self.config['attenuator']['attenuator_2'])   
        self.assertTrue(status, 'Set all channel to high attenuation_2 is failed') 
        self.log.info('Set all channel to high attenuation_2 is successful')

        # Turn on the panel signal in RF box-1                                  
        status = self.att_obj.set_attenuation(self.config['attenuator']['on'],  
                                    self.config['attenuator']['channel_1'],     
                                    self.config['attenuator']['attenuator_1'])  
        self.assertTrue(status, 'Passing panel signal in RF box-1 is failed')   
        self.attenuator_1 = True

        # Turn on the panel signal in RF box-2                                  
        status = self.att_obj.set_attenuation(self.config['attenuator']['on'],  
                                    self.config['attenuator']['channel_2'],     
                                    self.config['attenuator']['attenuator_1'])  
        self.assertTrue(status, 'Passing panel signal in RF box-2 is failed')   
        self.attenuator_2 = True

        # Configure panel as MPP                                                 
        self.panel_mpp_ip = self.configure_mpp(self.panel)                       
        self.assertTrue(self.panel_mpp_ip, 'get MPP IP address is failed')       
                                                                                 
        '''
        # Get mesh ID and psk from panel                                         
        status = self.panel.get_mesh_id_and_psk()                                
        self.assertTrue(status, 'Failed to get mesh_id and wps_psk')             
        '''
                                                                                 
        # Select the PCI card                                                    
        self.log.info('RF-1 wireless adapter card: {}'.format(                   
                                self.config['controller']['rf1_wireless_adapter_mac']))
        self.cntl.pci_mac=self.config['controller']['rf1_wireless_adapter_mac']  
                                                                                 
        # Start sniffer_4 capture                                                  
        if self.config['sniffer_4']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_4', '2.4', 'rf_1_add_camera')
            self.assertTrue(status, 'Sniffer_4 start is failed')                 
                                                                                 
        # Gets the camera instance                                               
        self.get_camera_instance('dbc_camera_2')                                
                                                                                 
        # Add Camera                                                             
        status = self.add_camera_to_panel('wps')                                 
        self.assertTrue(status, 'camera addition is failed')                     
        self.log.info('camera addition is succeeded')                            
                                                                                 
        # Select the PCI card                                                    
        self.log.info('RF-2 wireless adapter card: {}'.format(                   
                      self.config['controller']['rf2_wireless_adapter_mac']))
        self.cntl.pci_mac=self.config['controller']['rf2_wireless_adapter_mac']  
                                                                                 
        # Start sniffer_5 capture                                                  
        if self.config['sniffer_5']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_5', '2.4', 'rf_2_add_camera')
            self.assertTrue(status, 'Sniffer_5 start is failed')                 
                                                                                 
        # Gets the camera instance                                               
        self.get_camera_instance('ping_camera_2')                                
                                                                                 
        # Add Camera                                                             
        status = self.add_camera_to_panel('wps')                                 
        self.assertTrue(status, 'camera addition is failed')                     
        self.log.info('camera addition is succeeded')                            
                                                                                 
        # Stop sniffer_4 capture                                                 
        if self.config['sniffer_4']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_4')                      
            self.assertTrue(status, 'Sniffer_4 stop is failed')                  
        rf_1_add_camera_pcap = self.multiple_sniffer_handler['sniffer_4']['pcap_filename']
                                                                                 
        # Stop sniffer_5 capture                                                 
        if self.config['sniffer_5']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_5')                      
            self.assertTrue(status, 'Sniffer_5 stop is failed')                  
        rf_2_add_camera_pcap = self.multiple_sniffer_handler['sniffer_5']['pcap_filename']
                                                                                 
        # Gets the yofi-1 instance                                               
        self.get_yofi_instance('yofi-2')

        # Start sniffer_1 capture                                                  
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_1', '5', 'adding_yofi_2_to_panel', sniffer_flag=False)
            self.assertTrue(status, 'Sniffer_1 start is failed')                 
                                                                                 
        # Start sniffer_2 capture                                                
        if self.config['sniffer_2']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_2', '2.4', 'adding_yofi_2_to_panel')
            self.assertTrue(status, 'Sniffer_2 start is failed')

        # Add yofi-2                                                               
        status = self.add_yofi_node_to_panel('wps')                              
        self.assertTrue(status, 'yofi-2 addition is failed')                     
        self.log.info('yofi-2 addition is succeeded')

        # Stop sniffer_1 capture                                                 
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_1')                      
            self.assertTrue(status, 'Sniffer_1 stop is failed')                  
        add_yofi_2_pcap_in_5  = self.multiple_sniffer_handler['sniffer_1']['pcap_filename']
                                                                                 
        # Stop sniffer_2 capture                                                 
        if self.config['sniffer_2']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_2')                      
            self.assertTrue(status, 'Sniffer_2 stop is failed')                  
        add_yofi_2_pcap_in_24  = self.multiple_sniffer_handler['sniffer_2']['pcap_filename']
                                                                                 
        # TODO RSSI of panel should less than -60, RSSI of YoFi-1 should not available or more than -70
        # If not work do attenuate 30dB instead of 0dB
        exp_mac_list = [self.config['panel']['ap_mac_addr'], self.config['panel']['sta_mac_addr']]
        unexp_mac_list = [self.config['yofi-2']['mac'], self.config['yofi-2']['mac_for_wps_check']]
        status = self.cntl.get_signal_strength_in_controller(
                        self.config['controller']['rf1_wireless_adapter_mac'],
                        exp_mac_list, unexp_mac_list)
        #self.assertTrue(status, 'Getting RSSI value in RF box-1 is failed')

        # Start sniffer_1 capture                                                  
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_1', '5', 'valiadtion')
            self.assertTrue(status, 'Sniffer_1 start is failed')                 
                                                                                 
        # Gets the yofi-3 instance
        self.get_yofi_instance('yofi-3')

        # Start sniffer_3 capture                                                  
        if self.config['sniffer_3']['enable'].lower() == 'true':
            status = self.start_sniffer_capture('sniffer_3', '5', 'adding_yofi_3_to_panel')
            self.assertTrue(status, 'Sniffer_3 start is failed')

        # Start sniffer_4 capture
        if self.config['sniffer_4']['enable'].lower() == 'true':
            status = self.start_sniffer_capture('sniffer_4', '2.4', 'adding_yofi_3_to_panel')
            self.assertTrue(status, 'Sniffer_4 start is failed')

        # Add yofi-3
        status = self.add_yofi_node_to_panel('wps')
        self.assertTrue(status, 'yofi-3 addition is failed')
        self.log.info('yofi-3 addition is succeeded')

        # Stop sniffer_4 capture
        if self.config['sniffer_4']['enable'].lower() == 'true':
            status = self.stop_sniffer_capture('sniffer_4')
            self.assertTrue(status, 'Sniffer_4 stop is failed')
        add_yofi_3_pcap_in_24  = self.multiple_sniffer_handler['sniffer_4']['pcap_filename']

        # Stop sniffer_3 capture                                                 
        if self.config['sniffer_3']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_3')                      
            self.assertTrue(status, 'Sniffer_3 stop is failed')                  
        add_yofi_3_pcap_in_5 = self.multiple_sniffer_handler['sniffer_3']['pcap_filename']
                                                                                 
        # Start sniffer_3 capture                                                  
        if self.config['sniffer_3']['enable'].lower() == 'true':
            status = self.start_sniffer_capture('sniffer_3', '5', 'rf_1_linear')
            self.assertTrue(status, 'Sniffer_3 start is failed')

        # Get channel from YoFi-3                                                
        yofi_3_channel = self.yofi.get_channel('wlan1')                          
        self.assertTrue(yofi_3_channel, 'Getting YoFi-3 2.4GHz channel is failed')
                                                                                 
        # Start sniffer_4 capture                                                
        if self.config['sniffer_4']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_4', '2.4', 'rf_1_camera_switch', yofi_3_channel)
            self.assertTrue(status, 'Sniffer_4 start is failed')                 
                                                                                 
        yofi_type = 'yofi-2'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']              
                                                                                 
        # Get channel from YoFi-2                                                
        yofi_2_channel = self.yofi.get_channel('wlan1')                          
        self.assertTrue(yofi_2_channel, 'Getting YoFi-2 2.4GHz channel is failed')
                                                                                 
        # Start sniffer_5 capture                                                
        if self.config['sniffer_5']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_5', '2.4', 'rf_2_camera_switch', yofi_2_channel)
            self.assertTrue(status, 'Sniffer_5 start is failed')                 
                                                                                 
        # Turn off the panel signal in RF box-1                                 
        status = self.att_obj.set_attenuation(self.config['attenuator']['off'],  
                                    self.config['attenuator']['channel_1'],      
                                    self.config['attenuator']['attenuator_1'])
        self.assertTrue(status, 'Blocking panel signal in RF box-1 is failed')   
                                                                                 
        # Turn off the panel signal in RF box-2                                  
        status = self.att_obj.set_attenuation(self.config['attenuator']['off'],  
                                    self.config['attenuator']['channel_2'],      
                                    self.config['attenuator']['attenuator_1'])
        self.assertTrue(status, 'Blocking panel signal in RF box-2 is failed')   
                                                                                 
        time.sleep(10)                                                           
                                                                                 
        # Turn on the YoFi-2 signal in RF box-1                               
        status = self.att_obj.set_attenuation(self.config['attenuator']['on'],   
                                    self.config['attenuator']['channel_1'],      
                                    self.config['attenuator']['attenuator_2'])   
        self.assertTrue(status, 'Passing YoFi-2 signal in RF box-1 is failed')   

        # Turn on the YoFi-2 signal in RF box-2                                  
        status = self.att_obj.set_attenuation(self.config['attenuator']['on'],   
                                    self.config['attenuator']['channel_2'],      
                                    self.config['attenuator']['attenuator_2'])   
        self.assertTrue(status, 'Passing YoFi-2 signal in RF box-2 is failed')   
                                                                                 
        # Verify YoFi-2 node is MAP mesh type
        status = self.yofi.is_mesh_node_map()
        self.assertTrue(status, 'YoFi-2 is not in MAP mode')
        self.log.info('YoFi-2 is in MAP mode')

        # Verify panel node is MPP mesh type                                     
        status = self.panel.is_mesh_node_mpp()                                   
        self.assertTrue(status, 'Panel is not in MPP mode')                      
        self.log.info('Panel is in MPP mode')
                                                                                 
        yofi_type = 'yofi-3'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']              
                                                                                 
        # Verify YoFi-3 node is MAP mesh type
        status = self.yofi.is_mesh_node_map()
        self.assertTrue(status, 'YoFi-3 is not in MAP mode')
        self.log.info('YoFi-3 is in MAP mode')

        # Ping from Yofi-3(MAP) to Panel(MPP)                                    
        status = self.yofi.ping(self.config['panel']['nw_br_lan_ip'])            
        # TODO
        #self.assertTrue(status, 'Ping from YoFi-3(MAP) to panel(MPP) is failed') 
        self.log.info('Ping from YoFi-3(MAP) to panel(MPP) is successfull')      
                                                                                 
        # Ping from Yofi-3(MAP) to Yofi-2(MAP)                                   
        status = self.yofi.ping(self.multiple_yofi_handler['yofi-2']['yofi_ip']) 
        #self.assertTrue(status, 'Ping from yofi-3(MAP) to YoFi-2(MAP) is failed')
        self.log.info('Ping from Yofi-3(MAP) to YoFi-2(MAP) is successfull')

        # Ping from Panel(MPP) to Yofi-2(MAP)                                    
        status = self.panel.ping(self.multiple_yofi_handler['yofi-2']['yofi_ip'])
        #self.assertTrue(status, 'Ping from panel(MPP) to YoFi-2(MAP) is failed') 
        self.log.info('Ping from panel(MPP) to YoFi-2(MAP) is successfull')

        # Ping from Panel(MPP) to Yofi-3(MAP)                                    
        status = self.panel.ping(self.multiple_yofi_handler['yofi-3']['yofi_ip'])                                    
        # TODO
        #self.assertTrue(status, 'Ping from panel(MPP) to YoFi-3(MAP) is failed') 
        self.log.info('Ping from panel(MPP) to YoFi-3(MAP) is successfull')      
                                                                                 
        yofi_type = 'yofi-2'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']              
                                                                                 
        # Ping from Yofi-2(MAP) to Panel(MPP)                                    
        status = self.yofi.ping(self.config['panel']['nw_br_lan_ip'])            
        #self.assertTrue(status, 'Ping from YoFi-2(MAP) to panel(MPP) is failed') 
        self.log.info('Ping from YoFi-2(MAP) to panel(MPP) is successfull')      
                                                                                 
        # Ping from Yofi-2(MAP) to Yofi-3(MAP)                                   
        status = self.yofi.ping(self.multiple_yofi_handler['yofi-3']['yofi_ip']) 
        #self.assertTrue(status, 'Ping from yofi-2(MAP) to YoFi-3(MAP) is failed')
        self.log.info('Ping from Yofi-2(MAP) to YoFi-3(MAP) is successfull')

        # Get mesh graph .svg file from panel if this flag True
        self.mesh_graph_flag = True

        # Topology check in panel MPP                                            
        status = self.verify_station_dump(self.panel, self.config['yofi-2']['mac'])
        self.assertTrue(status, 'Station dump check in Panel is failed')         
        self.log.info('Station dump check on mesh interface in Panel is succeeded')
                                                                                 
        # Topology check in Panel MPP                                            
        status = self.verify_station_dump(self.panel, self.config['yofi-3']['mac'])
        # TODO should not found
        #self.assertTrue(status, 'Station dump check in Panel is failed')         
        self.log.info('Station dump check on mesh interface in Panel is succeeded')
                                                                                 
        # Topology check in MAP-YoFi-2                                            
        status = self.verify_station_dump(self.yofi, self.config['yofi-3']['mac'])
        self.assertTrue(status, 'Station dump check in YoFi is failed')          
        self.log.info('Station dump check on mesh interface in YoFi is succeeded')
                                                                                 
        # Topology check in MAP-YoFi-2                                            
        status = self.verify_station_dump(self.yofi, self.config['panel']['sta_mac_addr'])
        self.assertTrue(status, 'Station dump check in YoFi is failed')          
        self.log.info('Station dump check on mesh interface in YoFi is succeeded')
                                                                                 
        # Gets the yofi-3 instance                                               
        yofi_type = 'yofi-3'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']              
                                                                                 
        # Topology check in MAP-YoFi-3                                            
        status = self.verify_station_dump(self.yofi, self.config['yofi-2']['mac'])
        self.assertTrue(status, 'Station dump check in YoFi is failed')          
        self.log.info('Station dump check on mesh interface in YoFi is succeeded')
                                                                                 
        # Topology check in MAP-YoFi-3                                           
        status = self.verify_station_dump(self.yofi, self.config['panel']['sta_mac_addr'])
        # TODO should not found
        #self.assertTrue(status, 'Station dump check in YoFi is failed')          
        self.log.info('Station dump check on mesh interface in YoFi is succeeded')

        # Mesh path dump in MPP-panel                                            
        status = self.verify_mpath_dump(self.panel, self.config['yofi-2']['mac'])
        self.assertTrue(status, 'mpath dump check in panel is failed')           
        self.log.info('mpath dump check on mesh interface in Panel is succeeded')

        # TODO RSSI of panel should less than -60, RSSI of YoFi-1 should not available or more than -70
        # If not work do attenuate 30dB instead of 0dB
        unexp_mac_list = [self.config['panel']['ap_mac_addr'], self.config['panel']['sta_mac_addr']]
        exp_mac_list = [self.config['yofi-2']['mac'], self.config['yofi-2']['mac_for_wps_check']]
        status = self.cntl.get_signal_strength_in_controller(
                        self.config['controller']['rf1_wireless_adapter_mac'],
                        exp_mac_list, unexp_mac_list)
        #self.assertTrue(status, 'Getting RSSI value in RF box-1 is failed')

        exp_mac_list = [self.config['panel']['ap_mac_addr'], self.config['panel']['sta_mac_addr']]
        unexp_mac_list = [self.config['yofi-3']['mac'], self.config['yofi-3']['mac_for_wps_check']]
        status = self.cntl.get_signal_strength_in_controller(
                        self.config['controller']['outside_wireless_adapter_mac'],
                        exp_mac_list, unexp_mac_list)
        #self.assertTrue(status, 'Getting RSSI value is failed')

        # TODO If fails, Do attenuate 20dB and check again

        # Check the linear topology using mpath dump, next hop node mac and dest node mac
        self.yofi.verify_linear_topology(self.config['panel']['sta_mac_addr'], self.config['yofi-2']['mac'])
        # TODO 
        #self.assertTrue(status, 'Linear topology check in YoFi-3 is failed')
                                                                                 
        # Netv assoc for 5GHz
        self.display_mesh_node_connection_status(self.config['panel']['sta_mac_addr'])

        # Displays the where the camera is connected using netv assoc 2.4         
        status = self.display_camera_connection_status(self.config['camera']['mac'], panel_flag=True)
        self.log.info('Display cameras connection status in Panel MPP')         
                                                                                 
        # Stop sniffer_1 capture                                                 
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_1')                      
            self.assertTrue(status, 'Sniffer_1 stop is failed')                  
        validation_5 = self.multiple_sniffer_handler['sniffer_1']['pcap_filename']
                                                                                 
        # Stop sniffer_3 capture                                                 
        if self.config['sniffer_3']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_3')                      
            self.assertTrue(status, 'Sniffer_3 stop is failed')                  
        rf_1_linear_validation = self.multiple_sniffer_handler['sniffer_3']['pcap_filename']
                                                                                 
        # Start sniffer_1 capture                                                  
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_1', '5', 'camera_switch')
            self.assertTrue(status, 'Sniffer_1 start is failed')                 
                                                                                 
        # Start sniffer_3 capture                                                  
        if self.config['sniffer_3']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_3', '5', 'rf_1_camera_switch')
            self.assertTrue(status, 'Sniffer_3 start is failed')                 
                                                                                 
        # Connecting camera to mesh node using bssid                                 
        self.connect_camera_to_mesh_node('dbc_camera_2',
                                    self.config['yofi-3']['mac_for_wps_check'])

        self.get_camera_config('ping_camera_2')                                  

        # Gets the yofi-2 instance                                               
        yofi_type = 'yofi-2'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']              
                                                                                 
        # Topology check in MPP-YoFi, Camera should connected to YoFi            
        status = self.verify_station_dump(self.yofi, self.config['camera']['mac'], 'wlan1')
        self.assertTrue(status, 'Station dump check in YoFi is failed')          
        self.log.info('Station dump check on 2.4GHz interface in YoFi is succeeded')
                                                                                 
        # Stop sniffer_4 capture                                                 
        if self.config['sniffer_4']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_4')                      
            self.assertTrue(status, 'Sniffer_4 stop is failed')                  
        rf_1_camera_switch_pcap = self.multiple_sniffer_handler['sniffer_4']['pcap_filename']
                                                                                 
        # Stop sniffer_5 capture                                                 
        if self.config['sniffer_5']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_5')                      
            self.assertTrue(status, 'Sniffer_5 stop is failed')                  
        rf_2_camera_switch_pcap = self.multiple_sniffer_handler['sniffer_5']['pcap_filename']
                                                                                 
        # Stop sniffer_1 capture                                                 
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_1')                      
            self.assertTrue(status, 'Sniffer_1 stop is failed')                  
        camera_switch_pcap_in_5 = self.multiple_sniffer_handler['sniffer_1']['pcap_filename']
                                                                                 
        # Stop sniffer_3 capture                                                 
        if self.config['sniffer_3']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_3')                      
            self.assertTrue(status, 'Sniffer_1 stop is failed')                  
        rf_1_camera_switch_pcap_in_5 = self.multiple_sniffer_handler['sniffer_3']['pcap_filename']

        # Turn on the panel signal in RF box-2                                  
        status = self.att_obj.set_attenuation(self.config['attenuator']['on'],  
                                    self.config['attenuator']['channel_2'],     
                                    self.config['attenuator']['attenuator_1'])  
        self.assertTrue(status, 'Passing panel signal in RF box-2 is failed')   

        # Start sniffer_3 capture                                                  
        if self.config['sniffer_3']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_3', '5', 'delete_yofi_2')
            self.assertTrue(status, 'Sniffer_3 start is failed')                 
                                                                                 
        # Gets the yofi-3 instance                                               
        yofi_type = 'yofi-3'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']              

        # Get channel from YoFi-3                                                
        yofi_3_channel = self.yofi.get_channel('wlan1')                          
        self.assertTrue(yofi_3_channel, 'Getting YoFi-3 2.4GHz channel is failed')
                                                                                 
        # Start sniffer_4 capture                                                
        if self.config['sniffer_4']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_4', '2.4', 'delete_yofi_2', yofi_3_channel)
            self.assertTrue(status, 'Sniffer_4 start is failed')                 
                                                                                 
        # Start sniffer_5 capture                                                
        if self.config['sniffer_5']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_5', '2.4', 'ping_camera_roam')
            self.assertTrue(status, 'Sniffer_5 start is failed')                 
                                                                                 
        # TODO get the .svg files to controller with different name

        # TODO Ping between Panel and Camera Sta's

        # Camera video streamming                                                
        status = self.camera_stream_in_controller(camera_type_list,              
                                                  live_video_stream_duration=1200,
                                                  validation_flag=False)         
        self.assertTrue(status, 'Camera streaming in controller is failed')      
                                                                                 
        # Stream camera 60s via panel before Panel reboot                        
        time.sleep(60)

        # Gets the yofi-2 instance                                               
        yofi_type = 'yofi-2'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']              
                                                                                 
        # Delete the MAP-1 yofi-2                                                
        status = self.delete_yofi_from_panel('yofi-2')                           
        self.assertTrue(status, 'YoFi-2 delete is failed')                       
        self.log.info('YoFi-2 delete is succeeded')                              
                                                                                 
        # Clear the YoFi-2 detailes                                              
        del(self.multiple_yofi_handler['yofi-2'])                                
                                                                                 
        time.sleep(120)                                                           
                                                                                 
        # Stream should stop                                                     
        status = self.validate_camera_stream_in_controller(camera_type_list,     
                    live_video_stream_duration=1200)                             
        self.assertFalse(status, 'Camera streaming is not stopped in controller')
        self.log.info('Camera streaming is stopped in controller')

        # Stop sniffer_3 capture                                                 
        if self.config['sniffer_3']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_3')                      
            self.assertTrue(status, 'Sniffer_1 stop is failed')                  
        delete_yofi_2_in_5 = self.multiple_sniffer_handler['sniffer_3']['pcap_filename']

        # Stop sniffer_4 capture                                                 
        if self.config['sniffer_4']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_4')                      
            self.assertTrue(status, 'Sniffer_4 stop is failed')                  
        delete_yofi_2_in_24 = self.multiple_sniffer_handler['sniffer_4']['pcap_filename']
                                                                                 
        # Gets the yofi-3 instance                                               
        yofi_type = 'yofi-3'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']              

        self.get_camera_config('ping_camera_2')

        # Do station dump for ping camera in Panel
        status = self.verify_station_dump(self.panel, self.config['camera']['mac'], 'wlan1')
        self.assertTrue(status, 'Ping camera is not connected to panel')
        self.log.info('Ping camera is connected to panel')
                                                                                 
        self.get_camera_config('dbc_camera_2')

        # Do ping from panel to ping camera
        status = self.panel.ping(self.multiple_yofi_handler['ping_camera_2']['camera_ip'])                                    
        self.assertTrue(status, 'Ping from panel(MPP) to Ping camera is failed') 
        self.log.info('Ping from panel(MPP) to Ping camera is successfull')      
                                                                                 
        # Do ping from panel to DBC camera, ping opertaion should fail
        status = self.panel.ping(self.multiple_yofi_handler['ping_camera_2']['camera_ip'])                                    
        self.assertFalse(status, 'Ping from panel(MPP) to Ping camera is successfull') 
        self.log.info('Ping from panel(MPP) to Ping camera is failed, expected result')      
        
        # Live ping camera stream in panel
        status = self.camera_stream_in_panel(['ping_camera_2'])                   
        self.assertTrue(status, 'Ping Camera streaming in panel is failed')
        self.log.info('Ping Camera streaming in panel is successfull')      

        # Mesh path dump in MPP-panel                                            
        status = self.verify_mpath_dump(self.panel, self.config['yofi-2']['mac'])
        self.assertFalse(status, 'YoFi-2 entry found in mpath dump')           
        self.log.info('YoFi-2 entry is not found in mpath dump')

        # TODO Should not show DBC camera in yofi-3
        # Do station dump for DBC camera in Panel
        status = self.verify_station_dump(self.yofi, self.config['camera']['mac'], 'wlan1')
        #self.assertFalse(status, 'DBC camera is connected to panel')
        #self.log.info('DBC camera is not connected to panel')
                                                                                 
        ip_address = self.yofi.get_yofi_ip('br-lan')
        self.assertFalse(ip_address, 'YoFi-3 MAP-2 IP address: {}'.format(ip_address))
        self.log.info('YoFi-3 MAP-2 do not have an IP address')

        # Stop sniffer_5 capture                                                 
        if self.config['sniffer_5']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_5')                      
            self.assertTrue(status, 'Sniffer_5 stop is failed')                  
        ping_camera_roam_pcap = self.multiple_sniffer_handler['sniffer_5']['pcap_filename']
                                                                                 
        self.get_sniffer_utility_instance()                                      
                                                                                 
        panel_sta_mac = self.config['panel']['sta_mac_addr']                     
        yofi_2_mac = self.config['yofi-2']['mac']                                
        yofi_3_mac = self.config['yofi-3']['mac']                                
        panel_ap_mac = self.config['panel']['ap_mac_addr']                       
        yofi_2_mac_for_24 = self.config['yofi-2']['mac_for_wps_check']           
        yofi_3_mac_for_24 = self.config['yofi-3']['mac_for_wps_check']           
                                                                                 
        # Sniffer_1 frame analysis                                               
        self.log.info('Sniffer_1 analysis between YoFi-2(MAP) and panel(MPP)')   
        self.log.info('Sniffer_1 pcap file: {}'.format(add_yofi_2_pcap_in_5))    
        status = self.sniffer_analysis.validate_MPP_and_MAP_connection_with_sae_and_peer_action_frames(add_yofi_2_pcap_in_5, yofi_2_mac, panel_sta_mac)
                                                                                 
        # Sniffer_2 frame analysis, Source Mac should be STA (YoFi)              
        self.log.info('Sniffer_2 analysis between YoFi-2(MAP) and panel(MPP)')   
        self.log.info('Sniffer_2 pcap file: {}'.format(add_yofi_2_pcap_in_24))   
        status = self.sniffer_analysis.wps_connect(add_yofi_2_pcap_in_24, yofi_2_mac_for_24, panel_ap_mac)
                                                                                 
        # Sniffer_3 frame analysis                                               
        self.log.info('Sniffer_3 analysis between YoFi-3(MAP) and panel(MPP)')   
        self.log.info('Sniffer_3 pcap file: {}'.format(add_yofi_3_pcap_in_5))    
        status = self.sniffer_analysis.validate_MPP_and_MAP_connection_with_sae_and_peer_action_frames(add_yofi_3_pcap_in_5, yofi_3_mac, panel_sta_mac)
                                                                                 
        # Sniffer_4 frame analysis, Source Mac should be STA (YoFi)              
        self.log.info('Sniffer_4 analysis between YoFi-3(MAP) and panel(MPP)')   
        self.log.info('Sniffer_4 pcap file: {}'.format(add_yofi_3_pcap_in_24))   
        status = self.sniffer_analysis.wps_connect(add_yofi_3_pcap_in_24, yofi_3_mac_for_24, panel_ap_mac)

        # TODO
        # Sniffer_3 frame analysis                                               
        self.log.info('Sniffer_3 analysis between YoFi-3(MAP-2) and YoFi-2(MAP-1)')   
        self.log.info('Sniffer_3 pcap file: {}'.format(rf_1_linear_validation))    
        status = self.sniffer_analysis.validate_MPP_and_MAP_connection_with_sae_and_peer_action_frames(rf_1_linear_validation, yofi_2_mac, yofi_3_mac)
                                                                                 
        # Sniffer_4 packet check M1/M2 packet analysis                                                  
        self.log.info('Sniffer_4 packet checking')                               
        total_errors = {}                                                        
        for camera_type_name in ['dbc_camera_2']:                               
            self.get_camera_config(camera_type_name)                             
            self.log.info('#################################################')   
            self.log.info('Started WPS IE validation for {}'.format(camera_type_name))
            self.log.info('Sniffer_4 pcap file: {}'.format(rf_1_add_camera_pcap))
            camera_mac = self.config[camera_type_name]['mac']                    
            status, errors = self.sniffer_analysis.GES_Vivint_Yofi_PAK_0016_24G_analysis(rf_1_add_camera_pcap, self.config)
            status_camera_add = self.sniffer_analysis.wps_connect(rf_1_add_camera_pcap, camera_mac, panel_ap_mac)
            if not status_camera_add:                                            
                errors.append('WPS connection is failed')                        
            total_errors[camera_type_name] = errors                              
            self.log.info('WPS IE validation is done for {}'.format(camera_type_name))
            self.log.info('#################################################')   
                                                                                 
        for camera_type_name in total_errors.keys():                             
            self.log.info('#################################################')   
            self.log.info('Errors found during validation of {}'.format(camera_type_name))
            self.log.info('#################################################')
            for error in total_errors[camera_type_name]:                         
                self.log.error('{} of {}'.format(error, camera_type_name))       
            self.log.info('#################################################')   
            error_length = [len(total_errors[item]) for item in total_errors]    
        if not all(i == 0 for i in error_length):                                
            self.log.error('M1/M2 packet check failed')                          
                                                                                 
        # Sniffer_5 packet check M1/M2 packet analysis                                                  
        self.log.info('Sniffer_5 packet checking')                               
        total_errors = {}                                                        
        for camera_type_name in ['ping_camera_2']:                               
            self.get_camera_config(camera_type_name)                             
            self.log.info('#################################################')   
            self.log.info('Started WPS IE validation for {}'.format(camera_type_name))
            self.log.info('Sniffer_5 pcap file: {}'.format(rf_2_add_camera_pcap))
            camera_mac = self.config[camera_type_name]['mac']                    
            status, errors = self.sniffer_analysis.GES_Vivint_Yofi_PAK_0016_24G_analysis(rf_2_add_camera_pcap, self.config)
            status_camera_add = self.sniffer_analysis.wps_connect(rf_2_add_camera_pcap, camera_mac, panel_ap_mac)
            if not status_camera_add:                                            
                errors.append('WPS connection is failed')                        
            total_errors[camera_type_name] = errors                              
            self.log.info('WPS IE validation is done for {}'.format(camera_type_name))
            self.log.info('#################################################')   
                                                                                 
        for camera_type_name in total_errors.keys():                             
            self.log.info('#################################################')   
            self.log.info('Errors found during validation of {}'.format(camera_type_name))
            self.log.info('#################################################')   
            for error in total_errors[camera_type_name]:                         
                self.log.error('{} of {}'.format(error, camera_type_name))       
            self.log.info('#################################################')   
        error_length = [len(total_errors[item]) for item in total_errors]        
        if not all(i == 0 for i in error_length):                                
            self.log.error('M1/M2 packet check failed')                          
                                                                                 
        # Sniffer_4 frames analysis for camera switch                                                 
        self.log.info('Sniffer_4 packet checking for camera switch')             
        total_errors = {}                                                        
        for camera_type_name in ['dbc_camera_2']:                               
            self.get_camera_config(camera_type_name)                             
            self.log.info('Started WPS connection validation for {}'.format(camera_type_name))
            self.log.info('Sniffer_4 pcap file: {}'.format(rf_1_camera_switch_pcap))
            camera_mac = self.config[camera_type_name]['mac']                    
            status = self.sniffer_analysis.connection_over_24GHz(rf_1_camera_switch_pcap, camera_mac, yofi_3_mac_for_24)
                                                                                 
        # Sniffer_5 frames analysis for camera switch                                                 
        self.log.info('Sniffer_5 packet checking for camera switch')             
        total_errors = {}                                                        
        for camera_type_name in ['ping_camera_2']:                               
            self.get_camera_config(camera_type_name)                             
            self.log.info('Started WPS connection validation for {}'.format(camera_type_name))
            self.log.info('Sniffer_5 pcap file: {}'.format(rf_2_camera_switch_pcap))
            camera_mac = self.config[camera_type_name]['mac']                    
            status = self.sniffer_analysis.connection_over_24GHz(rf_2_camera_switch_pcap, camera_mac, yofi_2_mac_for_24)
                                                                                 
        # TODO working properly
        # Sniffer_3 frame analysis, Validate the close frame of YoFi-2     
        self.log.info('Sniffer_3 analysis between YoFi-2(MAP) and YoFi-3(MAP)')   
        self.log.info('Sniffer_3 pcap file: {}'.format(delete_yofi_2_in_5))   
        status = self.sniffer_analysis.mesh_peer_close_5G_analysis(delete_yofi_2_in_5, yofi_2_mac, yofi_3_mac)

        # TODO working properly
        # Sniffer_3 frame analysis, Validate the close frame of YoFi-2     
        self.log.info('Sniffer_3 analysis between YoFi-2(MAP) and Panel (MPP)')   
        self.log.info('Sniffer_3 pcap file: {}'.format(delete_yofi_2_in_5))   
        status = self.sniffer_analysis.mesh_peer_close_5G_analysis(delete_yofi_2_in_5, yofi_2_mac, panel_sta_mac)

        # TODO working properly
        # Sniffer_4 frame analysis, Validate the disassoc/deauth frame of YoFi-2 for connected STA    
        self.log.info('Sniffer_4 analysis between YoFi-2(MAP) and Camera')   
        self.log.info('Sniffer_4 pcap file: {}'.format(delete_yofi_2_in_24))   
        status = self.sniffer_analysis.disconnection_24G_analysis(delete_yofi_2_in_24, yofi_2_mac, self.config['dbc_camera_2']['mac'])

        # Sniffer_5 frames analysis for camera switch                                                 
        self.log.info('Sniffer_5 packet checking for camera switch')             
        total_errors = {}                                                        
        for camera_type_name in ['ping_camera_2']:                               
            self.get_camera_config(camera_type_name)                             
            self.log.info('Started WPS connection validation for {}'.format(camera_type_name))
            self.log.info('Sniffer_5 pcap file: {}'.format(ping_camera_roam_pcap))
            camera_mac = self.config[camera_type_name]['mac']                    
            status = self.sniffer_analysis.connection_over_24GHz(ping_camera_roam_pcap, camera_mac, panel_ap_mac)

    @attr(test_category='SnS')
    @attr(test_id='GES_Vivint_Yofi_SnS_0007')
    @nose.allure.severity(nose.allure.severity_level.CRITICAL)
    @nose.allure.feature("Stress Panel with Cams streaming and FPing with Yofi mesh having MPP(Panel), MAP's(YoFi) in daisy chain topology")
    def test_08_GES_Vivint_Yofi_SnS_0007(self):
        """Stress Panel with Cams streaming and FPing with Yofi mesh having MPP(Panel), MAP's(YoFi) in daisy chain topology
        :Vivint Testrail ID : C1177895
        :Test Case ID: GES_Vivint_Yofi_SnS_0007
        :author: GES automation dev
        """
        self.log.info('======= Testcase started =======')
        self.testcase_name = sys._getframe().f_code.co_name
        test_case = getattr(self, self.testcase_name)
        self.log_path = '{}{}/{}/'.format(self.config['controller']['log_path'], execution_log_path, test_case.test_category)
        self.log.debug('Fun name: {}\n'.format(self.testcase_name))

        # Creating log directory with testcase_name
        self.log_path_with_test_name =  self.cntl.create_log_dir_with_testcase_name(self.log_path, self.testcase_name)
        self.log.info('Log path of testcase directory: {}'.format(self.log_path_with_test_name))

        camera_type_list = ['dbc_camera_1', 'hd400w_camera', 'ping_camera_2', 'hdp450_camera']
        self.check_cameras_in_ap_mode(camera_type_list)

        status = self.att_obj.set_all_channel_to_high_attenuation(               
                                    self.config['attenuator']['attenuator_1'])   
        self.assertTrue(status, 'Set all channel to high attenuation_1 is failed') 
        self.log.info('Set all channel to high attenuation_1 is successful')

        status = self.att_obj.set_all_channel_to_high_attenuation(               
                                    self.config['attenuator']['attenuator_2'])   
        self.assertTrue(status, 'Set all channel to high attenuation_2 is failed') 
        self.log.info('Set all channel to high attenuation_2 is successful')

        # Turn on the panel signal in RF box-1                                  
        status = self.att_obj.set_attenuation(self.config['attenuator']['on'],  
                                    self.config['attenuator']['channel_1'],     
                                    self.config['attenuator']['attenuator_1'])  
        self.assertTrue(status, 'Passing panel signal in RF box-1 is failed')   
        self.attenuator_1 = True

        # Turn on the panel signal in RF box-2                                  
        status = self.att_obj.set_attenuation(self.config['attenuator']['on'],  
                                    self.config['attenuator']['channel_2'],     
                                    self.config['attenuator']['attenuator_1'])  
        self.assertTrue(status, 'Passing panel signal in RF box-2 is failed')   
        self.attenuator_2 = True

        # Configure panel as MPP                                                 
        self.panel_mpp_ip = self.configure_mpp(self.panel)                       
        self.assertTrue(self.panel_mpp_ip, 'get MPP IP address is failed')       
                                                                                 
        '''
        # Get mesh ID and psk from panel                                         
        status = self.panel.get_mesh_id_and_psk()                                
        self.assertTrue(status, 'Failed to get mesh_id and wps_psk')             
        '''
                                                                                 
        # Start sniffer_2 capture                                                  
        if self.config['sniffer_2']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_2', '2.4', 'add_camera')
            self.assertTrue(status, 'Sniffer_2 start is failed')                 
                                                                                 
        # Select the PCI card                                                    
        self.log.info('Outside wireless adapter mac: {}'.format(                 
                                self.config['controller']['outside_wireless_adapter_mac']))
        self.cntl.pci_mac=self.config['controller']['outside_wireless_adapter_mac']
                                                                                 
        # Gets the camera instance                                               
        self.get_camera_instance('hd400w_camera')                                
                                                                                 
        # Add Camera                                                             
        status = self.add_camera_to_panel('wps')                                 
        self.assertTrue(status, 'camera addition is failed')                     
        self.log.info('camera addition is succeeded')
                                                                          
        # Gets the camera instance                                               
        self.get_camera_instance('dbc_camera_1')                                 
                                                                                 
        # Add Camera                                                             
        status = self.add_camera_to_panel('wps')                                 
        self.assertTrue(status, 'camera addition is failed')                     
        self.log.info('camera addition is succeeded')

        # Select the PCI card                                                    
        self.log.info('RF-2 wireless adapter card: {}'.format(                   
                      self.config['controller']['rf2_wireless_adapter_mac']))
        self.cntl.pci_mac=self.config['controller']['rf2_wireless_adapter_mac']  
                                                                                 
        # Start sniffer_5 capture                                                  
        if self.config['sniffer_5']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_5', '2.4', 'rf_2_add_camera')
            self.assertTrue(status, 'Sniffer_5 start is failed')                 
                                                                                 
        # Gets the camera instance                                               
        self.get_camera_instance('ping_camera_2')                                
                                                                                 
        # Add Camera                                                             
        status = self.add_camera_to_panel('wps')                                 
        self.assertTrue(status, 'camera addition is failed')                     
        self.log.info('camera addition is succeeded')

        # Gets the camera instance                                               
        self.get_camera_instance('hdp450_camera')                                
                                                                                 
        # Add Camera                                                             
        status = self.add_camera_to_panel('wps')                                 
        self.assertTrue(status, 'camera addition is failed')                     
        self.log.info('camera addition is succeeded')                            
                                                                                                                                     
        # Stop sniffer_2 capture                                                 
        if self.config['sniffer_2']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_2')                      
            self.assertTrue(status, 'Sniffer_2 stop is failed')                  
        add_camera_pcap = self.multiple_sniffer_handler['sniffer_2']['pcap_filename']
                                                                                 
        # Stop sniffer_5 capture                                                 
        if self.config['sniffer_5']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_5')                      
            self.assertTrue(status, 'Sniffer_5 stop is failed')                  
        rf_2_add_camera_pcap = self.multiple_sniffer_handler['sniffer_5']['pcap_filename']
                                                                                 
        # Gets the yofi-2 instance                                               
        self.get_yofi_instance('yofi-2')

        # Start sniffer_1 capture                                                  
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_1', '5', 'adding_yofi_2_to_panel', sniffer_flag=False)
            self.assertTrue(status, 'Sniffer_1 start is failed')                 
                                                                                 
        # Start sniffer_2 capture                                                
        if self.config['sniffer_2']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_2', '2.4', 'adding_yofi_2_to_panel')
            self.assertTrue(status, 'Sniffer_2 start is failed')

        # Add yofi-2                                                               
        status = self.add_yofi_node_to_panel('wps')                              
        self.assertTrue(status, 'yofi-2 addition is failed')                     
        self.log.info('yofi-2 addition is succeeded')

        # Stop sniffer_1 capture                                                 
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_1')                      
            self.assertTrue(status, 'Sniffer_1 stop is failed')                  
        add_yofi_2_pcap_in_5  = self.multiple_sniffer_handler['sniffer_1']['pcap_filename']
                                                                                 
        # Stop sniffer_2 capture                                                 
        if self.config['sniffer_2']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_2')                      
            self.assertTrue(status, 'Sniffer_2 stop is failed')                  
        add_yofi_2_pcap_in_24  = self.multiple_sniffer_handler['sniffer_2']['pcap_filename']
                                                                                 
        # TODO RSSI of panel should less than -60, RSSI of YoFi-2 should not available or more than -70
        # If not work do attenuate 30dB instead of 0dB
        exp_mac_list = [self.config['panel']['ap_mac_addr'], self.config['panel']['sta_mac_addr']]
        unexp_mac_list = [self.config['yofi-2']['mac'], self.config['yofi-2']['mac_for_wps_check']]
        status = self.cntl.get_signal_strength_in_controller(
                        self.config['controller']['rf1_wireless_adapter_mac'],
                        exp_mac_list, unexp_mac_list)
        #self.assertTrue(status, 'Getting RSSI value in RF box-1 is failed')

        # Start sniffer_1 capture                                                  
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_1', '5', 'valiadtion')
            self.assertTrue(status, 'Sniffer_1 start is failed')                 
                                                                                 
        # Gets the yofi-3 instance
        self.get_yofi_instance('yofi-3')

        # Start sniffer_3 capture                                                  
        if self.config['sniffer_3']['enable'].lower() == 'true':
            status = self.start_sniffer_capture('sniffer_3', '5', 'adding_yofi_3_to_panel')
            self.assertTrue(status, 'Sniffer_3 start is failed')

        # Start sniffer_4 capture
        if self.config['sniffer_4']['enable'].lower() == 'true':
            status = self.start_sniffer_capture('sniffer_4', '2.4', 'adding_yofi_3_to_panel')
            self.assertTrue(status, 'Sniffer_4 start is failed')

        # Add yofi-3
        status = self.add_yofi_node_to_panel('wps')
        self.assertTrue(status, 'yofi-3 addition is failed')
        self.log.info('yofi-3 addition is succeeded')

        # Stop sniffer_4 capture
        if self.config['sniffer_4']['enable'].lower() == 'true':
            status = self.stop_sniffer_capture('sniffer_4')
            self.assertTrue(status, 'Sniffer_4 stop is failed')
        add_yofi_3_pcap_in_24  = self.multiple_sniffer_handler['sniffer_4']['pcap_filename']

        # Stop sniffer_3 capture                                                 
        if self.config['sniffer_3']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_3')                      
            self.assertTrue(status, 'Sniffer_3 stop is failed')                  
        add_yofi_3_pcap_in_5 = self.multiple_sniffer_handler['sniffer_3']['pcap_filename']
                                                                                 
        # Start sniffer_3 capture                                                  
        if self.config['sniffer_3']['enable'].lower() == 'true':
            status = self.start_sniffer_capture('sniffer_3', '5', 'rf_1_linear')
            self.assertTrue(status, 'Sniffer_3 start is failed')

        # Get channel from YoFi-3                                                
        yofi_3_channel = self.yofi.get_channel('wlan1')                          
        self.assertTrue(yofi_3_channel, 'Getting YoFi-3 2.4GHz channel is failed')
                                                                                 
        # Start sniffer_5 capture                                                
        if self.config['sniffer_5']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_5', '2.4', 'rf_2_camera_switch', yofi_3_channel)
            self.assertTrue(status, 'Sniffer_5 start is failed')                 
                                                                                 
        # Turn off the panel signal in RF box-1                                  
        status = self.att_obj.set_attenuation(self.config['attenuator']['off'],  
                                    self.config['attenuator']['channel_1'],      
                                    self.config['attenuator']['attenuator_1'])
        self.assertTrue(status, 'Blocking panel signal in RF box-1 is failed')   
                                                                                 
        # Turn off the panel signal in RF box-2                                  
        status = self.att_obj.set_attenuation(self.config['attenuator']['off'],  
                                    self.config['attenuator']['channel_2'],      
                                    self.config['attenuator']['attenuator_1'])
        self.assertTrue(status, 'Blocking panel signal in RF box-2 is failed')   

        time.sleep(10)                                                           
                                                                                 
        # Turn on the YoFi-2 signal in RF box-1                                  
        status = self.att_obj.set_attenuation(self.config['attenuator']['on'],   
                                    self.config['attenuator']['channel_1'],      
                                    self.config['attenuator']['attenuator_2'])   
        self.assertTrue(status, 'Passing YoFi-2 signal in RF box-1 is failed')   
                                                                                 
        # Turn on the YoFi-3 signal in RF box-2                                  
        status = self.att_obj.set_attenuation(self.config['attenuator']['on'],   
                                    self.config['attenuator']['channel_3'],      
                                    self.config['attenuator']['attenuator_2'])   
        self.assertTrue(status, 'Passing YoFi-3 signal in RF box-2 is failed')   
                                                                                 
        # Verify YoFi-3 node is MAP mesh type
        status = self.yofi.is_mesh_node_map()
        self.assertTrue(status, 'YoFi-3 is not in MAP mode')
        self.log.info('YoFi-3 is in MAP mode')

        # Verify panel node is MPP mesh type                                     
        status = self.panel.is_mesh_node_mpp()                                   
        self.assertTrue(status, 'Panel is not in MPP mode')                      
        self.log.info('Panel is in MPP mode')
                                                                                 
        yofi_type = 'yofi-2'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']              
       	
        # Verify YoFi-2 node is MAP mesh type
        status = self.yofi.is_mesh_node_map()
        self.assertTrue(status, 'YoFi-2 is not in MAP mode')
        self.log.info('YoFi-2 is in MAP mode')

        # Ping from Yofi-2(MAP) to Panel(MPP)                                    
        status = self.yofi.ping(self.config['panel']['nw_br_lan_ip'])            
        #self.assertTrue(status, 'Ping from YoFi-2(MAP) to panel(MPP) is failed') 
        self.log.info('Ping from YoFi-2(MAP) to panel(MPP) is successfull')      
                                                                                 
        # Ping from Yofi-2(MAP) to Yofi-3(MAP)                                   
        status = self.yofi.ping(self.multiple_yofi_handler['yofi-3']['yofi_ip']) 
        #self.assertTrue(status, 'Ping from yofi-2(MAP) to YoFi-3(MAP) is failed')
        self.log.info('Ping from Yofi-2(MAP) to YoFi-3(MAP) is successfull')

        # Ping from Panel(MPP) to Yofi-2(MAP)                                    
        status = self.panel.ping(self.multiple_yofi_handler['yofi-2']['yofi_ip'])
        #self.assertTrue(status, 'Ping from panel(MPP) to YoFi-2(MAP) is failed') 
        self.log.info('Ping from panel(MPP) to YoFi-2(MAP) is successfull')

        # Ping from Panel(MPP) to Yofi-3(MAP)                                    
        status = self.panel.ping(self.multiple_yofi_handler['yofi-3']['yofi_ip'])                                    
        # TODO
        #self.assertTrue(status, 'Ping from panel(MPP) to YoFi-3(MAP) is failed') 
        self.log.info('Ping from panel(MPP) to YoFi-3(MAP) is successfull')      
                                                                                 
        yofi_type = 'yofi-3'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']              
                                                                                 
        # Ping from Yofi-3(MAP) to Panel(MPP)                                    
        status = self.yofi.ping(self.config['panel']['nw_br_lan_ip'])            
        # TODO
        #self.assertTrue(status, 'Ping from YoFi-3(MAP) to panel(MPP) is failed') 
        self.log.info('Ping from YoFi-3(MAP) to panel(MPP) is successfull')      
                                                                                 
        # Ping from Yofi-3(MAP) to Yofi-2(MAP)                                   
        status = self.yofi.ping(self.multiple_yofi_handler['yofi-2']['yofi_ip']) 
        #self.assertTrue(status, 'Ping from yofi-3(MAP) to YoFi-2(MAP) is failed')
        self.log.info('Ping from Yofi-3(MAP) to YoFi-2(MAP) is successfull')

        # Topology check in MAP-YoFi-3                                            
        status = self.verify_station_dump(self.yofi, self.config['yofi-2']['mac'])
        self.assertTrue(status, 'Station dump check in YoFi is failed')          
        self.log.info('Station dump check on mesh interface in YoFi is succeeded')
                                                                                 
        # Topology check in MAP-YoFi-3                                           
        status = self.verify_station_dump(self.yofi, self.config['panel']['sta_mac_addr'])
        # TODO should not found
        #self.assertTrue(status, 'Station dump check in YoFi is failed')          
        self.log.info('Station dump check on mesh interface in YoFi is succeeded')

        # Topology check in panel MPP                                            
        status = self.verify_station_dump(self.panel, self.config['yofi-2']['mac'])
        self.assertTrue(status, 'Station dump check in Panel is failed')         
        self.log.info('Station dump check on mesh interface in Panel is succeeded')
                                                                                 
        # Topology check in Panel MPP                                            
        status = self.verify_station_dump(self.panel, self.config['yofi-3']['mac'])
        # TODO should not found
        #self.assertTrue(status, 'Station dump check in Panel is failed')         
        self.log.info('Station dump check on mesh interface in Panel is succeeded')
                                                                                 
        # Gets the yofi-2 instance                                               
        yofi_type = 'yofi-2'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']              
                                                                                 
        # Topology check in MAP-YoFi-2                                            
        status = self.verify_station_dump(self.yofi, self.config['yofi-3']['mac'])
        self.assertTrue(status, 'Station dump check in YoFi is failed')          
        self.log.info('Station dump check on mesh interface in YoFi is succeeded')
                                                                                 
        # Topology check in MAP-YoFi-2                                            
        status = self.verify_station_dump(self.yofi, self.config['panel']['sta_mac_addr'])
        self.assertTrue(status, 'Station dump check in YoFi is failed')          
        self.log.info('Station dump check on mesh interface in YoFi is succeeded')
                                                                                 
        # Get mesh graph .svg file from panel if this flag True
        self.mesh_graph_flag = True

        # TODO RSSI of panel should less than -60, RSSI of YoFi-2 should not available or more than -70
        # If not work do attenuate 30dB instead of 0dB
        unexp_mac_list = [self.config['panel']['ap_mac_addr'], self.config['panel']['sta_mac_addr']]
        exp_mac_list = [self.config['yofi-2']['mac'], self.config['yofi-2']['mac_for_wps_check']]
        status = self.cntl.get_signal_strength_in_controller(
                        self.config['controller']['rf1_wireless_adapter_mac'],
                        exp_mac_list, unexp_mac_list)
        #self.assertTrue(status, 'Getting RSSI value in RF box-1 is failed')

        exp_mac_list = [self.config['panel']['ap_mac_addr'], self.config['panel']['sta_mac_addr']]
        unexp_mac_list = [self.config['yofi-3']['mac'], self.config['yofi-3']['mac_for_wps_check']]
        status = self.cntl.get_signal_strength_in_controller(
                        self.config['controller']['outside_wireless_adapter_mac'],
                        exp_mac_list, unexp_mac_list)
        #self.assertTrue(status, 'Getting RSSI value is failed')

        # TODO If fails, Do attenuate 20dB and check again

        # Gets the yofi-3 instance                                               
        yofi_type = 'yofi-3'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']              
                                                                                 
        # Check the linear topology using mpath dump, next hop node mac and dest node mac
        self.yofi.verify_linear_topology(self.config['panel']['sta_mac_addr'], self.config['yofi-2']['mac'])
        # TODO 
        #self.assertTrue(status, 'Linear topology check in YoFi-3 is failed')
                                                                                 
        # Netv assoc for 5GHz
        self.display_mesh_node_connection_status(self.config['panel']['sta_mac_addr'])

        # Displays the where the camera is connected using netv assoc 2.4         
        status = self.display_camera_connection_status(self.config['camera']['mac'], panel_flag=True)
        self.log.info('Display cameras connection status in Panel MPP')         
                                                                                
        # Stop sniffer_1 capture                                                 
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_1')                      
            self.assertTrue(status, 'Sniffer_1 stop is failed')                  
        validation_5 = self.multiple_sniffer_handler['sniffer_1']['pcap_filename']
                                                                                 
        # Stop sniffer_3 capture                                                 
        if self.config['sniffer_3']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_3')                      
            self.assertTrue(status, 'Sniffer_3 stop is failed')                  
        rf_1_linear_validation = self.multiple_sniffer_handler['sniffer_3']['pcap_filename']
      
        # Start sniffer_1 capture                                                  
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_1', '5', 'camera_switch')
            self.assertTrue(status, 'Sniffer_1 start is failed')                 

        # Start sniffer_3 capture                                                  
        if self.config['sniffer_3']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_3', '5', 'rf_1_camera_switch')
            self.assertTrue(status, 'Sniffer_3 start is failed')                 
                                                                                 
        # Gets the yofi-2 instance                                               
        yofi_type = 'yofi-2'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']              
                                                                                 
        # Get channel from YoFi-2                                                
        yofi_2_channel = self.yofi.get_channel('wlan1')                          
        self.assertTrue(yofi_2_channel, 'Getting YoFi-2 2.4GHz channel is failed')
                                                                                 
        # Start sniffer_2 capture                                                
        if self.config['sniffer_2']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_2', '2.4', 'camera_switch', yofi_2_channel)
            self.assertTrue(status, 'Sniffer_2 start is failed')                 
                                                                                 
        # Connecting camera to mesh node using bssid                                 
        self.connect_camera_to_mesh_node('hd400w_camera', self.config['yofi-2']['mac_for_wps_check'])

        # Connecting camera to mesh node using bssid                                 
        self.connect_camera_to_mesh_node('dbc_camera_1', self.config['yofi-2']['mac_for_wps_check'])
      
        # Gets the yofi-3 instance                                               
        yofi_type = 'yofi-3'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']              
                                                                                 
        self.get_camera_config('ping_camera_2')

        # Topology check in MAP-YoFi, Camera should connected to YoFi            
        status = self.verify_station_dump(self.yofi, self.config['camera']['mac'], 'wlan1')
        self.assertTrue(status, 'Station dump check in YoFi is failed')          
        self.log.info('Station dump check on 2.4GHz interface in YoFi is succeeded')
                                                                                 
        self.get_camera_config('hdp450_camera')

        # Topology check in MAP-YoFi, Camera should connected to YoFi            
        status = self.verify_station_dump(self.yofi, self.config['camera']['bridge_mac'], 'wlan1')
        self.assertTrue(status, 'Station dump check in YoFi is failed')          
        self.log.info('Station dump check on 2.4GHz interface in YoFi is succeeded')
                                                                                 
        # Stop sniffer_2 capture                                                 
        if self.config['sniffer_2']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_2')                      
            self.assertTrue(status, 'Sniffer_2 stop is failed')                  
        camera_switch_pcap = self.multiple_sniffer_handler['sniffer_2']['pcap_filename']

        # Stop sniffer_1 capture                                                 
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_1')                      
            self.assertTrue(status, 'Sniffer_1 stop is failed')                  
        camera_switch_pcap_5 = self.multiple_sniffer_handler['sniffer_1']['pcap_filename']

        # Stop sniffer_5 capture                                                 
        if self.config['sniffer_5']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_5')                      
            self.assertTrue(status, 'Sniffer_5 stop is failed')                  
        rf_2_camera_switch_pcap = self.multiple_sniffer_handler['sniffer_5']['pcap_filename']
      
        # Stop sniffer_3 capture                                                 
        if self.config['sniffer_3']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_3')                      
            self.assertTrue(status, 'Sniffer_3 stop is failed')                  
        rf_1_camera_switch_pcap_5 = self.multiple_sniffer_handler['sniffer_3']['pcap_filename']
 
        # Ping to camera from panel                                              
        status = self.ping_from_panel_to_cams_in_background(camera_type_list, self.config['durations']['live_video_stream'])
        self.assertTrue(status, 'ping from panel to camera is failed')           
        self.log.info('ping from panel to camera is successfully completed')     

        if not status:
            ping_status = self.panel.stop_ping()                                 
            self.assertTrue(ping_status, 'Failed to stop ping')                  
            self.log.info('Successfully ping stopped')                           
                                                                                 
        ping_status = self.validate_ping(camera_type_list, self.config['durations']['live_video_stream'])

        # Get panel logread                                                      
        status = self.panel.get_logread_logs(self.log_path_with_test_name, 'before_sns_stream_panel_logread.log')
        if not status:                                                           
            self.log.error('Geting panel MPP logread is failed')                 
        else:                                                                    
            self.log.info('Geting panel MPP logread is succeeded')               

        # Clear panel logread                                                    
        self.panel.clear_logread()                                               
	
        # Get YoFi-3 logread                                                     
        self.yofi_map_ip = self.multiple_yofi_handler['yofi-3']['yofi_ip']
        status = self.get_yofi_logread('yofi-3', self.yofi_map_ip, 'adding_yofi3_logread.log')
        if not status:                                                           
            self.log.error('Geting YoFi-3 MAP logread is failed')                
        else:                                                                    
            self.log.info('Geting YoFi-3 MAP logread is succeeded')              
                         
        # Clear YoFi-3 logread                                                   
        self.yofi.clear_logread() 
        
        # Gets the yofi-2 instance                                               
        yofi_type = 'yofi-2'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']              
                                                        
        # Get YoFi-2 logread                                                     
        self.yofi_map_ip = self.multiple_yofi_handler['yofi-2']['yofi_ip']
        status = self.get_yofi_logread('yofi-2', self.yofi_map_ip, 'adding_yofi2_logread.log')
        if not status:                                                           
            self.log.error('Geting YoFi-2 MAP logread is failed')                
        else:                                                                    
            self.log.info('Geting YoFi-2 MAP logread is succeeded')  
            
        # Clear YoFi-2 logread                                                   
        self.yofi.clear_logread() 
         
        # Start sniffer_1 capture                                                  
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_1', '5', 'camera_streaming')
            self.assertTrue(status, 'Sniffer_1 start is failed')                 

        # Start sniffer_3 capture                                                  
        if self.config['sniffer_3']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_3', '5', 'rf_1_camera_streaming')
            self.assertTrue(status, 'Sniffer_3 start is failed')                 

        # Get channel from YoFi-2                                                
        yofi_2_channel = self.yofi.get_channel('wlan1')                          
        self.assertTrue(yofi_2_channel, 'Getting YoFi-2 2.4GHz channel is failed')
                                                                                 
        # Start sniffer_2 capture                                                
        if self.config['sniffer_2']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_2', '2.4', 'camera_streaming', yofi_2_channel)
            self.assertTrue(status, 'Sniffer_2 start is failed')                 
        
        # Gets the yofi-3 instance                                               
        yofi_type = 'yofi-3'                                                     
        self.get_yofi_config(yofi_type)                                          
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']              

        # Get channel from YoFi-3                                            
        yofi_3_channel = self.yofi.get_channel('wlan1')                          
        self.assertTrue(yofi_3_channel, 'Getting YoFi-3 2.4GHz channel is failed')
                                                                                 
        # Start sniffer_5 capture                                                
        if self.config['sniffer_5']['enable'].lower() == 'true':                 
            status = self.start_sniffer_capture('sniffer_5', '2.4', 'rf_2_camera_streaming', yofi_3_channel)
            self.assertTrue(status, 'Sniffer_5 start is failed')                 
                                                  
        #TODO  12hr streamming  
        # Camera video streamming                                                
        status = self.camera_stream_in_controller(camera_type_list,              
                                                  live_video_stream_duration=self.config['durations']['live_video_stream'],
                                                  validation_flag=False)         
        self.assertTrue(status, 'Camera streaming in controller is failed')      
                                                                                 
        # fping to camera from panel                                              
        status = self.fping_from_panel_to_cams_in_background(camera_type_list,   
                        self.config['durations']['fping_count_in_sns'],          
                        self.config['durations']['fping_interval_in_sns'])       
        self.assertTrue(status, 'fping from panel to camera is failed')          
        self.log.info('fping from panel to camera is successfully completed') 
                                                                                                                                  
        #TODO  12hr streamming  
        status = self.validate_camera_stream_in_controller(camera_type_list,live_video_stream_duration=self.config['durations']['live_video_stream'])
                                                                                 
        if not status:
            ping_status = self.panel.stop_fping()                                
            self.assertTrue(ping_status, 'Failed to stop fping')                 
            self.log.info('Successfully fping stopped')                          

        fping_status = self.validate_fping(camera_type_list, self.config['durations']['fping_count_in_sns'])
 
        # Get YoFi-3 logread                                                     
        status = self.get_yofi_logread('yofi-3', self.multiple_yofi_handler['yofi-3']['yofi_ip'], 'sns_yofi3_logread.log')
        if not status:
            self.log.error('Geting YoFi-3 MAP logread is failed')
        else:
            self.log.info('Geting YoFi-3 MAP logread is succeeded')
                                                                                                                                   
        # Get panel logread                                                      
        status = self.panel.get_logread_logs(self.log_path_with_test_name, 'After_sns_stream_panel_logread.log')
        if not status:
            self.log.error('Geting panel MPP logread is failed')
        else:
            self.log.info('Geting panel MPP logread is succeeded')

        # Gets the yofi-2 instance                                               
        yofi_type = 'yofi-2'
        self.get_yofi_config(yofi_type)
        self.yofi = self.multiple_yofi_handler[yofi_type]['object']

        # Get YoFi-2 logread                                                     
        status = self.get_yofi_logread('yofi-2', self.multiple_yofi_handler['yofi-2']['yofi_ip'], 'sns_yofi2_logread.log')
        if not status:
            self.log.error('Geting YoFi-2 MAP logread is failed')
        else:
            self.log.info('Geting YoFi-2 MAP logread is succeeded')

        # Stop sniffer_1 capture                                                 
        if self.config['sniffer_1']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_1')                      
            self.assertTrue(status, 'Sniffer_1 stop is failed')                  
        sniffer_1_sns_pcap = self.multiple_sniffer_handler['sniffer_1']['pcap_filename']
                                                                                 
        # Stop sniffer_3 capture                                                 
        if self.config['sniffer_3']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_3')                      
            self.assertTrue(status, 'Sniffer_3 stop is failed')                  
        sniffer_3_sns_pcap = self.multiple_sniffer_handler['sniffer_1']['pcap_filename']
                                                                                 
        # Stop sniffer_2 capture                                                 
        if self.config['sniffer_2']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_2')                      
            self.assertTrue(status, 'Sniffer_2 stop is failed')                  
        sniffer_2_sns_pcap = self.multiple_sniffer_handler['sniffer_2']['pcap_filename']

        # Stop sniffer_5 capture                                                 
        if self.config['sniffer_5']['enable'].lower() == 'true':                 
            status = self.stop_sniffer_capture('sniffer_5')                      
            self.assertTrue(status, 'Sniffer_5 stop is failed')                  
        sniffer_5_sns_pcap = self.multiple_sniffer_handler['sniffer_5']['pcap_filename']
                                                                                 
        self.get_sniffer_utility_instance()                                      
                                                                                 
        panel_sta_mac = self.config['panel']['sta_mac_addr']                     
        yofi_2_mac = self.config['yofi-2']['mac']                                
        yofi_3_mac = self.config['yofi-3']['mac']                                
        panel_ap_mac = self.config['panel']['ap_mac_addr']                       
        yofi_2_mac_for_24 = self.config['yofi-2']['mac_for_wps_check']           
        yofi_3_mac_for_24 = self.config['yofi-3']['mac_for_wps_check']           
                                                                                 
        # Sniffer_1 frame analysis                                               
        self.log.info('Sniffer_1 analysis between YoFi-2(MAP) and panel(MPP)')   
        self.log.info('Sniffer_1 pcap file: {}'.format(add_yofi_2_pcap_in_5))    
        status = self.sniffer_analysis.validate_MPP_and_MAP_connection_with_sae_and_peer_action_frames(add_yofi_2_pcap_in_5, yofi_2_mac, panel_sta_mac)
                                                                                 
        # Sniffer_2 frame analysis, Source Mac should be STA (YoFi)              
        self.log.info('Sniffer_2 analysis between YoFi-2(MAP) and panel(MPP)')   
        self.log.info('Sniffer_2 pcap file: {}'.format(add_yofi_2_pcap_in_24))   
        status = self.sniffer_analysis.wps_connect(add_yofi_2_pcap_in_24, yofi_2_mac_for_24, panel_ap_mac)
                                                                             
        # Sniffer_3 frame analysis                                               
        self.log.info('Sniffer_3 analysis between YoFi-3(MAP) and panel(MPP)')   
        self.log.info('Sniffer_3 pcap file: {}'.format(add_yofi_3_pcap_in_5))    
        status = self.sniffer_analysis.validate_MPP_and_MAP_connection_with_sae_and_peer_action_frames(add_yofi_3_pcap_in_5, yofi_3_mac, panel_sta_mac)
                                                                                 
        # Sniffer_4 frame analysis, Source Mac should be STA (YoFi)              
        self.log.info('Sniffer_2 analysis between YoFi-3(MAP) and panel(MPP)')   
        self.log.info('Sniffer_2 pcap file: {}'.format(add_yofi_3_pcap_in_24))   
        status = self.sniffer_analysis.wps_connect(add_yofi_3_pcap_in_24, yofi_3_mac_for_24, panel_ap_mac)

        # Sniffer_3 frame analysis                                               
        self.log.info('Sniffer_3 analysis between YoFi-3(MAP) and YoFi-2(MAP)')   
        self.log.info('Sniffer_3 pcap file: {}'.format(rf_1_linear_validation))    
        status = self.sniffer_analysis.validate_MPP_and_MAP_connection_with_sae_and_peer_action_frames(rf_1_linear_validation, yofi_2_mac, yofi_3_mac)

        # Sniffer_2 packet check M1/M2 packet analysis                                                  
        self.log.info('Sniffer_2 packet checking')                               
        total_errors = {}                                                        
        for camera_type_name in ['hd400w_camera', 'dbc_camera_1']:
            self.get_camera_config(camera_type_name)                             
            self.log.info('#################################################')   
            self.log.info('Started WPS IE validation for {}'.format(camera_type_name))
            self.log.info('Sniffer_2 pcap file: {}'.format(add_camera_pcap))
            camera_mac = self.config[camera_type_name]['mac']                    
            status, errors = self.sniffer_analysis.GES_Vivint_Yofi_PAK_0016_24G_analysis(add_camera_pcap, self.config)
            status_camera_add = self.sniffer_analysis.wps_connect(add_camera_pcap, camera_mac, panel_ap_mac)
            if not status_camera_add:                                            
                errors.append('WPS connection is failed')                        
            total_errors[camera_type_name] = errors                              
            self.log.info('WPS IE validation is done for {}'.format(camera_type_name))
            self.log.info('#################################################')   
                                                                                 
        for camera_type_name in total_errors.keys():                             
            self.log.info('#################################################')   
            self.log.info('Errors found during validation of {}'.format(camera_type_name))
            self.log.info('#################################################')   
            for error in total_errors[camera_type_name]:                         
                self.log.error('{} of {}'.format(error, camera_type_name))       
            self.log.info('#################################################')   
        error_length = [len(total_errors[item]) for item in total_errors]        
        if not all(i == 0 for i in error_length):                                
            self.log.error('M1/M2 packet check failed')                          
                                                                                 
        # Sniffer_5 packet check M1/M2 packet analysis                                                  
        self.log.info('Sniffer_5 packet checking')                               
        total_errors = {}                                                        
        for camera_type_name in ['ping_camera_2', 'hdp450_camera']:                               
            self.get_camera_config(camera_type_name)                             
            self.log.info('#################################################')   
            self.log.info('Started WPS IE validation for {}'.format(camera_type_name))
            self.log.info('Sniffer_5 pcap file: {}'.format(rf_2_add_camera_pcap))
            camera_mac = self.config[camera_type_name]['mac']                    
            status, errors = self.sniffer_analysis.GES_Vivint_Yofi_PAK_0016_24G_analysis(rf_2_add_camera_pcap, self.config)
            status_camera_add = self.sniffer_analysis.wps_connect(rf_2_add_camera_pcap, camera_mac, panel_ap_mac)
            if not status_camera_add:                                            
                errors.append('WPS connection is failed')                        
            total_errors[camera_type_name] = errors                              
            self.log.info('WPS IE validation is done for {}'.format(camera_type_name))
            self.log.info('#################################################')   
                                                                                 
        for camera_type_name in total_errors.keys():                             
            self.log.info('#################################################')   
            self.log.info('Errors found during validation of {}'.format(camera_type_name))
            self.log.info('#################################################')   
            for error in total_errors[camera_type_name]:                         
                self.log.error('{} of {}'.format(error, camera_type_name))       
            self.log.info('#################################################')   
        error_length = [len(total_errors[item]) for item in total_errors]        
        if not all(i == 0 for i in error_length):                                
            self.log.error('M1/M2 packet check failed')                          
                   
        # Sniffer_2 frames analysis for camera switch                                               
        self.log.info('Sniffer_2 packet checking for camera switch')             
        total_errors = {}                                                        
        for camera_type_name in ['hd400w_camera', 'dbc_camera_1']:               
            self.get_camera_config(camera_type_name)                             
            self.log.info('Started WPS connection validation for {}'.format(camera_type_name))
            self.log.info('Sniffer_2 pcap file: {}'.format(camera_switch_pcap))
            camera_mac = self.config[camera_type_name]['mac']                    
            status = self.sniffer_analysis.connection_over_24GHz(camera_switch_pcap, camera_mac, yofi_2_mac_for_24)

        # Sniffer_5 frames analysis for camera switch                                                 
        self.log.info('Sniffer_5 packet checking for camera switch')             
        total_errors = {}                                                        
        for camera_type_name in ['ping_camera_2', 'hdp450_camera']:                               
            self.get_camera_config(camera_type_name)                             
            self.log.info('Started WPS connection validation for {}'.format(camera_type_name))
            self.log.info('Sniffer_5 pcap file: {}'.format(rf_2_camera_switch_pcap))
            camera_mac = self.config[camera_type_name]['mac']                    
            status = self.sniffer_analysis.connection_over_24GHz(rf_2_camera_switch_pcap, camera_mac, yofi_3_mac_for_24)
        
        # Sniffer_1 validation for SNS testcase                                  
        self.log.info('Sniffer_1 frame checking for SNS testcase')               
        self.log.info('Sniffer_1 pcap file: {}'.format(sniffer_1_sns_pcap))      
        status_5ghz = self.sniffer_analysis.mesh_peer_close_5G_analysis(sniffer_1_sns_pcap, yofi_mpp_mac, panel_mac)
                                                                                 
        # Sniffer_2 validation for SNS testcase                                  
        self.log.info('Sniffer_2 frame checking for SNS testcase')               
        total_errors_sniffer_2 = {}                                              
        for camera_type_name in ['dbc_camera_1', 'hd400w_camera']:
            self.get_camera_config(camera_type_name)                             
            self.log.info('Started deauth and disassoc frame validation for {}'.format(camera_type_name))
            self.log.info('Sniffer_2 pcap file: {}'.format(sniffer_2_sns_pcap))  
            status = self.sniffer_analysis.disconnection_24G_analysis(sniffer_2_sns_pcap, self.config['camera']['mac'], self.config['panel']['ap_mac_addr'])
            total_errors_sniffer_2[camera_type_name] = status                    
        self.log.debug(total_errors_sniffer_2)                                   
        sniffer_2_cam_status = True                                              
        for cam_status in total_errors_sniffer_2.values():                       
            if not cam_status:                                                   
                sniffer_2_cam_status = False  
 
        # Sniffer_3 validation for SNS testcase                                  
        self.log.info('Sniffer_3 frame checking for SNS testcase')               
        self.log.info('Sniffer_3 pcap file: {}'.format(sniffer_3_sns_pcap))      
        status_5ghz = self.sniffer_analysis.mesh_peer_close_5G_analysis(sniffer_3_sns_pcap, yofi_mpp_mac, panel_mac)
                                                                                 
        # Sniffer_5 validation for SNS testcase                                  
        self.log.info('Sniffer_5 frame checking for SNS testcase')               
        total_errors_sniffer_5 = {}                                              
        for camera_type_name in ['ping_camera_2', 'hdp450_camera']:
            self.get_camera_config(camera_type_name)                             
            self.log.info('Started deauth and disassoc frame validation for {}'.format(camera_type_name))
            self.log.info('Sniffer_5 pcap file: {}'.format(sniffer_5_sns_pcap))  
            status = self.sniffer_analysis.disconnection_24G_analysis(sniffer_5_sns_pcap, self.config['camera']['mac'], self.config['panel']['ap_mac_addr'])
            total_errors_sniffer_5[camera_type_name] = status                    
        self.log.debug(total_errors_sniffer_5)                                   
        sniffer_5_cam_status = True                                              
        for cam_status in total_errors_sniffer_5.values():                       
            if not cam_status:                                                   
                sniffer_5_cam_status = False   
        
        # Logread validation for SNS testcase                                    
        status = self.validate_logread_for_sns()                                 
                                                                                 
        if not sniffer_2_cam_status or not sniffer_5_cam_status or not status:   
            self.assertTrue(False, 'Logread/Sniffer validation of SnS testcase is failed')
                                                                 
        self.assertTrue(ping_status, 'ping verification failed')                 
        self.log.info('Successfully verified ping')

        self.assertTrue(fping_status, 'fping verification failed')                 
       	self.log.info('Successfully verified fping')

    def tearDown(self):
        self.log.info('======= Test teardown started =======')

        panel_logread_flag = False
        try:
            if self.panel_map_ip is None and self.is_panel_mpp_flag == False:
                self.log.info('MAP Panel IP: {}'.format(self.panel_map_ip))
                self.log.warning('Controller can not reach to MAP panel')
            elif self.is_panel_mpp_flag:
                # Get the logread logs from MPP panel
                status = self.panel.get_logread_logs(self.log_path_with_test_name, 'panel_logread.log')
                self.assertTrue(status, 'Geting panel MPP logread is failed')                     
                self.log.info('Geting panel MPP logread is succeeded')
                panel_logread_flag = True
            else:
                # Get the logread logs from MAP panel
                status = self.panel.get_logread_logs(self.log_path_with_test_name, 'panel_logread.log', self.panel_map_ip)
                self.assertTrue(status, 'Geting panel MAP logread is failed')                     
                self.log.info('Geting panel MAP logread is succeeded')
                panel_logread_flag = True
        except Exception as error:
            self.log.error('Failed to get the panel logread logs, Error: {}'.format(error))

        if self.mesh_graph_flag:
            try:
                self.get_mesh_node_graph_from_panel()
                self.assertTrue(status, 'Geting mesh graph from panel is failed')                     
            except Exception as error:
                self.log.error('Failed to get mesh graph from panel, Error: {}'.format(error))

        try:
            self.log.info('======= delete cameras from panel =======')
            camera_type_list = self.multiple_camera_handler.keys()
            if len(camera_type_list) > 0:
                self.log.info('YoFi multiple camera handler dict: {}'.format(self.multiple_camera_handler))
                for camera_type_name in camera_type_list:
                    self.log.info('Camera type name: {}'.format(camera_type_name))
                    camera_service_name = self.multiple_camera_handler[camera_type_name]['camera_service_name']
                    try:
                        if camera_service_name:
                            # Get camera config
                            self.get_camera_config(camera_type_name)
                            status = self.delete_camera_from_panel(camera_type_name)
                            self.assertTrue(status, 'Camera deletion is failed')
                            self.log.info('Camera deletion is succeeded')
                        else:
                            self.camera_clean_up(camera_type_name)
                    except Exception as error:
                        self.log.error('{} delete failed with exception {}'.format(camera_service_name, error))
        except Exception as error:
            tb = traceback.format_exc()
            self.log.debug(tb)
            self.log.error('Test teardown failed with exception {}'.format(error))

        try:
            self.log.info('======= delete YoFi nodes from panel =======')
            yofi_type_list = self.multiple_yofi_handler.keys()
            if len(yofi_type_list) > 0:
                self.log.info('YoFi multiple yofi handler dict: {}'.format(self.multiple_yofi_handler))
                for yofi_type_name in yofi_type_list:
                    self.log.info('YoFi type name: {}'.format(yofi_type_name))
                    yofi_service_name = self.multiple_yofi_handler[yofi_type_name]['yofi_service_name']
                    try:
                        if yofi_service_name:
                            # Get YoFi config
                            self.get_yofi_config(yofi_type_name)
                            status = self.delete_yofi_from_panel(yofi_type_name)
                            self.assertTrue(status, 'YoFi deletion is failed')
                            self.log.info('YoFi deletion is succeeded')
                        else:
                            self.yofi_clean_up(yofi_type_name)
                    except Exception as error:
                        self.log.error('{} delete failed with exception {}'.format(yofi_type_name, error))
        except Exception as error:
            tb = traceback.format_exc()
            self.log.debug(tb)
            self.log.error('Test teardown failed with exception {}'.format(error))

        try:
            status = self.reconfigure_mpp()
            self.assertTrue(status, 'Re-configuring Panel as MPP is failed')
        except Exception as error:
            self.log.error('Reconfiguring Panel as MPP is failed, Error: {}'.format(error))

        if not panel_logread_flag:
            try:
                # Get the logread logs from MAP panel
                status = self.panel.get_logread_logs(self.log_path_with_test_name, 'panel_logread.log')
                self.assertTrue(status, 'Geting panel logread in teardown is failed')                     
                self.log.info('Geting panel logread in teardown is succeeded')
            except Exception as error:
                self.log.error('Failed to get the panel logread logs in teardown, Error: {}'.format(error))

        try:
            status = self.stop_all_sniffers()
            self.assertTrue(status, 'Unable to stop the sniffer')                     
        except Exception as error:
            self.log.error('Error while stopping the all sniffer: {}'.format(error))

        if self.attenuator_1:
            try:
                status = self.att_obj.set_all_channel_to_high_attenuation(               
                                            self.config['attenuator']['attenuator_1'])   
                self.assertTrue(status, 'Set all channel to high attenuation_1 is failed') 
                self.log.info('Set all channel to high attenuation_1 is successful')
            except Exception as error:
                self.log.error('Error while high attenuating the all channel of attenuator_1: {}'.format(error))

        if self.attenuator_1:
            try:
                status = self.att_obj.set_all_channel_to_high_attenuation(               
                                            self.config['attenuator']['attenuator_2'])   
                self.assertTrue(status, 'Set all channel to high attenuation_2 is failed') 
                self.log.info('Set all channel to high attenuation_2 is successful')
            except Exception as error:
                self.log.error('Error while high attenuating the all channel of attenuator_2: {}'.format(error))

        try:
            self.cntl.cmd_local('dmesg > controller_dmesg.txt')
            self.cntl.cmd_local('mv controller_dmesg.txt {}'.format(
                self.log_path_with_test_name))
        except Exception as error:
            self.log.error('Error while collecting controller dmesg : {}'.format(error))

        self.panel.save_all_panel_logs(self.log_path_with_test_name)
